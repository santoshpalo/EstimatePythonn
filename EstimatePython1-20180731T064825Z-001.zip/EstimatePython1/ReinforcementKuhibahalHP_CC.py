import ClassLibrary as cl
reinforcement1=cl.Quantity([['footing bars',3*2*9,1.15,0.62],
                           ['column bars 1',4,1.2+.45+.25+.5,1.58],
                           ['column bars 2',4,3.0+0.45+.25+.5,1.58],
                           ['column bars 3',4,4.5+.45+.25+.5,1.58],
                           ['stirrups',64,0.87,0.395],
                            ['first floor bend bars long walls',4*2,8.03,0.89],
                            ['first floor bend bars short walls',4*2,6.27,0.89],
                            ['verandah width bend',4,1.65+.5-.08,0.89],
                            ['bend stirrups',201,0.67,0.395],
                            ['columns 0.25x0.25',8*4,3.3,0.89],
                            ['0.38x0.25 column',8,3.3,0.89],
                            ['stirrups',112,0.87,0.395],
                            ['stirrups 1',14,0.87+.26,0.395]])
reinforcement1.rate=100
reinforcement1.reinforcement()
reinforcement2=cl.Quantity([['waist beam bars',6,3.4*2+1.8,0.89],
                            ['extra top bars1',2,1.5,0.89],
                            ['extra top bars2',2,1.2+1.15+1.15,0.89],
                            ['extra top bars3',2,1.2+1.15,0.89],
                            ['stirrups',57,0.87+.14,0.395],
                            ['waist slab top bars',60,1.33,0.62],
                            ['waist slab bottom bars',60,0.5,0.62],
                            ['distribution of top bars',8,3.4*2+1.2*2,0.395],
                            ['distribution of bottom bars',2,3.4*2+1.2*2,0.395],
                            ['lintel bars long walls',4*2,8.03,0.62],
                            ['lintel bars short walls',4*2,6.27,0.62],
                            ['extra bar on door',1,1.2+.5,0.62],
                            ['extra bar on windows',6,1.4,0.62],
                            ['lintel bend stirrups',180,0.67,0.395],
                            ['chajja bars on door',12,0.78,0.395],
                            ['chajja bars on windows',6*9,0.5+.25-.08,0.395],
                            ['distribution in door chajjas',4,1.73,0.395],
                            ['distribution in window chajjas',6*3,1.2-.07,0.395],
                            ['column0.25x0.25 stirrups',8*6,0.87,0.395],
                            ['0.38x0.25 column stirrups',7,0.87+0.26,0.395]])
reinforcement2.rate=100
reinforcement2.reinforcement()