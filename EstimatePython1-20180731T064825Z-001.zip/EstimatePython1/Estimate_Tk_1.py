import numpy as np
import textwrap


import pandas as pd
import items as it
import LeadStatement1 as ls1
from tkinter import *
import FunctionLibraryR as fr
import Gorekhnath as hb
#==================================================================================================================================
class Length:
    def __init__(self,master):
        frame = Frame(master,bg = 'red')
        frame.pack()
        self.Label = Label(frame, text = 'Length')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.TCL = Button(frame,text = "Total centre line length",command = self.TCL)
        self.TCL.pack(side=TOP)
    def TCL(self):
        d = hb.tcl
        table = pd.DataFrame(d, index=range(1, len(d) + 1),
                             columns=['description', 'no', 'length'])
        table['quantity'] = table['no'] * table['length'] .round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)

        print('\n', 'Total centre line length', '\n', table, '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}m'.format(table.tquantity))


root = Tk()
app = Length(root)
root.mainloop()
#===============================================================================================================================================================
class Volume:
    def __init__(self,master):
        frame = Frame(master,bg = 'green')
        frame.pack()
        self.Label = Label(frame, text = 'Volume',bg = 'AntiqueWhite1', fg = 'blue4')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.foundation = Button(frame,text = "foundation",command = self.foundation, bg = 'blanched almond', fg = 'blue')
        self.foundation.pack(side=TOP)
        self.concrete148 = Button(frame, text="C.C.(1:4:8)", command=self.concrete148)
        self.concrete148.pack(side=TOP)
        self.concrete136 = Button(frame, text="C.C.(1:3:6)", command=self.concrete136)
        self.concrete136.pack(side=TOP)
        self.concrete124 = Button(frame, text="C.C.(1:2:4)", command=self.concrete124)
        self.concrete124.pack(side=TOP)
        self.bmfpcb = Button(frame, text="brick masonry in FP with CB", command=self.bmfpcb)
        self.bmfpcb.pack(side=TOP)
        self.bmsscb = Button(frame, text="brick masonry in SS with CB", command=self.bmsscb)
        self.bmsscb.pack(side=TOP)
        self.bmfpfa = Button(frame, text="brick masonry in FP with FA", command=self.bmfpfa)
        self.bmfpfa.pack(side=TOP)
        self.bmssfa = Button(frame, text="brick masonry in SS with FA", command=self.bmssfa)
        self.bmssfa.pack(side=TOP)
        self.sandfilling = Button(frame, text="Sand filling in F & P", command=self.sandfilling)
        self.sandfilling.pack(side=TOP)
        self.rccm20 = Button(frame, text="R.C.C. M-20 grade concrete", command=self.rccm20)
        self.rccm20.pack(side=TOP)
        self.rrhg = Button(frame, text="R.R.H.G. stone masonry (1:6)", command=self.rrhg)
        self.rrhg.pack(side=TOP)
        self.grade_I_metalling = Button(frame, text="Grade I Metalling in road", command=self.grade_I_metalling)
        self.grade_I_metalling.pack(side=TOP)
        self.moorum_sub_base = Button(frame, text="Moorum sub-base in road", command=self.moorum_sub_base)
        self.moorum_sub_base.pack(side=TOP)


    def foundation(self):
        d = hb.foundation
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['efhs'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.foundation(1)),'\u20B9{:.2f} '.format(round(fr.foundation(1)*table.tquantity,0)))
    def concrete148(self):
        d = hb.CC148
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['CC(1:4:8)'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.concrete(1)),'\u20B9{:.2f} '.format(round(fr.concrete(1)*table.tquantity,0)))
    def concrete136(self):
        d = hb.metal_concrete
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['CC(1:3:6)'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.concrete(2)),'\u20B9{:.2f} '.format(round(fr.concrete(2)*table.tquantity,0)))
    def concrete124(self):
        d = hb.chips_concrete
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['CC(1:2:4)'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.concrete(3
                                                                                           )),'\u20B9{:.2f} '.format(round(fr.concrete(3)*table.tquantity,0)))
    def rccm20(self):
        d = hb.rcc
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['m20'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.gradedconcrete(2)),'\u20B9{:.2f} '.format(round(fr.gradedconcrete(2)*table.tquantity,0)))
    def bmfpcb(self):
        d = hb.rccm20
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['bmfpcb'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.brickmasonry(1)[0]),'\u20B9{:.2f} '.format(round(fr.brickmasonry(1)[0]*table.tquantity,0)))
    def bmsscb(self):
        d = hb.brick_masonry
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['bmsscb'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.brickmasonry(1)[1]),'\u20B9{:.2f} '.format(round(fr.brickmasonry(1)[1]*table.tquantity,0)))
    def bmfpfa(self):
        d = hb.brickfp
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['bmfpfa'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.brickmasonry(2)[0]),'\u20B9{:.2f} '.format(round(fr.brickmasonry(2)[0]*table.tquantity,0)))
    def bmssfa(self):
        d = hb.brick
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['bmssfa'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.brickmasonry(2)[1]),'\u20B9{:.2f} '.format(round(fr.brickmasonry(2)[1]*table.tquantity,0)))
    def sandfilling(self):
        d = hb.sand_filling
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['sand_filling'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.sandfilling()),'\u20B9{:.2f} '.format(round(fr.sandfilling()*table.tquantity,0)))
    def rrhg(self):
        d = hb.rrhg_masonry
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['rrhg'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.stonemasonry(1)),'\u20B9{:.2f} '.format(round(fr.stonemasonry(1)*table.tquantity,0)))
    def grade_I_metalling(self):
        d = hb.grade_I_metalling
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['gradeI'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.Grade_I_metalling()),'\u20B9{:.2f} '.format(round(fr.Grade_I_metalling()*table.tquantity,0)))
    def moorum_sub_base(self):
        d = hb.moorum_sub_base
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['subbase'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.moorum(1)),'\u20B9{:.2f} '.format(round(fr.moorum(1)*table.tquantity,0)))




root = Tk()
app = Volume(root)
root.mainloop()
#================================================================================================================================================================
class trapezoidalVolume:
    def __init__(self,master):
        frame = Frame(master,bg = 'midnight blue')
        frame.pack()
        self.Label = Label(frame, text = 'Trapezoidal Volume',bg = 'AntiqueWhite1', fg = 'blue4')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit,bg = 'yellow')
        self.button.pack(side = LEFT)
        self.RRHG_masonry = Button(frame,text = "RRHG masonry",command = self.rrhg, bg = 'blanched almond', fg = 'blue')
        self.RRHG_masonry.pack(side=TOP)
        self.metal_concrete = Button(frame, text="Cement concrete (1:3:6)", command=self.metalconcrete, bg='blanched almond', fg='blue')
        self.metal_concrete.pack(side=TOP)
    def rrhg(self):
        d = hb.crhg
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','top breadth','bottom breadth','height'])
        table['quantity'] = (table['no'] * table['length']*(table['top breadth']+table['bottom breadth'])/2.0*table['height'].round(2))
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['top breadth'] = table['top breadth'].map('{:.2f}m'.format)
        table['bottom breadth'] = table['bottom breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['rrhg'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.stonemasonry(2)),'\u20B9{:.2f} '.format(round(fr.stonemasonry(2)*table.tquantity,0)))
    def metalconcrete(self):
        d = hb.metal_concrete_wall_1
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','top breadth','bottom breadth','height'])
        table['quantity'] = (
        table['no'] * table['length'] * (table['top breadth'] + table['bottom breadth']) / 2.0 * table['height'].round(
            2))
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['top breadth'] = table['top breadth'].map('{:.2f}m'.format)
        table['bottom breadth'] = table['bottom breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['CC(1:3:6)'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.concrete(2)),'\u20B9{:.2f} '.format(round(fr.concrete(2)*table.tquantity,0)))

root = Tk()
app = trapezoidalVolume(root)
root.mainloop()


#=============================================================================================================================================================
class Reinforcement:
    def __init__(self,master):
        frame = Frame(master,bg = 'blue')
        frame.pack()
        self.Label = Label(frame, text = 'Reinforcement')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.tor_8 = Button(frame,text = '8mm tor HYSD reinforcement bars',command = self.tor_8)
        self.tor_8.pack(side = TOP)
        self.tor_10 = Button(frame, text='10mm tor HYSD reinforcement bars', command=self.tor_10)
        self.tor_10.pack(side=TOP)
        self.tor_12 = Button(frame, text='12mm tor HYSD reinforcement bars', command=self.tor_12)
        self.tor_12.pack(side=TOP)
        self.tor_16 = Button(frame, text='16mm tor HYSD reinforcement bars', command=self.tor_16)
        self.tor_16.pack(side=TOP)
        self.tor_20 = Button(frame, text='20mm tor HYSD reinforcement bars', command=self.tor_20)
        self.tor_20.pack(side=TOP)
    def tor_8(self):
        d = hb.hysd8
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length'])
        table['quantity'] = table['no'] * table['length'].round(2)
        tquantity = (table['quantity'].sum())
        tweight = round(tquantity*0.395,2)
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)
        print('\n', it.items['hysd'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}m'.format(tquantity) ,'@ {:.3f} kg/m = '.format(0.395),'{:.2f}kg '.format(tweight),'\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}qtl'.format(tweight/100), '@ {:.2f} kg/m = '.format(fr.reinforcement()), '\u20B9{:.2f} '.format(round(tweight*fr.reinforcement()/100)))
    def tor_10(self):
        d = hb.tor_10
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length'])
        table['quantity'] = table['no'] * table['length'].round(2)
        tquantity = (table['quantity'].sum())
        tweight = round(tquantity*0.62,2)
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)
        print('\n', it.items['hysd'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}m'.format(tquantity) ,'@ {:.3f} kg/m = '.format(0.62),'{:.2f}kg '.format(tweight),'\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}qtl'.format(tweight/100), '@ {:.2f} kg/m = '.format(fr.reinforcement()), '\u20B9{:.2f} '.format(round(tweight*fr.reinforcement()/100)))
    def tor_12(self):
        d = hb.hysd12
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length'])
        table['quantity'] = table['no'] * table['length'].round(2)
        tquantity = (table['quantity'].sum())
        tweight = round(tquantity*0.89,2)
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)
        print('\n', it.items['hysd'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}m'.format(tquantity) ,'@ {:.3f} kg/m = '.format(0.89),'{:.2f}kg '.format(tweight),'\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}qtl'.format(tweight/100), '@ {:.2f} kg/m = '.format(fr.reinforcement()), '\u20B9{:.2f} '.format(round(tweight*fr.reinforcement()/100)))
    def tor_16(self):
        d = hb.hysd16
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length'])
        table['quantity'] = table['no'] * table['length'].round(2)
        tquantity = (table['quantity'].sum())
        tweight = round(tquantity*1.58,2)
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)
        print('\n', it.items['hysd'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}m'.format(tquantity) ,'@ {:.3f} kg/m = '.format(1.58),'{:.2f}kg '.format(tweight),'\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}qtl'.format(tweight/100), '@ {:.2f} kg/m = '.format(fr.reinforcement()), '\u20B9{:.2f} '.format(round(tweight*fr.reinforcement()/100)))
    def tor_20(self):
        d = hb.tor_20
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length'])
        table['quantity'] = table['no'] * table['length'].round(2)
        tquantity = (table['quantity'].sum())
        tweight = round(tquantity*2.47,2)
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)
        print('\n', it.items['hysd'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}m'.format(tquantity) ,'@ {:.3f} kg/m = '.format(2.47),'{:.2f}kg '.format(tweight),'\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}qtl'.format(tweight/100), '@ {:.2f} kg/m = '.format(fr.reinforcement()), '\u20B9{:.2f} '.format(round(tweight*fr.reinforcement()/100)))
root = Tk()
app = Reinforcement(root)
root.mainloop()
#================================================================================================================================================================
class RSCS:
    def __init__(self,master):
        frame = Frame(master, bg = 'thistle')
        frame.pack()
        self.Label = Label(frame, text = 'Rigid & Smooth Centering & Shuttering')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.footing = Button(frame,text = 'RSCS footiong & plinth',command = self.footing)
        self.footing.pack(side = TOP)
        self.slab = Button(frame, text='RSCS slab & chajja', command=self.slab)
        self.slab.pack(side=TOP)
        self.column = Button(frame, text='RSCS column & beam', command=self.column)
        self.column.pack(side=TOP)
        self.lintel = Button(frame, text='RSCS lintel', command=self.lintel)
        self.lintel.pack(side=TOP)
        self.stair = Button(frame, text='RSCS stair', command=self.stair)
        self.stair.pack(side=TOP)
        self.wall = Button(frame, text='RSCS wall', command=self.wall)
        self.wall.pack(side=TOP)
    def footing(self):
        d = hb.rscs_footings
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['rscs_plinth'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.rscs(3)),'\u20B9{:.2f} '.format(round(fr.rscs(3)*table.tquantity,0)))
    def slab(self):
        d = hb.rscs_slab
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['rscs_slab'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.rscs(1)),'\u20B9{:.2f} '.format(round(fr.rscs(1)*table.tquantity,0)))
    def column(self):
        d = hb.rscs_column
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['rscs_beam'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.rscs(2)),'\u20B9{:.2f} '.format(round(fr.rscs(2)*table.tquantity,0)))
    def lintel(self):
        d = hb.rscs_lintel_bottom
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['rscs_lintel'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.rscs(4)),'\u20B9{:.2f} '.format(round(fr.rscs(4)*table.tquantity,0)))
    def stair(self):
        d = ([['column foundation',4,1.2,1.2]])
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['rscs_stair'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.rscs(5)),'\u20B9{:.2f} '.format(round(fr.rscs(5)*table.tquantity,0)))
    def wall(self):
        d = hb.rscs_wall
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['rscs_wall'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.rscs(6)),'\u20B9{:.2f} '.format(round(fr.rscs(6)*table.tquantity,0)))
root = Tk()
app = RSCS(root)
root.mainloop()
#=====================================================================================================================
class verticalArea:
    def __init__(self,master):
        frame = Frame(master, bg = 'coral')
        frame.pack()
        self.Label = Label(frame, text = 'Vertical Area')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.plaster_1 = Button(frame, text='12mm thick plaster (1:6)', command=self.plaster_1)
        self.plaster_1.pack(side=TOP)
        self.plaster_2 = Button(frame, text='16mm thick plaster (1:6)', command=self.plaster_2)
        self.plaster_2.pack(side=TOP)
        self.plaster_3 = Button(frame, text='20mm thick plaster (1:4)', command=self.plaster_3)
        self.plaster_3.pack(side=TOP)
        self.wpcp = Button(frame, text='Water proofing cement paint 2 coats', command=self.wpcp)
        self.wpcp.pack(side=TOP)
    def plaster_1(self):
        d = ([['column foundation',4,1.2,1.2]])
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['12cp(1:6)'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.plaster(1)),'\u20B9{:.2f} '.format(round(fr.plaster(1)*table.tquantity,0)))
    def plaster_2(self):
        d = hb.plaster_16
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['16cp(1:6)'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.plaster(2)),'\u20B9{:.2f} '.format(round(fr.plaster(2)*table.tquantity,0)))
    def plaster_3(self):
        d = hb.plaster20
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['20cp(1:4)'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.plaster(4)),'\u20B9{:.2f} '.format(round(fr.plaster(4)*table.tquantity,0)))
    def wpcp(self):
        d = hb.wpcp
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['wpcp'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.waterproofpaint()),'\u20B9{:.2f} '.format(round(fr.waterproofpaint()*table.tquantity,0)))
root = Tk()
app = verticalArea(root)
root.mainloop()
#==============================================================================================================
class horizontalArea:
    def __init__(self,master):
        frame = Frame(master,bg = 'light blue')
        frame.pack()
        self.Label = Label(frame, text = 'Horizontal Area')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.asf = Button(frame, text='2.5cm thick flooring (1:2:4)', command=self.asf)
        self.asf.pack(side=TOP)
        self.dpc = Button(frame, text='2.5cm damp proof course (1:2:4)', command=self.dpc)
        self.dpc.pack(side=TOP)
        self.ceramic = Button(frame, text='Tile Floor', command=self.ceramic)
        self.ceramic.pack(side=TOP)
        self.gci_sheet = Button(frame, text='GCI sheet roofing', bg = 'azure',fg = 'alice blue',command=self.gci_roofing )
        self.gci_sheet.pack(side=TOP)
    def asf(self):
        d = ([['column foundation',4,1.2,1.2]])
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth'])
        table['quantity'] = table['no'] * table['length']*table['breadth'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['12cp(1:6)'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.flooring(1)),'\u20B9{:.2f} '.format(round(fr.flooring(1)*table.tquantity,0)))
    def dpc(self):
        d = hb.dpc
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth'])
        table['quantity'] = table['no'] * table['length']*table['breadth'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['dpc'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.flooring(0)),'\u20B9{:.2f} '.format(round(fr.flooring(0)*table.tquantity,0)))
    def ceramic(self):
        d = hb.ceramic_tile
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth'])
        table['quantity'] = table['no'] * table['length']*table['breadth'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['floor tile'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.Tile(1)),'\u20B9{:.2f} '.format(round(fr.Tile(1)*table.tquantity,0)))
    def gci_roofing(self):
        d = hb.gci_roofing
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth'])
        table['quantity'] = table['no'] * table['length']*table['breadth'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['gci_roofing'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.gci_roofing()),'\u20B9{:.2f} '.format(round(fr.gci_roofing()*table.tquantity,0)))
root = Tk()
app = horizontalArea(root)
root.mainloop()

#==============================================================================================================


print('Cost A.C. sheet for roofing 182.34 sqm @ \u20B9182.00 / sqm = \u20B933,186.00')
print('Cost for masonry aquarium\t\t\t\t\t\t= \u20B915,000.00')
print(textwrap.fill('Cost Cost topwards MS fixtures including all rafters and purlins, GI J hookk washers etc.  = \u20B920,000.00',80))
print('Cost of HYSD bars including labour charges = 6.00q @ \u20B95,000.00/q = \u20B930,000.00')
print(textwrap.fill('Cost of ceramic glazed tiles on the pavement 273.18 sqm @ \u20B9429.00/sqm = \u20B91,17,194.00',80))
print('Cost of Sambalpuri stones on the poavement 254.60sqm @ \u20B9140.00/sqm = \u20B935,644.00')
print('Cost towards bore well of b0.15 x 0.10 dia = \u20B91,00,000.00')
print(textwrap.fill('Cost towards three nos. of water closets and bath room including watersupply and sanitary fittings @ \u20B930,000.00 / no = \u20B990,000.00',80))
print('='*80)
print(textwrap.fill('This estimate amounting to \u20B9 19,14,281.00 (Rupees ninteen lakh fourteen thousand two hundred eighty one only) has been prepared by me on request',80))
print('\n\n\n\n\t\t\t\tJunior Engineer\t\t\tAssistant Executive Engineer\n\t\t\t\tUlunda Block Office\t\t\tSonepur Block Office')


