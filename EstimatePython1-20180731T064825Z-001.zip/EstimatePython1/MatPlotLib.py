import matplotlib.pyplot as plt
import numpy as np
t = np.arange(0.0,1.0,0.01)
s = np.arange(0.0,5.0,0.05)
fig = plt.figure()
ax = fig.add_subplot(2,1,1)
fig2 = plt.figure()
ax2 = fig2.add_axes([0.15,0.1,0.7,0.3])
line = ax.plot(t,s,color = 'red',lw=5)
xtext = ax.set_xlabel('my x data')
ytext = ax.set_ylabel('my y data')

plt.show()