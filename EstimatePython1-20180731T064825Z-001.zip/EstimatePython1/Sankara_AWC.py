import items as it
import ClassLibrary as cl
import FunctionLibraryR as fr










if __name__ == "__main__":
    print(it.items['asfloor'])
    floor = cl.Quantity([['hall',1,8.51-0.25,3.68-0.25],
                         ['store',1,8.51/3-0.25,2.26-0.25],
                         ['kitchen',1,8.51/3-0.25,2.26-0.25],
                         ['verandah',1,8.51/3-0.25,2.26-0.25],
                         ['toilets',3,10.74-8.51-0.25,1.06],
                         ['entrance steps',3,1.5,0.25],
                         ['toilet steps',3,3.0,0.25]])
    floor.rate=fr.flooring()
    floor.vArea()
    print(it.items['bmfp'])
    brickwork = cl.Quantity([['entrance steps 1',1,2.6,1.0,0.25],
                             ['entrance steps 2',1,2.6,0.75,0.15],
                             ['entrance steps 3',1,2.6,0.5,0.15],
                             ['entrance step 4',1,2.6,0.25,0.15],
                             ['toilet steps 1',1,3.0,1.0,0.25],
                             ['toilet steps 2',1,0.75,0.15],
                             ['toilet steps 3',1,3.0,0.5,0.15],
                             ['toilet steps 4',1,3.0,0.25,0.15]])
    brickwork.rate=fr.brickmasonry(1)[0]
    brickwork.volume()
    print(it.items['bmss'])
    brickworkA= cl.Quantity([['partition walls of toilets',3,10.74-8.51-0.25,0.13,3.3]])
    brickworkA.rate = fr.brickmasonry(1)[1]
    brickworkA.volume()
    dado = cl.Quantity([['toilet long walls',6,10.74-8.51-0.25,1.5],
                        ['toilet short walls',6,1.06,1.5]])
    dado.rate=fr.plaster(6)
    dado.vArea()
    print(it.items['20cp(1:6)'])
    plinthplaster = cl.Quantity([['external plaster plinth',1,38.4,0.75]])
    plinthplaster.rate =fr.plaster(5)
    plinthplaster.vArea()
    print(it.items['wpcp'])
    print('468.08 sqm @ Rs.',fr.waterproofpaint(),'= Rs.',round(468.08*fr.waterproofpaint(),2))
    print(it.items['paint'])
    dWpaint=cl.Quantity([['door1',2.25,1.2,2.1],
                         ['door2',2*2.25,0.9,2.1],
                         ['door 3',3*2.25,0.75,2.1],
                         ['windows',4*2.75,0.9,1.2]])
    dWpaint.rate = fr.painting()
    dWpaint.vArea()
