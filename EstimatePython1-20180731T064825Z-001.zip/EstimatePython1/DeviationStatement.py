import textwrap
import pandas as pd
import numpy as np
pd.set_option('max_colwidth', 0)
pd.set_option('display.expand_frame_repr', False)
pd.set_option('display.precision', 2)
print('\t\t\t\t\t\t\tDeviation Statement','\n','_'*80)
print(textwrap.fill('Name of the work:-Construction of Conference Hall-cum-Auditorium at Braja Bihari High School Sankara',80))
print('Estimated cost:-\u20B925,00,000.00\tHead of Account:-IAP(2014-15)')
print('_'*80)
q=np.zeros((39,6),dtype=float)
q[:,4]=(168.29,54.94,101.86,203.26,30.54,282.29,158.44,91.67,96.25,20.67,29.46,51.26,303.7,254.21,
        40.45,805.28,5.76,3.15,22.66,12,227.25,27.37,184.34,23.7,4.01,29.66,84.59,519.42,254.21,
        165.92,294.06,23.79,193.56,224.7,36.68,4.57,10.57,63.55,129.86)
q[0,0:2]=(109.17,2.7)
q[1,0:3]=(12.61,22.28,3.07)
q[2,0:2]=(37.37,66)
q[3,0:2]=(181.48,1.44)
q[5,0:2]=(19.8,207.96)
q[6,1]=236.17
q[9,0:3]=(13.24,0,4.95)
q[30,0:2]=(208.11,23.08)
q[7,0:2]=(50.68,74.9)
q[8,0:2]=(53.21,74.9)

q[11,1]=59.11
q[13,2]=297.87
q[14,2]=128.25
q[15,2]=1020
q[16,2]=1.89
q[18,2]=13.52
q[12,2]=276.08
q[21,2]=61.57
q[22,2]=105.04
q[24,2]=82.44
q[26,2]=70
q[27,2]=845.34
q[28,2]=227.94
q[29,2]=264.27
q[31,2]=13.52
q[32,2]=82.44
q[33,2]=105.04
q[35,2]=3.78
q[36,2]=8.75
q[37,2]=56.98
q[38,2]=211.34






Foundation=pd.DataFrame(q,columns=[['Quantity']*6,['1stR/A','2ndR/A','3rdR/A','total','estimated','Deviation']],
                   index=[['excavation of foundation',
                          'Cement concrete (1:4:8)',
                          'R.C.C. M-20 grade concrete',
                           'R/S C/S of plinth',
                           'R/S C/S Lintel band',
                           'R/S C/S of beams',
                           'R/S C/S of slab',
                           'Labour for reinforcement',
                           'Cost of HYSD bar',
                           'Brick masonry in F/P',
                           '2.5cm thick D.P.C. (1:2:4)',

                           'Brick masonry in S/S',
                           '16mm thick plaster(1:6',
                           '12mm thick plaster(1:6)',
                           '6mm thick plaster(1:4)',
                           'M.S. Doors and Windows',
                           'sliding type windows',
                           'Fixing PVC doors',
                           'glazed ceramic wall tile',
                           'chequered tiles in dado',
                           'M.S. window grills',

                           'vitrified floor tiles',
                           'kota stone tile flooring',
                           'chequered tiles in steps',
                           'glazed ceramic floor tiles',
                           'kota stone wall tile',
                           'painting 2 coats',
                            'water proofing cement paint',
                            'distempering 2 coats',
                            '20mm thick plaster(1:4)',
                           'Filling sand',

                            'cost of ceramic wall tiles',
                            'cost of ceramic floor tiles',
                            'cost of kota stone tiles',
                           'chequered tiles',
                           'cost of red oxide primer',
                           'cost of enamel paint',
                           'cost of distemper',
                           'cost of WPC paint']])
Foundation['Quantity']['total']=Foundation['Quantity']['1stR/A']+Foundation['Quantity']['2ndR/A']+Foundation['Quantity']['3rdR/A']
Foundation['Quantity']['Deviation']=Foundation['Quantity']['total']-Foundation['Quantity']['estimated']
rccm20=np.array([[]])
if __name__ == "__main__":
    print(Foundation)
    print('\n\n\nJunior Engineer\t\tAssistant Engineer\t\t\tAddl. P.D.(T)\n'
          'Binka Block Office\tBinka Block Office\t\t\tD.R.D.A. Subarnapur')

