import ClassLibrary as cl
import math as mt
import items as it
import textwrap
import items as it
import FunctionLibrary as fl
print(textwrap.fill('Name of the work:-Construction of C.C. road inside KuhiBahal High School Campus',80))
print('Estimated Cost:-Rs.1,86,416.00\t\tHead of Account:-4th SFC (2014-15)')
print('-'*80)

print('Surface Area of rectangular roads')
rectangularpatches=[
                   ['patch2',1,18.9,3.85],
                   ['patch3',1,4.3,3.65],
                   ['patch4',1,18.34,3.73],
                   ['patch5',1,10.54,3.8],

                   # ['patch7',1,1.95,1.95],
                   # ['patch8',1,4.35,4],
                   # ['patch9',1,2.5,1.35],

                   # ['triangular patch1',1,2.4,1.2],
                   # ['triangular patch2',1,1.35,1.35],

                   ]
rectangularpatches=cl.Quantity(rectangularpatches)
rectangularpatches.surface_area()
cut_offArea=[
        ['patch2', 1, 18.9 + 11.4, 0.2],
        ['patch3', 2, 4.3, 0.2],
        ['patch4', 1, 18.34 + 18.34 - 7.65, 0.2],
        ['patch5', 1, 18.1 * 2 - 7.4, 0.2],

             # ['patch7',2,1.8,0.2],

             ]
cut_offArea=cl.Quantity(cut_offArea)
cut_offArea.hArea()
print(it.items['efhs'])
foundation=[
            ['reactangular area cut-off',19.35,0.2],
            ]
foundation=cl.Quantity(foundation)
foundation.rate=110.17
foundation.areaVolume()
sandfill=[
          ['rectangular surface area',177.56,.05]]
sandfill=cl.Quantity(sandfill)
sandfill.rate=304.17
sandfill.areaVolume()
print(it.items['CC(1:3:6)'])
cc136=[['rectangular surface area',196.91,.1],
       ['rectangular cut-off wall',19.35,0.25]]
cc136=cl.Quantity(cc136)
cc136.rate=3521.83
cc136.areaVolume()
print(it.items['CC(1:2:4)'])
cc124=[
          ['rectangular surface area',196.91,.1],
       ]
cc124=cl.Quantity(cc124)
cc124.rate=4696.44
cc124.areaVolume()
print('Hire and running charges of plate vibrator')
print('\n14.20hour @\u20B9106.00/hour = \u20B91505.00')

rscs2=[
             ['patch2',1,18.9+11.4,0.3],
             ['patch3',2,4.3,0.3],
             ['patch4',1,18.34+18.34-7.65,0.3],
             ['patch5',1,18.1*2-7.4,0.3],

             # ['patch7',2,1.8,0.3],

             ]
rscs2=cl.Quantity(rscs2)
rscs2.rate=83.43
rscs2.vArea()
print('\nProvisional cost towards Display Board= Rs.1,000.00')
print('Cess for welfare of labourers = Rs.1,865.00')
print('\nWork contingency=Rs.935.00')
print('Labour registration cess= Rs.100.00\n')
print('='*80)
fl.signature(186416,'One lakh eighty six thousand four hundred six',1,'')




