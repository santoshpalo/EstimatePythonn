#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 31 07:15:00 2018

@author: spalo
"""

import LeadStatementGST as ls
import numpy as np
us=224.3
s=264.3
ss=244.3
hs=284.3
cement=ls.z['total cost'][4]
sand=ls.z['total cost'][2]
chips12=ls.z['total cost'][9]
floortile=ls.z['total cost'][15]
walltile=ls.z['total cost'][16]
vitrified=ls.z['total cost'][14]
whitecement=ls.z['total cost'][23]
wallprimer=ls.z['total cost'][25]
redoxideprimer=ls.z['total cost'][17]
enamelpaint=ls.z['total cost'][18]
cementpaint=ls.z['total cost'][22]
plasticpaint=ls.z['total cost'][19]
distemper=ls.z['total cost'][21]
wallputty=ls.z['total cost'][24]
#plaster
print('plaster')
plaster_Quantity=np.array([[0.12,0.14,0.0358,0.015],#plaster 12mm (1:6))
                           [0.11,0.15,0.0644,0.015],#plaster 12mm (1:4) with punning
                           [0.24,0.16,0.043,.018],#plaster 16mm (1:6)
                           [0.12,0.14,0.0543,0.015],#plaster 12mm (1:4)
                           [0.24,0.16,0.0744,.021],#plaster 20mm (1:4)
                           [0.24,0.16,0.057,.021],#plaster 20mm (1:6)
                           ])
plaster_rate=np.array([[us],
                       [s],
                       [cement],
                       [sand]])
plaster=np.round(np.dot(plaster_Quantity,plaster_rate),2)
print (plaster)

#Floor
print('floor')
floor_Quantity=np.array([[0.36,0.13,.0858,.023,.012,0,0,0,0],# A.S. flooring
                         [0.216,0.216,(1.857+0.44)/10,0,.013,1,0,0,0],#tiles other than marble in floor
                         [0.325,0.325,(0.715+0.66)/10,0,.015,0,1,0,0],#tile other than marble on wall
                          [0.216,0.216,(0.33+0.744)/10,0,.021,0,0,1,.0076]#vitrified tile
                          ])
floor_rate=np.array([[us],
                     [hs],
                     [cement],
                     [chips12],
                     [sand],
                     [floortile],
                     [walltile],
                     [vitrified],
                     [whitecement]])
floor=np.round(np.dot(floor_Quantity,floor_rate),2)
print(floor)

#paint
print('paint')
paint_Quantity=np.array([[0.5/9.3,0.5/9.3,.084,0,0,0,0,0,0,0],#Wall priming one coat
                         [0.5/9.3,0.5/9.3,0,.054,0,0,0,0,0,0],#steel door window priming
                         [1.1/9.3,1.25/9.3,0,0,0.125,0,0,0,0,0],#painting 2 coats on new door and window
                         [.022,.015,0,0,0,0.25,0,0,0,0],#cement paint 2 coats
                         [.064,.054,0,0,0,0,.125,0,0,0],#plastic paint of walls
                         [.063,.052,0,0,0,0,0,.25,0,0],#distempering 2 coats
                         [.057,0,0,0,0,0,0,0,.05,0.8],#wall putty finishing
                         ])
paint_rate=np.array([[us],
                     [hs],
                     [wallprimer],
                     [redoxideprimer],
                     [enamelpaint],
                     [cementpaint],
                     [plasticpaint],
                     [distemper],
                     [s],
                     [wallputty]])
paint=np.round(np.dot(paint_Quantity,paint_rate),2)
print(paint)
