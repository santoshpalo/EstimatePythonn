import pandas as pd
pd.set_option('max_colwidth', 0)
pd.set_option('display.expand_frame_repr', False)
pd.set_option('display.precision', 2)
def timeline(data):
    table=pd.DataFrame(data,index = range(1,len(data)+1),columns = ['Activity','Date','Remarks'])
    table['Date'] = pd.to_datetime(table['Date'],errors ='coerce')
    print (table)





if __name__ == "__main__":
    timeline([['execution started','2014-09-02','Execution started'],
              ['1st R/A bill prepared by J.E.','2014-11-10','produced for check measurement'],
              ['A.E.E. & C.P. reported non-availablity of MGNREGS fund','27-11-2014','Bill paid from State Plan'],
              ['2nd phase M.R. generated','2015-06-30','a long gap for rearrangement of labourers'],
              ['2nd R/A bill prepared','2015-09-12','The house is built upto lintel level'],
              ['3rd phase M.R. issued','2016-01-25','long gap for rearrangement of labourers'],
              ['3rd R/A bill passed ','2016-02-05','The state plan fund exhausted'],
              ['revised estimate MGNREGA','2017-06-01','Detailed project report prepared'],
              ['MGNREGA M.R. (1st phase) generated','2017-01-09','material collected for slab casting'],
              ['Detailed project report entered','2017-03-10','as per MGNREGA guide lines'],
              ['4th R/A bill passed ','2017-03-04','Roof slab cast'],
              ['unskilled wages processed','2017-04-15','paid'],
              ['unskilled wages processed','2017-04-17','unpaid till now']])
    timeline([['Revised estimate prepared','2016-01-12','Detailed project report'],
              ['1st phase of M.R. generated','2016-01-25','Materials collected'],
              ['1st R/A bill prepared','2016-02-05','Put up the bill for ckeck measurement'],
              ['1st R/A bill passed','2016-02-10','Building has been brought upto plinth level'],
              ['reported B.D.O. about non-payment of \u20B984,967.00','2016-04-25','Payment towards Material'],
              ['Material payment cleared up','2016-05-10','From state plan head of account'],
              ['Work to be restarted','2017-01-17','requested for M.R., materials collected'],
              ['2nd phase M.R. issued','2017-01-16','work is started'],
              ['2nd R/A bill prepared','2017-01-25','put up for check measurement'],
              ['unskilled labourers payment','2017-02-03','labourers paid'],
              ['material payment','2017-03-04','A month passed for material payment']])
