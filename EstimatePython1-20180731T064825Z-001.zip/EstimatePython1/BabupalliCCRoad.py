import ClassLibrary as cl
import textwrap
import items as it
import FunctionLibraryR as fl

print(textwrap.fill("Name of the work:-Construction of C.C. road inside village Babupalli",80))
print('Head of Account:-\t\t\t\tEstimated Cost:-Rs.2,56,000.00')
print('-'*80)

print(it.items['efhs'])
efhs=[['field side wall',1,20.8,1.05,0.3],
       ['village side wall',1,14,1.05,0.30],
       ['drain both side walls',2,7.2,1.05,0.3],
       ['west side field walls',1,3.65-1.05,1.05,0.3],
       ['near tube wall',1,3.65,0.45,0.3],
       ['cut-off wall near tree',1,3.0,0.45,0.3],
      ['guard wall near tree',1,21,1.05,0.3]]
efhs=cl.Quantity(efhs)
efhs.rate=110.17
efhs.volume()
print(it.items['CC(1:3:6)'])
cc136=[['field side wall',1,20.8,0.3,0.75,0.75],
       ['village side wall',1,14,0.3,0.75,0.75],
       ['drain both side walls',2,7.2,0.3,0.75,0.75],
       ['west side field walls',1,3.65-1.05,0.3,0.3,0.75],
       ['near tube wall',1,3.65,0.3,0.3,0.6],
       ['cut-off wall near tree',1,3.0,0.3,0.3,0.3],
       ['guard wall around tree',1,21,0.3,0.75,0.75]]
cc136=cl.Quantity(cc136)
cc136.rate=3521.83
cc136.trapezoidalVolume()
ccbase=[['road base',1,20.8,3.65,0.1],
        ['deduct for RCC M-20 slab',-1,7.2,1.2,0.1],
        ['near tree',0.5,12.5,3.0,0.1],
        ['bottom of the drain',1,7.2,2.5,0.15],
        ]
ccbase=cl.Quantity(ccbase)
ccbase.rate=3521.83
ccbase.volume()
print(it.items['m20'])
rccm20=[['rcc slab of the culvert',1,7.2,1.2,0.20]
        ]
rccm20=cl.Quantity(rccm20)
rccm20.rate=4037.4
rccm20.volume()
print(it.items['CC(1:2:4)'])
cc124=[['road crust',1,20.8,3.65,0.1],
        ['deduct for RCC M-20 slab',-1,7.2,1.2,0.1],
        ['near tree',0.5,12.5,3.0,0.1],
        ['bottom of the drain',1,7.2,0.6,0.1],
        ]
cc124=cl.Quantity(cc124)
cc124.rate=4696.44
cc124.volume()
print(it.items['sand_filling'])
sandfill=[['whole road',1,20.8,3.65,3.65,0.45],
          ['village side wall',- 1, 14, 0.3, 0.75, 0.45],
          ['drain both side walls',- 2, 7.2, 0.3, 0.75, 0.45],
          ['west side field walls', -1, 3.65 - 1.05, 0.3, 0.3, 0.45],
          ['near tube wall',- 1, 3.65, 0.3, 0.3, 0.4],
          ['deduct culvert hole',-1,7.2,0.6,0.6,0.5]]
sandfill=cl.Quantity(sandfill)
sandfill.rate=304.17
sandfill.trapezoidalVolume()
print(it.items['hysd'])
reinforcement=[['main bars',48,2.45,0.89],
               ['distributions',14,7.12,0.62]]
reinforcement=cl.Quantity(reinforcement)
reinforcement.rate=4863.74
reinforcement.reinforcement()
print(it.items['rscs_wall'])
centeringshuttering=[['field side wall',2,20.8,0.75],
       ['village side wall',2,14,0.75],
       ['drain both side walls',2*2,7.2,0.75],
       ['west side field walls',1*2,3.65-1.05,0.75],
       ['cut-off wall near tube wall',1*2,3.65,0.6],
       ['cut-off wall near tree',1*2,3.0,0.3],
                     ['guard wall around tree',2,21,0.75]]
centeringshuttering=cl.Quantity(centeringshuttering)
centeringshuttering.rate=402.33
centeringshuttering.vArea()
print(it.items['rscs_slab'])
centeringshuttering1=[['R.C.C. culvert wall',1,7.2,0.6]
       ]
centeringshuttering1=cl.Quantity(centeringshuttering1)
centeringshuttering1.rate=313.92
centeringshuttering1.hArea()
print(it.items['rscs_plinth'])
centeringshuttering2=[['road base',2,20.8,0.2],
        ['add for RCC M-20 slab',2,7.2,0.2],
        ['near tree',2,12.5,0.2],

       ]
centeringshuttering2=cl.Quantity(centeringshuttering2)
centeringshuttering2.rate=83.43
centeringshuttering2.hArea()
print('Hire and running charges of plate vibrator')
print('\n4.30hour @\u20B9106.00/hour = \u20B9456.00')
print('\nProvisional cost towards Display Board= Rs.2,000.00')
print('Cess for welfare of labourers = Rs.2,560.00')
print('\nWork contingency=Rs.1,280.00')
print('Labour registration cess= Rs.100.00\n')
print('='*80)
fl.signature(256000,'Two lakh fifty six thousand only',1,'')
