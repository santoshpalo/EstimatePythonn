#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 11 17:00:27 2018

@author: spalo
"""

import pandas as pd
import FunctionLibraryR as fl
import items as it
import math as mt
class PlayGround():
    def __init__(self,length,breadth,height):
        self.length=length
        self.breadth=breadth
        self.height=height
        
    def earthworkR(self):
        data=[[self.length,self.breadth,self.height]]
        table=pd.DataFrame(data,columns=['length','breadth','height'],index=['play ground'])
        table['volume']=round(table['length']*table['breadth']*table['height'],2)
        sumVolume=table['volume'].sum()
        return [sumVolume,sumVolume*fl.earthwork_mechanical(1)]
    def earthwork(self):
        data=[[self.length,self.breadth,self.height]]
        table=pd.DataFrame(data,columns=['length','breadth','height'],index=['play ground'])
        table['volume']=round(table['length']*table['breadth']*table['height'],2)
        sumVolume=table['volume'].sum()
        table['length']=table['length'].map('{:.2f}m'.format)
        table['breadth']=table['breadth'].map('{:.2f}m'.format)
        table['height']=table['height'].map('{:.2f}m'.format)
        table['volume']=table['volume'].map('{:.2f}cum'.format)
        print(it.items['Earth_work_mechanical'],'\n',table,'\n\t\t\t','{:.2f}cum'.format(sumVolume),'@ \u20B9{:.2f} /cum'.format(fl.earthwork_mechanical(1)),'= \u20B9{:.2f}'.format(mt.ceil(sumVolume*fl.earthwork_mechanical(1))))
    def finedressingR(self):
        data=[[self.length,self.breadth]]
        table=pd.DataFrame(data,columns=['length','breadth'],index=['play ground'])
        table['area']=round(table['length']*table['breadth'],2)
        sumArea=table['area'].sum()
        return [sumArea,sumArea*fl.finedressing()]
    def finedressing(self):
        data=[[self.length,self.breadth]]
        table=pd.DataFrame(data,columns=['length','breadth'],index=['play ground'])
        table['area']=round(table['length']*table['breadth'],2)
        sumArea=table['area'].sum()
        table['length']=table['length'].map('{:.2f}m'.format)
        table['breadth']=table['breadth'].map('{:.2f}m'.format)        
        table['area']=table['area'].map('{:.2f}sqm'.format)
        print(it.items['finedressing'],'\n',table,'{:.2f}sqmm'.format(sumArea),'@ \u20B9{:.2f} /cum'.format(fl.finedressing()),'= \u20B9{:.2f}'.format(mt.ceil(sumArea*fl.finedressing())))
    def miscellaneousR(self):
        return 2500.00
    def miscellaneous(self):
        print('\nProvisional cost for display board and photograph = \u20B9',self.miscellaneousR())
    def cessR(self):
        return mt.ceil((self.earthworkR()[1]+self.finedressingR()[1]+self.miscellaneousR())*.01)
    def cess(self):
        print('\nProvision for cess for welfare of labourers = \u20B9',self.cessR())
    def totalR(self):
        return mt.ceil(self.cessR()/.01*1.01)
    
        
      
        
        
        
        