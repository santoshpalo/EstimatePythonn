#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 11 17:19:41 2018

@author: spalo
"""

import RenovationTank as rt
import FunctionLibraryR as fl
print('\t\t\tDETAILED ESTIMATE')
print('\nName of the work:-Renovation of Mahada Negitikira JamuMunda')
print('Estimated Cost:-\u20B92,50,000.00\tHead of Account:-G.G.Y.(2017-18)')
print('-'*80)
tank=rt.RenovateTank(42,42,1.28)
tank.excavation()
tank.miscellaneous()
tank.cess()
print('\nTotal estimated cost = ','\u20B9{:.2f}'.format(tank.totalR()),'limited to \u20B9 2,50,000.00')
print('-'*80)
fl.signature(250000,'Rupees two lakh fifty thousand only',1,'')