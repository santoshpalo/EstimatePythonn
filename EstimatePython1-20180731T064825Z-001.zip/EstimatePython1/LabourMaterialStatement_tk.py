import math as mt
from tkinter import *
import numpy as np
import LeadStatement_2014 as ls1
import math as mt
import pandas as pd


pd.set_option('max_colwidth',0)
pd.set_option('display.expand_frame_repr', False)
pd.set_option('display.precision', 2)
pd.set_option('max_colwidth', 0)

pd.set_option('display.expand_frame_repr', False)
#===============================================================================
# pd.set_option('display.precision', 2)
#===============================================================================
pd.options.display.max_rows = 999

def material_labour(item,q):
    if item == 'bmfp':
        c = ['u/s','masonI','masonII','cement','sand','bricks']
        i = ['brick masonry in F & P']
        d = {'u/s':[2.96*q],'masonI':[0.35*q],'masonII':[1.05*q],'cement':[0.672*q],'sand':[0.28*q],'bricks':[mt.ceil(350*q)]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}cum'.format)

    elif item == 'rcc':
        c = ['u/s','masonII','cement','sand','chips12']
        i = ['R.C.C. (1:1.5:3)']
        d = {'u/s':[4.6*q],'masonII':[0.68*q],'cement':[4.29*q],'sand':[0.45*q],'chips12':[0.9*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}cum'.format)

    elif item == 'cc148':
        c = ['u/s','masonII','cement','sand','metal40']
        i = ['Cement Concrete (1:4:8)']
        d = {'u/s':[3.9*q],'masonII':[0.18*q],'cement':[1.72*q],'sand':[0.48*q],'metal40':[0.96*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}cum'.format)

    elif item == 'rscscolumn':
        c = ['s/s','masonII']
        i = ['Centering of column']
        d = {'s/s':[2.75/4.2*q],'masonII':[2.75/4.2*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}sqm'.format)

    elif item == 'rscsplinth':
        c = ['s/s','masonII']
        i = ['Centering of footing']
        d = {'s/s':[0.05*q],'masonII':[0.05*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}sqm'.format)

    elif item == 'efhs':
        c = ['u/s']
        i = ['Excavation Foundation']
        d = {'u/s':[0.43*1.2*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}cum'.format)
    elif item == 'hysd':
        c = ['u/s','s/s','masonI','b_wire']
        i = ['Reinforcement works']
        d = {'u/s':[0.8*q],'s/s':[.044*q],'masonI':[0.3*q],'b_wire':[0.8*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}qtl'.format)
    elif item == 'paint':
        c = ['u/s','masonI','paint','primer']
        i = ['Paint and priming']
        d = {'u/s':[1.6/9.3*q],'masonI':[1.75/9.3*q],'paint':[1.25/10*q],'primer':[0.54/10*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}sqm'.format)
    elif item == 'wpcp':
        c = ['u/s','masonI','wpcp']
        i = ['water proofing cement paint']
        d = {'u/s':[.032*q],'masonI':[.022*q],'wpcp':[2.5/10*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}sqm'.format)
    elif item == '12cp(1:6)':
        c = ['u/s','masonII','cement','sand']
        i = ['plaster (1:6) 12mm thick']
        d = {'u/s':[.12*q],'masonII':[.14*q],'cement':[.0358*q],'sand':[.015*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}sqm'.format)
    elif item == '12cp(1:4)':
        c = ['u/s','masonII','cement','sand']
        i = ['plaster (1:4) 12mm thick']
        d = {'u/s':[.12*q],'masonII':[.14*q],'cement':[.0644*q],'sand':[.015*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}sqm'.format)
    elif item == 'sandfill':
        c = ['u/s','sand(c)']
        i = ['Filling sand']
        d = {'u/s':[.1236*q],'sand(c)':[q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}sqm'.format)
    elif item == 'asf(1:2:4)':
        c = ['u/s','masonI','cement','sand','chips12']
        i = ['A.S. Flooring (1:2:4)']
        d = {'u/s':[.33*q],'masonI':[0.13*q],'cement':[.0858*q],'sand':[0.012*q],'chips12':[0.023*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}cum'.format)
    elif item == '16cp(1:6)':
        c = ['u/s','masonII','cement','sand']
        i = ['plaster (1:6) 16mm thick']
        d = {'u/s':[.24*q],'masonII':[.16*q],'cement':[.043*q],'sand':[.018*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}sqm'.format)
    elif item == 'rcc M-20':
        c = ['u/s','s/s','masonII','cement','sand','chips10','chips20','generator','CCmixer']
        i = ['R.C.C. M-20 grade']
        d = {'u/s':[20.0/15*q],'s/s':[0.86/15*q],'masonII':[.1*q],'cement':[5.21*10/15*q],'sand':[.45*q],'chips10':[5.4/15*q],'chips20':[8.1/15*q],'generator':[0.4*q],'CCmixer':[0.4*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}cum'.format)
    elif item == 'pcc M-20':
        c = ['u/s','s/s','masonII','cement','sand','chips10','chips20','metal40','generator','CCmixer']
        i = ['P.C.C. M-20 grade']
        d = {'u/s':[20.0/15*q],'s/s':[0.86/15*q],'masonII':[.1*q],'cement':[5.16*10/15*q],'sand':[.45*q],'chips10':[1.35/15*q],'chips20':[4.05/15*q],'metal40':[8.1/15*q],'generator':[0.4*q],'CCmixer':[0.4*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}cum'.format)
    elif item == 'rscsslab':
        c = ['s/s','masonII']
        i = ['Centering of slab']
        d = {'s/s':[2.75/9*q],'masonII':[2.75/9*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}sqm'.format)
    elif item == 'rscswalls':
        c = ['s/s','masonII']
        i = ['Centering of walls']
        d = {'s/s':[13.5/23.9*q],'masonII':[13.5/23.9*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}sqm'.format)
    elif item == '20cp(1:4)':
        c = ['u/s','masonII','cement','sand']
        i = ['plaster (1:4) 20mm thick']
        d = {'u/s':[.24*q],'masonII':[.16*q],'cement':[.0744*q],'sand':[.021*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}sqm'.format)
    elif item == 'cc136':
        c = ['u/s','masonII','cement','sand','metal40']
        i = ['Cement Concrete (1:3:6)']
        d = {'u/s':[3.9*q],'masonII':[0.18*q],'cement':[2.29*q],'sand':[0.48*q],'metal40':[0.96*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}cum'.format)
    elif item == 'cc124':
        c = ['u/s','masonII','cement','sand','chips12']
        i = ['Cement Concrete (1:2:4)']
        d = {'u/s':[4.6*q],'masonII':[0.68*q],'cement':[3.23*q],'sand':[0.45*q],'chips12':[0.90*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}cum'.format)
    elif item == 'rscslintel':
        c = ['s/s','masonII']
        i = ['Centering of lintel']
        d = {'s/s':[1.25/7.8*q],'masonII':[1.25/7.8*q]}
        table = pd.DataFrame(d,index = i,columns = c)
        table.insert(0,'quantity',q)
        table['quantity']=table['quantity'].map('{:.2f}sqm'.format)
    elif item == '20cp(1:6)':
        c = ['u/s', 'masonII', 'cement', 'sand']
        i = ['plaster (1:6) 20mm thick']
        d = {'u/s': [.24 * q], 'masonII': [.16 * q], 'cement': [.057 * q], 'sand': [.021 * q]}
        table = pd.DataFrame(d, index=i, columns=c)
        table.insert(0, 'quantity', q)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)
    elif item == '6cp(1:4)':
        c = ['u/s', 'masonII', 'cement', 'sand']
        i = ['plaster (1:4) 6mm thick']
        d = {'u/s': [.17 * q], 'masonII': [.14 * q], 'cement': [.0372 * q], 'sand': [.0075 * q]}
        table = pd.DataFrame(d, index=i, columns=c)
        table.insert(0, 'quantity', q)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)
    elif item == 'distemper':
        c = ['u/s', 'masonI', 'distemper']
        i = ['Distemper 2 coats']
        d = {'u/s': [0.062 * q], 'masonI': [0.052* q], 'distemper':[0.25*q]}
        table = pd.DataFrame(d, index=i, columns=c)
        table.insert(0, 'quantity', q)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)
    elif item == 'vitrified':
        c = ['u/s', 'masonI', 'sand','cement','w_cement','v_tile']
        i = ['vitrified tile flooring']
        d = {'u/s': [0.216 * q], 'masonI': [0.216 * q], 'sand': [0.021 * q],'cement':[.1074*q],'w_cement':[.0075*q],'v_tile':[1*q]}
        table = pd.DataFrame(d, index=i, columns=c)
        table.insert(0, 'quantity', q)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)
    elif item == 'ewhs':
        c = ['u/s']
        i = ['Earth work in hard soil']
        d = {'u/s': [0.43* q]}
        table = pd.DataFrame(d, index=i, columns=c)
        table.insert(0, 'quantity', q)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)
    elif item == 'rrhg':
        c = ['u/s', 'masonI', 'masonII', 'cement', 'sand', 'stone']
        i = ['RRHG stone masonry in F & P']
        d = {'u/s': [3.17 * q], 'masonI': [0.35 * q], 'masonII': [1.41 * q], 'cement': [0.8151 * q],
         'sand': [0.34 * q], 'stone': [1 * q]}
        table = pd.DataFrame(d, index=i, columns=c)
        table.insert(0, 'quantity', q)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)
    elif item == 'crhg':
        c = ['u/s', 's/s','masonI', 'masonII', 'cement', 'sand', 'stone']
        i = ['CRHG stone masonry in F & P']
        d = {'u/s': [(1.41+.25) * q], 's/s':[1.41*q],'masonI': [(0.35+2.47) * q], 'masonII': [1.41 * q], 'cement': [0.572 * q],
         'sand': [0.24 * q], 'stone': [1.0 * q]}
        table = pd.DataFrame(d, index=i, columns=c)
        table.insert(0, 'quantity', q)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)
    elif item == 'bmfps':
          c = ['u/s', 'masonI', 'masonII', 'cement', 'sand', 'C.B.bricks']
          i = ['F.A.brick masonry(1:6)']
          d = {'u/s': [2.96 * q], 'masonI': [0.35 * q], 'masonII': [1.05 * q], 'cement': [0.672 * q], 'sand': [0.28 * q],
             'F.A.bricks': [mt.ceil(350 * q)]}
          table = pd.DataFrame(d, index=i, columns=c)
          table.insert(0, 'quantity', q)
          table['quantity'] = table['quantity'].map('{:.2f}cum'.format)
    elif item == 'bmfps1':
        c = ['u/s', 'masonI', 'masonII', 'cement', 'sand', 'F.A.bricks']
        i = ['F.A.brick masonry(1:6)']
        d = {'u/s': [2.96 * q], 'masonI': [0.35 * q], 'masonII': [1.05 * q], 'cement': [0.672 * q], 'sand': [0.28 * q],
             'F.A.bricks': [mt.ceil(350 * q)]}
        table = pd.DataFrame(d, index=i, columns=c)
        table.insert(0, 'quantity', q)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)
    elif item == 'floor_tile':
        c = ['u/s', 'masonI', 'f_tile', 'cement', 'sand']
        i = ['Fixing tiles in floor']
        d = {'u/s': [0.216 * q], 'masonI': [0.216 * q], 'f_tile': [1.0 * q], 'cement': [.2737* q], 'sand': [0.013 * q]}
        table = pd.DataFrame(d, index=i, columns=c)
        table.insert(0, 'quantity', q)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)
    elif item == 'wall_tile':
        c = ['u/s', 'masonI', 'w_tile', 'cement', 'sand']
        i = ['Fixing tiles on walls']
        d = {'u/s': [0.325 * q], 'masonI': [0.325 * q], 'w_tile': [1.0 * q], 'cement': [.1375 * q],
             'sand': [0.015 * q]}
        table = pd.DataFrame(d, index=i, columns=c)
        table.insert(0, 'quantity', q)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)
    else :
        pass
    return table
fields=('ewhs','efhs','filling sand','C.C.(1:3:6)','C.C.(1:4:8)','C.C.(1:2:4)','C.C.(1:1.5:3)','P.C.C. M-20','R.C.C. M-20','Reinforcement','R.S./C.S. Plinth','R.S./C.S. Column'
,'R.S./C.S. Lintel','R.S./C.S. Slab','R.S./C.S. Staircase','R.S./C.S. Wall','B.M.F.P.C.B.(1:6)','B.M.F.P.F.A.(1:6)','B.M.S.S..C.B.(1:6)','B.M.S.S.F.A.(1:6)',
 'R.R.H.G.S.M.(1:6)','C.R.H.G.S.M.(1:6)','12mm C.P.(1:6)','16mm C.P.(1:6)','20mm C.P.(1:6)','12mm C.P.(1:4)','20mm C.P.(1:4)','6mm C.P.(1:4) on R.C.C.','A.S.F. with C.C. (1:2:4)',
        'Vitrified Tile Floor','Ceramic Tile Floor','Ceramic Wall Tile',
        'Painting 2 coats Priming 1 coat','2 coats water proofing cement paint','Distemper 2 coats'

        )
def maketable(entries):
    rate = pd.Series([213.5, 233.5, 253.5, 273.5, ls1.z['total cost'][4], ls1.z['total cost'][2] - 38.4,
                      ls1.z['total cost'][9] - 138.3, ls1.z['total cost'][11] - 138.3, ls1.z['total cost'][1], 63.83, 151.97,
                      101.57, 27.56, ls1.z['total cost'][3] - 38.4, ls1.z['total cost'][8] - 138.3,
                      ls1.z['total cost'][10] - 138.3, 208.7, 153.91, 51.92, 13.58, 571.65, ls1.z['total cost'][7] - 138.3,
                      ls1.z['total cost'][13] - 0, 337.80, 304.72],
                     index=['u/s', 's/s', 'masonII', 'masonI', 'cement', 'sand', 'chips12', 'metal40', 'bricks',
                            'b_wire', 'paint', 'primer', 'wpcp', 'sand(c)', 'chips10', 'chips20', 'generator',
                            'CCmixer', 'distemper', 'w_cement', 'v_tile', 'stone', 'F.A.bricks', 'f_tile', 'w_tile'])

    a = material_labour('bmfp', float(entries['B.M.F.P.C.B.(1:6)'].get()))
    b = material_labour('rcc', float(entries['C.C.(1:1.5:3)'].get()))
    c = material_labour('cc148', float(entries['C.C.(1:4:8)'].get()))
    d = material_labour('rscscolumn', float(entries['R.S./C.S. Column'].get()))
    e = material_labour('rscsplinth', float(entries['R.S./C.S. Plinth'].get()))
    f = material_labour('efhs', float(entries['efhs'].get()))
    g = material_labour('hysd', float(entries['Reinforcement'].get()))
    h = material_labour('paint', float(entries['Painting 2 coats Priming 1 coat'].get()))
    i = material_labour('wpcp', float(entries['2 coats water proofing cement paint'].get()))
    j = material_labour('12cp(1:6)', float(entries['12mm C.P.(1:6)'].get()))
    k = material_labour('sandfill', float(entries['filling sand'].get()))
    l = material_labour('asf(1:2:4)', float(entries['A.S.F. with C.C. (1:2:4)'].get()))
    m = material_labour('16cp(1:6)', float(entries['16mm C.P.(1:6)'].get()))
    n = material_labour('rcc M-20', float(entries['R.C.C. M-20'].get()))
    o = material_labour('rscsslab', float(entries['R.S./C.S. Slab'].get()))
    p = material_labour('rscswalls', float(entries['R.S./C.S. Slab'].get()))
    q = material_labour('20cp(1:4)', float(entries['20mm C.P.(1:4)'].get()))
    r = material_labour('cc136', float(entries['C.C.(1:3:6)'].get()))
    s = material_labour('cc124', float(entries['C.C.(1:2:4)'].get()))
    t = material_labour('rscslintel', float(entries['R.S./C.S. Lintel'].get()))
    u = material_labour('20cp(1:6)', float(entries['20mm C.P.(1:6)'].get()))
    v = material_labour('6cp(1:4)', float(entries['6mm C.P.(1:4) on R.C.C.'].get()))
    w = material_labour('distemper', float(entries['Distemper 2 coats'].get()))
    x = material_labour('vitrified', float(entries['Vitrified Tile Floor'].get()))
    y = material_labour('ewhs', float(entries['ewhs'].get()))
    a1 = material_labour('rrhg', float(entries['R.R.H.G.S.M.(1:6)'].get()))
    a2 = material_labour('bmfps', float(entries['B.M.F.P.F.A.(1:6)'].get()))
    a3 = material_labour('bmfps1', float(entries['B.M.S.S.F.A.(1:6)'].get()))
    a4 = material_labour('floor_tile', float(entries['Ceramic Tile Floor'].get()))
    a5 = material_labour('wall_tile', float(entries['Ceramic Wall Tile'].get()))
    a6 = material_labour('12cp(1:4)', float(entries['12mm C.P.(1:4)'].get()))
    a7 = material_labour('pcc M-20', float(entries['P.C.C. M-20'].get()))
    a8 = material_labour('crhg', float(entries['C.R.H.G.S.M.(1:6)'].get()))
    z = a.append(b).append(c).append(d).append(e).append(f).append(g).append(h).append(i).append(j).append(k).append(l). \
        append(m).append(n).append(o).append(p).append(q).append(r).append(s).append(t).append(u).append(v).append(w). \
        append(x).append(y).append(a1).append(a2).append(a3).append(a4).append(a5).append(a6).append(a7).append(a8)

    z = z[['quantity', 'u/s', 's/s', 'masonII', 'masonI', 'cement', 'sand', 'chips12', 'metal40', 'bricks', 'b_wire',
           'paint', 'primer', 'wpcp', 'sand(c)', 'chips10', 'chips20', 'generator', 'CCmixer', 'distemper', 'w_cement',
           'v_tile', 'stone', 'F.A.bricks', 'f_tile', 'w_tile']]

    result = z.sum(axis=0, numeric_only=True)
    # z1= result.iloc[1:10]
    table1 = pd.DataFrame(dict(quantity=result, rate=rate))
    table1['total'] = table1['quantity'] * table1['rate']
    total_cost = round(table1['total'].sum(), 2)
    table1['rate'] = table1['rate'].map('Rs.{:.2f}'.format)
    table1['total'] = table1['total'].map('Rs.{:.2f}'.format)
    # ===========================================================================
    # ram = z.drop(z['quantity'] != 0)
    # ===========================================================================
    # ===========================================================================
    # z = z.drop(['bricks','paint','primer','wpcp','chips12','distemper','w_cement','vitrified tile','f_tile','w_tile','stone'],axis=1)
    # table1=table1.drop(table1['quantity']== 0)
    # ===========================================================================

    zz = z[z['u/s'] != 0]
    zzz = zz[zz['s/s'] != 0]
    print(table1[table1['quantity'] != 0], '\n', zzz.dropna(axis=1, how='all'), '\n', 'The total cost =',
          'Rs.{:.2f}'.format(total_cost))





def makeform(root,fields):
    entries={}
    for field in fields:
        row=Frame(root,bg ='red')
        lab = Label(row,width=30,text=field+":",anchor='w',bg="yellow",fg="black")
        ent= Entry(row,bg="blue",fg="white")
        ent.insert(0,"0")
        row.pack(side=TOP,fill=X,padx=0,pady=0)

        lab.pack(side=LEFT)
        ent.pack(side=RIGHT,expand = YES,fill=X)
        entries[field]=ent
    return entries
def fetch(entries):
    for entry in entries:
        print('Input => "%s"' % entry.get())


if __name__ == '__main__':
    root = Tk()
    root.title("Labour & Material Statement")
    ents = makeform(root, fields)
    root.bind('<Return>', (lambda event, e=ents: fetch(e)))


    b1 = Button(root, text='Return',bg='cyan', command=(lambda e=ents: maketable(e)))
    b1.pack(side=BOTTOM, padx=5, pady=5)
    root.mainloop()

