#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 11 16:02:06 2018

@author: spalo
"""

import ClassLibrary as cl
import items as it
import textwrap
import FunctionLibraryR as fl
import LeadStatementGST as ls
l=5.25
print('Calculation of centre line length')
tcl=cl.Quantity([['common room 4 sides',4,l],
                 ['toilet long',1,l+1.5],
                ['toilet short walls 1',2,1.5+l/4],
                ['toilet short walls 2',2,1.5],
                ['verandah long walls',1,l],
                ['verandah short walls 2',2,1.5]])
tcl.tcl()
tcl=44.62
print('\n',it.items['efhs'])
foundation=cl.Quantity([['column trenches',16,1.5,1.5,1.5],
                       ['alround walls',1,tcl-16*1.5,0.6,0.6],
                       ['steps',2,2,1.5,0.3]
                        ])
foundation.rate=fl.foundation(1)
foundation.volume()
print('\n',it.items['sand_filling'])
sandfill=cl.Quantity([['column trenches',16,1.5,1.5,0.15],
                       ['alround walls',1,tcl-16*1.2,0.6,0.15],
                      ['in the plinth',1,l-.25,l-0.25,0.45],
                      ['verandah',1,l-0.25,1.5-0.25,0.45],
                      ['toilet', 1,l+2*1.15-0.25,1.25,0.45],
                      ['toilet sides portion',2,l/4-0.25,1.25,0.45],
                      ['steps',2,2,1.5,0.15]
                      ])
sandfill.rate=fl.sandfilling()
sandfill.volume()
print('\n',it.items['CC(1:3:6)'])
concrete=cl.Quantity([['column trenches',16,1.5,1.5,0.15],
                       ['alround walls',1,tcl-16*1.2,0.6,0.15],
                      ['in the plinth',1,l-.25,l-0.25,0.1],
                      ['verandah',1,l-0.25,1.5-0.25,0.1],
                      ['toilet', 1,l+2*1.15-0.25,1.25,0.1],
                      ['toilet sides portion',2,l/4-0.25,1.25,0.1],
                      ['steps',2,2,1.5,0.15]
                      
                      ])
concrete.rate=fl.concrete(2)
concrete.volume()
#print('\n',it.items['CC(1:2:4)'])
#concrete=cl.Quantity([
#                      ['plinth protection tank side',1,28.5,1.5,0.1],
#                        ['plinth protection front and back',2,10,1.0,0.1]])
#concrete.rate=fl.concrete(3)
#concrete.volume()

print('\n',it.items['bmfpfa'])
brickworkfp=cl.Quantity([['centre line of total walls',1,tcl-16*.45,0.25,0.3],
                         ['centre line of total walls',1,tcl-16*.25,0.25,0.45],
                         
                         ])
brickworkfp.rate=fl.brickmasonry(2)[0]
brickworkfp.volume()
print('\n',it.items['m20'])
rcc=cl.Quantity([['column footings',16,1.2,1.2,0.3],
                 ['column pedestals ',16,0.45,0.45,0.45],                
                 ['columns upto P.L.',16,0.25,0.25,0.75],
                 ['plinth beam 1',1,tcl-0.5,0.25,0.3],                 
                 ['lintel bend',1,tcl-2*0.25,0.25,0.15],
                 ['half brick thick lintel bend',1,1.5,0.13,0.15],
                 ['columns 1 above P.L.',11,0.25,0.25,3.0],
                 ['columns 2 above P.L.',5,0.25,0.25,2.7],
                 ['chajjas 1',1,l+0.25+2*0.45,0.45,0.06],
                 ['chajjas 2',2,l/4+0.75+.15+.13,0.45,0.06],
                 ['R.C.C. beams',2,l,0.25,0.3],
                 ['R.C.C. roof bend long',2,tcl-0.5,0.25,0.15],
                 ['R.C.C. roof slab on toilet long',1,l+2*1.5+.25+.3,1.5+.25+.15,0.1],
                 ['R.C.C. roof slab on toilet short',2,l/2+.25,1.5+.25+.15,0.10],
                 ['R.C.C. slab main',1,l+0.25+.3+1.5,l+0.25+0.3,0.1],
                 ])
rcc.rate=fl.gradedconcrete(2)
rcc.volume()
print('\n',it.items['bmssfa'])
brickworkss=cl.Quantity([['alround walls',1,tcl-0.5,0.25,2.7-0.15],
                         ['half brick thk walls',2,1.5-0.25,0.13,2.7-.15],
                         ['add for common room extra height',1,5*l+2*1.5-0.25,0.25,0.6-.15],
                         ['deduct door1',-2,1.2,0.25,2.1],
                         ['deduct wash opening',-1,l/2-0.25,0.25,2.1],
                         ['urinal doors',-2,0.75,0.13,2.1],
                         ['wc & bath doors',-1,0.75,0.25,2.1],
                         ['deduct window1',-2,1.5,0.25,1.2],
                         ])
brickworkss.rate=fl.brickmasonry(2)[1]
brickworkss.volume()
print('\n',it.items['hysd'],'\n')
print('\t\t\t25.00q @ \u20B9',fl.reinforcement(),'/q = \u20B9',round(25.00*fl.reinforcement(),2))
print('\n',it.items['rscs_plinth'])
plinth=cl.Quantity([['column footings',14,2*(2.0+1.50),0.6],
                    ['plinth beams',3*2,9.50,0.75],
                    ['plinth beams long',4,17.3,0.3],
                    ['plinth beam of K&S',2,19.3,0.25],
                    ['Column footings',6*4,1.0,0.3],
                    ])
plinth.rate=fl.rscs(3)
plinth.vArea()
print('\n',it.items['rscs_beam'])
columns=cl.Quantity([['column pedestals ',16*4,0.45,0.45],                    
                     ['columns upto plinth level', 16*4, 0.25, 1.5-.3-.3-.45+.75],
                     ['columns in s/s', 11*4, 0.25, 3],                     
                     ['R.C.C. beams', 2, l-0.25, 0.3+2*0.25],
                     ])
columns.rate=fl.rscs(2)
columns.vArea()
print('\n',it.items['rscs_lintel'])
lintel=cl.Quantity([['lintel bend',2,tcl-0.5,0.15],
                 ['half brick thick lintel bend',2,1.5,0.15],
                    ['bottom door1', 2, 1.2, 0.25],
                    ['wash bottom', 2, l/2-0.25, 0.25],
                    ['bottom toilet doors', 2, 0.75,0.13],
                    ['bottom window1', 2, 1.5, 0.25],
                    ])
lintel.rate=fl.rscs(4)
lintel.vArea()
print('\n',it.items['rscs_slab'])
slab=cl.Quantity([['chajjas 1',1,l+0.25+2*0.45,0.45],
                 ['chajjas 2',2,l/4+0.75+.15+.13,0.45],                 
                 ['R.C.C. roof bend long',-2,tcl-0.5,0.25],
                 ['R.C.C. roof slab on toilet long',1,l+2*1.5+.25+.3,1.5+.25+.15],
                 ['R.C.C. roof slab on toilet short',2,l/2+.25,1.5+.25+.15],
                 ['R.C.C. slab main',1,l+0.25+.3+1.5,l+0.25+0.3]])
slab.rate=fl.rscs(1)
slab.hArea()

print('\n',it.items['20cp(1:4)'])
gradingplaster=cl.Quantity([['R.C.C. roof bend long',-1,tcl-0.5,0.25],
                 ['R.C.C. roof slab on toilet long',1,l+2*1.5+.25+.3,1.5+.25+.15],
                 ['R.C.C. roof slab on toilet short',2,l/2+.25,1.5+.25+.15],
                 ['R.C.C. slab main',1,l+0.25+.3+1.5,l+0.25+0.3]])
gradingplaster.rate=fl.plaster(4)
gradingplaster.hArea()

print('\n',it.items['16cp(1:6)'])
plaster16=cl.Quantity([['alround walls',1,tcl-0.5,2.7],
                       ['extra height walls',5*l+2*1.5-0.25,0.6],
                         ['deduct door1',-2*.5,1.2,2.1],
                         ['deduct wash opening',-1,l/2-0.25,2.1],
                         ['toilet doors',-2*.5,0.75,2.1],
                         ['deduct window1',-2*.5,1.5,1.2],
                         ['add for plinth area',1,tcl-2*l,0.9]
                       ])
plaster16.rate=fl.plaster(2)
plaster16.vArea()
print('\n',it.items['12cp(1:6)'])
plaster12=cl.Quantity([['alround walls',1,tcl-0.5,2.7],
                       ['extra height walls',5*l+2*1.5-0.25,0.6],
                         ['deduct door1',-2*.5,1.2,2.1],
                         ['deduct wash opening',-1,l/2-0.25,2.1],
                         ['toilet doors',-2*.5,0.75,2.1],
                         ['deduct window1',-2*.5,1.5,1.2],
                         
                       ])
plaster12.rate=fl.plaster(1)
plaster12.vArea()
print('\n',it.items['12cp(1:4)'])
plaster14=cl.Quantity([['half brick thk walls',2,1.5,2.7],])
plaster14.rate=fl.plaster(6)
plaster14.vArea()
print('\n',it.items['6cp(1:4)rcc'])
plaster6=cl.Quantity([['columns in verandah',3*4,0.25,2.1],                      
                      ['chajjas 1',1,l+0.25+2*0.45,0.45],
                 ['chajjas 2',2,l/4+0.75+.15+.13,0.45],                 
                 ['R.C.C. roof slab on toilet long',1,l+2*1.5+.25+.3,1.5+.25+.15],
                 ['R.C.C. roof slab on toilet short',2,l/2+.25,1.5+.25+.15],
                 ['R.C.C. slab main',1,l+0.25+.3+1.5,l+0.25+0.3]])
plaster6.rate=fl.plaster(3)
plaster6.hArea()


print('\n',textwrap.fill('Supplying ,fixing and fitting of M.S. Doors and windows including cost and conveyance = 3.50q @ \u20B97,000.00/q = \u20B924,500.oo',80))
print('\n',textwrap.fill('Supplying and fixing of A.C. sheet doors at toilet 3 nos @ \u20B95,000.00/no = \u20B9 15,000.00'))
print('\n',it.items['asfloor'])
floor=cl.Quantity([['steps treads',2*4,1.5,0.25]])
floor.rate=fl.flooring(1)
floor.hArea()
print('\n',it.items['vitrified'])
floor=cl.Quantity([['hall',1,l-0.25,l-0.25],
                   ['wash area',1,l/2-0.25,1.5]])
floor.rate=fl.vitrifiedtile1()
floor.hArea()
print('\n',it.items['floor tile'])
toiletfloor=cl.Quantity([['toilet floors',1,2.0,1.2],
                         ['urinals',1,l-0.25+1.5*2,1.2]])
toiletfloor.rate=fl.Tile(1)
toiletfloor.hArea()
print('\n',it.items['wall tile'])
walltile=cl.Quantity([['hall sides',1,4*(l-0.25+1.5*4),0.9],
                      ['urinal walls',2,l+1.5-0.25,0.9],
                      ['urinal widths',2,1.2,0.9],
                      ['toilets walls',2,(2+1.2),1.8],
                      ['urinal partitions',2*10,0.9+0.05]])
walltile.rate=fl.Tile(2)
walltile.vArea()
print('\n',it.items['paint'])
doorwindowpaint=cl.Quantity([['Doors1',2*2.25,1.2,2.1],
                             
                             ['windows1',2*2.75,1.5,1.2],
                             ])
doorwindowpaint.rate=fl.painting()
doorwindowpaint.vArea()
print('\n',it.items['wall primer'])
wallprimer=cl.Quantity([['12mm thick (1:6) plaster area',360.33],
                        ['6mm thick plaster area',490.47],
                        ['12mm thick (1:4) plaster area',21.25],
                        ['16mm thick (1:6) plaster area',346.11]
                        ])
wallprimer.rate=fl.priming_one_coat()
wallprimer.quantity(2)
print('\n',it.items['wall putty'])
wallputty=cl.Quantity([['12mm thick (1:6) plaster area',108.23],
                        ['6mm thick plaster area',81.27],
                        ['12mm thick (1:4) plaster area',8.1],
                        ['16mm thick (1:6) plaster area',138.94],
                       ['deduct out side walls plaster',-215.00]])
wallputty.rate=fl.wallputty()
wallputty.quantity(2)
print('\n',it.items['wall_paint1'])
wallpaint=cl.Quantity([['alround walls',1,31.5,3.9],
                       ['deduct for doors',-0.5,1.5,2.1],
                       ['deduct for windows',-10/2,1.5,1.2],
                       ['deduct for windows2',-1,0.9,1.2]])
wallpaint.rate=fl.wallpainting()
wallpaint.vArea()
print('\n',it.items['distemper'])
distemper=cl.Quantity([['12mm thick (1:6) plaster area',108.23],
                        ['6mm thick plaster area',81.27],
                        ['12mm thick (1:4) plaster area',8.1],
                        ['16mm thick (1:6) plaster area',138.94],
                       ['deduct for area of weather coat',-204.11]])
distemper.rate=fl.distempering()
distemper.quantity(2)
#print('\n',it.items['wpcp'])
#wpcp=cl.Quantity([['12mm thick plaster K&S',59.73],
#                 ['16mm thick plaster',69.38],
#                 ['ceiling and chajjas',26.44+3]])
#wpcp.rate=fl.waterproofpaint()
#wpcp.quantity(2)

materials=cl.Quantity([['distemper',33.10,'kg',ls.z['total cost'][21]],
                       ['weather coat',13.9,'ltr',ls.z['total cost'][20]],
                       ['cement based wall putty',97.23,'kg',ls.z['total cost'][24]],
                       ['wall primer',102.36,'ltr',ls.z['total cost'][25]],
                       ['enamel paint',2.66,'ltr',ls.z['total cost'][18]],
                       ['red oxide primer',1.15,'ltr',ls.z['total cost'][17]],
#                       ['water proofing cement paint',39.65,'kg',ls.z['total cost'][22]],
                       ['ceramic glazed wall tile',64.98,'sqm',ls.z['total cost'][16]],
                       ['ceramic glazed floor tile', 12.00, 'sqm', ls.z['total cost'][15]]])
materials.cost_material()
print("\nCess for welfare of labourers =\u20B9 10,000.00 ")
print('\nCost towards display board and photograph & T&P = \u20B95,000.00')
print('\nProvisionl cost towards electrification and sanitation= \u20B9 1,35,641.00')
print('-'*80)
fl.signature(1000000,'Ten lakh only',6,'')




