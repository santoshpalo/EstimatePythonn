import ClassLibrary as cl
import FunctionLibrary as fl
import items as it
import textwrap







if __name__ == "__main__":
    print(textwrap.fill(it.items['efhs'],80,subsequent_indent='        '))
    foundation = cl.Quantity([['extension',1,5.00,0.45,.3]])
    foundation.rate=103.2
    foundation.volume()
    print('\n')
    print(textwrap.fill(it.items['CC(1:3:6)'], 80, subsequent_indent='        '))
    metalcc = cl.Quantity([['waist slab',1,5.00,0.4,0.15],
                           ['steps',10*0.5,0.4,0.45,0.2],
                           ['kerbs',2*10,0.4,0.45,0.2]])
    metalcc.rate = 3625.49
    metalcc.volume()
    print('\n')
    print(textwrap.fill(it.items['CC(1:2:4)'], 80, subsequent_indent='        '))
    crustcc = cl.Quantity([['upper steps',10,4.15,0.45,0.1]])
    crustcc.rate=4740.01
    crustcc.volume()
    print('\n')
    print(textwrap.fill(it.items['rscs_plinth'], 80, subsequent_indent='        '))
    plinth= cl.Quantity([['steps',10,4.15,0.1],
                         ['kerbs',10*2,0.45*2+.4,0.2]])
    plinth.rate=82.15
    plinth.vArea()
    print('Cess for welfare of labourers''= \u20B9{:0.2f}'.format(150))
    print('Departmental contingency''= \u20B9{:0.2f}'.format(150))







