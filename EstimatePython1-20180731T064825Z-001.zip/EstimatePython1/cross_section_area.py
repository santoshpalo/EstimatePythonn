'''
Created on Feb 2, 2017

@author: spalo
'''
import statistics as st
import math as mt
def csa(a,b,c):
    area_triangle1=0.5*b**2/2
    area_triangle2=0.75/3.25*c**2
    mid_area= a*st.mean([b/mt.sqrt(2),c/mt.sqrt(3.25)*1.5])
    return round(area_triangle2+area_triangle1+mid_area,2)
    #===========================================================================
    # return round(area_triangle1+are_triangle2+mid_area,2)
    #===========================================================================
area=[csa(5.18,3.96,4.11)/2,
      csa(3.96, 3.96, 4.27),
      csa(4.57, 3.66, 4.88),
      csa(4.88, 3.66, 5.18),
      csa(4.57, 3.35, 5.49),
      csa(3.96, 3.35, 5.49),
      csa(3.81, 3.35, 6.1),
      csa(3.81, 3.35, 4.42)/2]
print(sum(area))