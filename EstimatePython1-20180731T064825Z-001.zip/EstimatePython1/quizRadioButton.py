import tkinter as tk
root=tk.Tk()
def call(par):
    if par:
        lab2=tk.Label(root,text='Correct',).grid(row=4)
    else:
        lab2=tk.Label(root,text='of course you are wrong!').grid(row=4)
        # lab2=tk.Label(root,text='how could you be so stupid').grid(row=5)
correct=tk.BooleanVar()
rad=tk.Radiobutton(root,text='yes',varaible=correct,value=True)
rad2=tk.Radiobutton(root,text='no',variable=correct,value=False)
lab=tk.Label(root,tex='Is the maker awesome?')
btn=tk.Button(root,text='submit',command=lambda:call(correct.get()))

lab.grid(row=0)
rad.grid(row=2,column=1)
rad2.grid(row=2,column=1)
btn.grid(row=3)
tk.mainloop()