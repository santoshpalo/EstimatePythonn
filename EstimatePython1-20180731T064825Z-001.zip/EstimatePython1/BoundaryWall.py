#!usr/bin/python3.5
import pandas as pd
import ClassLibrary as cl 
import FunctionLibrary
import FunctionLibrary as fl
import items as it
import AnalysisRates as ar
from AnalysisRates import Tamount28
panel = 3*3.35
x= 12





if __name__ == "__main__":
    print("Construction of Boundary wall around Braja Bihari High School, Sankara")
    print('Head of Account :-W.O.D.C. (2016-17)','\t','Estimated Cost:- \u20B94,00,000.00')
    print ('-'*80)
    print(it.items['efhs'])
    foundation = cl.Quantity([['foundation',1,panel*x+0.9,0.9,0.6]])
    foundation.rate = 103.2
    foundation.volume()
    print(it.items['sand_filling'])
    sandfilling = cl.Quantity([['foundation',1,panel*x+0.9,0.9,0.1]])
    sandfilling.rate = 302.62
    sandfilling.volume()
    print(it.items['CC(1:4:8)'])
    concrete = cl.Quantity([['foundation',1,panel*x+0.9,0.9,0.1]])
    concrete.rate = ar.Tamount3
    concrete.volume()
    print(it.items['bmfbfp'])
    brickmasonryFP = cl.Quantity([['foundation 1st footing',1,panel*x+0.65,0.65,0.15],
                                  ['foundation 2nd footing',1,panel*x+0.5,0.5,0.15],
                                  ['foundation 3rd footing',1,panel*x+0.38,0.38,0.45]])
    brickmasonryFP.rate = Tamount28
    brickmasonryFP.volume()
    print(it.items['bmfbss'])
    brickmasonrySS = cl.Quantity([['wall above F & P',1,panel*x+0.25,0.25,1.65],
                                  
                                  ])
    brickmasonrySS.rate = Tamount28+33
    brickmasonrySS.volume()
    print(it.items['12cp(1:6)'])
    plaster12 = cl.Quantity([['one side of wall',1,panel*x,1.65+.35],
                             ['pier projections',x*4,0.13,1.65]])
    plaster12.rate = ar.Tamount19
    plaster12.vArea()
    print(it.items['16cp(1:6)'])
    plaster12 = cl.Quantity([['one side of wall',1,panel*x,1.65+.35],
                             ['pier projections',x*4,0.13,1.65]])
    plaster12.rate = ar.Tamount20
    plaster12.vArea()
    print('\nCost towards Display Board \t\t\t\t\t   = \u20B91,500.00')
    print('\nCess for welfare of labourers\t\t\t\t\t    =\u20B94,000.00')
    print('-'*80)
    fl.signature(400000, 'Rupees four lakhs only', 2, '')
    
    