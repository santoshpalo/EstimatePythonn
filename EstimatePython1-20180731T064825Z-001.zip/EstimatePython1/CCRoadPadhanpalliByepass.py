#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 11 16:36:09 2018

@author: spalo
"""

import ConcreteRoad as cr
import textwrap
import FunctionLibrary as fl
import math as mt
print(textwrap.fill('''Name of the work:- Construction of C.C. road from Padhanpalli Bye-pass road''',80))
print('Head of Account:-G.G.Y.(2017-18)\tEstimated Cost:-\u20B92,00,000.00')
print('-'*80)
road = cr.UniformWidth(58,[3.65,0.9],[0.2,0.1],[.05,0.1,0.1,0.3])
road.foundation()
road.sand_fill()
road.metal_concrete()
road.chips_concrete()
road.vibrator()
road.rscs()
road.earth_mechanical()
road.miscellaneous()
road.cess()
y=mt.ceil((road.foundationR()+road.sand_fillR()+road.metal_concreteR()+road.chips_concreteR()[0]+road.rscsR()+road.earth_mechanicalR()+road.vibratorR()+road.miscellaneousR())*1.01)
print('Total estimated cost = \u20B9','{:.2f}'.format(y),'limited to \u20B9 2,00,000.00')
print('='*80)
fl.signature(200000,'Rupees two lakh only',1,'')