# coding=utf-8
# coding=utf-8
import FunctionLibrary as fl
import items as it
print ('''Excavation of foundation trench in hard soil including dressing
of sides and levelling of bed etc. complete.''')
print (fl.foundation(1),'\n')
print(fl.sandfilling())
print(fl.concrete(2))
print(fl.concrete(3))
#print(fl.brickmasonry(2))
#print(fl.gradedrcc(2))
#print(fl.reinforcement())
#print(fl.rscs(1))
#print(fl.rscs(2))
print(fl.rscs(3))
#print(fl.rscs(4))
#print(fl.rscs(5))
#print(fl.rscs(6))
#print(fl.plaster(1))
#print(fl.plaster(2))
#print(fl.plaster(3))
#print(fl.plaster(4))
#print(fl.plaster(5))
#print(fl.plaster(6))
#print(fl.vitrifiedtile1())
#print(fl.Tile(1))
#print(fl.Tile(2))
#print(fl.distempering())
#print(fl.wallpainting())
#print(fl.painting())

print('\n\nJunior Engineer\t\t Assistant Engineer\t\tBlock Development Officer')
print('Binka Block Ofiice\tBinka Block Office\t\t\tBinka')
