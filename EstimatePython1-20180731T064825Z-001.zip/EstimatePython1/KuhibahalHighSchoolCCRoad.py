import ClassLibrary as cl
import math as mt
import items as it
print('Circular surface area of the road at the front')
circular_area=[['external circle',1,mt.pi,12.65],
               ['internal circle',-1,mt.pi,5.5]]
print(cl.Quantity(circular_area).circular_surfaceArea()['y0'],'\n The area of circular concrete road', cl.Quantity(circular_area).circular_surfaceArea()['y1'])
print('Circular area opf cut-off wall')
circular_area_cutoff=[['external circle1',1,mt.pi,12.65],
['external circle 2',-1,mt.pi,12.25],
['internal circle1',1,mt.pi,5.1],
               ['internal circle 2',-1,mt.pi,5.5]]
print(cl.Quantity(circular_area_cutoff).circular_surfaceArea()['y0'],'\n The area of circular cut-off wall of road', cl.Quantity(circular_area_cutoff).circular_surfaceArea()['y1'])
print('Surface Area of rectangular roads')
rectangularpatches=[['patch 1',1,5,4.45],
                   ['patch2',1,18.9,3.85],
                   ['patch3',1,10.3,3.65],
                   ['patch4',1,18.34,3.73],
                   ['patch5',1,10.54,3.8],
                   ['patch6',1,3.65,1.5],
                   ['patch7',1,1.95,1.95],
                   ['patch8',1,4.35,4],
                   ['patch9',1,2.5,1.35],
                   ['patch10',1,3.1,0.9],
                    ['patch11',1,2.75,1.8],
                   ['triangular patch1',1,2.4,1.2],
                   ['triangular patch2',1,1.35,1.35],
                   ['triangular patch3',0.5,3.35,2.75],
                   ['patch12',1,3.5,3.0]]
rectangularpatches=cl.Quantity(rectangularpatches)
rectangularpatches.surface_area()
cut_offArea=[['patch1',2,5.0,0.2],
             ['patch2',1,18.9+11.4,0.2],
             ['patch3',1,10.3*2+7.57,0.2],
             ['patch4',1,18.34+18.34-7.65,0.2],
             ['patch5',1,18.1*2-7.4,0.2],
             ['patch6',2,1.5,0.2],
             ['patch7',2,1.8,0.2],
             ['patch8',1,6.53,2],
             ['patch12',2,3.0,0.2]]
cut_offArea=cl.Quantity(cut_offArea)
cut_offArea.hArea()
print(it.items['efhs'])
foundation=[['circular cut-off',4.49,0.2],
            ['reactangular area cut-off',40.84,0.2],
            ]
foundation=cl.Quantity(foundation)
foundation.rate=100
foundation.areaVolume()
sandfill=[['circular surface area',101.92-4.49,0.05],
          ['rectangular surface area',298.68-40.84,.05]]
sandfill=cl.Quantity(sandfill)
sandfill.rate=100
sandfill.areaVolume()
print(it.items['CC(1:3:6)'])
cc136=[['circular surface area',101.92-4.49,0.1],
          ['rectangular surface area',298.68-40.84,.1],
       ['circular cut off wall',4.49,0.25],
       ['rectangular cut-off wall',40.84,0.25]]
cc136=cl.Quantity(cc136)
cc136.rate=100
cc136.areaVolume()
print(it.items['CC(1:3:6)'])
cc124=[['circular surface area',101.92-4.49,0.1],
          ['rectangular surface area',298.68-40.84,.1],
       ]
cc124=cl.Quantity(cc124)
cc124.rate=100
cc124.areaVolume()
print('Hire and running charges of plate vibrator')
print('\n\n\n14.20hour @\u20B9106.00/hour = \u20B91505.00')
print(it.items['rscs_plinth'])
rscs1=[['external circle1',1,mt.pi,12.65,.25],
['external circle 2',1,mt.pi,12.25,.05],
['internal circle1',1,mt.pi,5.1,.25],
               ['internal circle 2',1,mt.pi,5.5,.05]]
rscs1=cl.Quantity(rscs1)
rscs1.rate=100
rscs1.circular_verticalArea()
rscs2=[['patch1',2,5.0,0.3],
             ['patch2',1,18.9+11.4,0.3],
             ['patch3',1,10.3*2+7.57,0.3],
             ['patch4',1,18.34+18.34-7.65,0.3],
             ['patch5',1,18.1*2-7.4,0.3],
             ['patch6',2,1.5,0.3],
             ['patch7',2,1.8,0.3],
             ['patch8',1,6.53,3],
             ['patch12',2,3.0,0.3]]
rscs2=cl.Quantity(rscs2)
rscs2.rate=100
rscs2.vArea()




