import numpy as np
import matplotlib
import tkinter
from tkinter import *
import matplotlib.pyplot as plt
matplotlib.use("TkAgg")
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

class mclass:
    def __init__(self,window):
        # self.box = Entry(window)
        self.button = Button(window,text="check",command = self.plott)
        # self.box.pack()
        self.button.pack()
    def plott(self):
        x=np.array([1,2,3,4,5,6,7,8])
        v=np.array([16,16.31925,17.6394,17.3131,19.1259,18.9694,22.0003,22.81226])
        p=np.array([16.23697,17.31653,17.22094,17.68631,17.73641,18.6368,19.32125,19.31756])

        plt.scatter(v,x,color='red')
        plt.plot(p,range(8),color = 'blue')
        plt.gca().invert_yaxis()

        plt.suptitle("Estimation Grid",fontsize=16)
        plt.ylabel("Y",fontsize=14)
        plt.xlabel("X",fontsize = 14)
        plt.show()
        plt.gcf().canvas.draw()
        fig=plt.figure()
        canvas = FigureCanvasAgg(fig,master = window)
        canvas.get_widget().grid(row=1,column=50)
        canvas.draw()

window = Tk()
start = mclass(window)
window.title('Halliday Resnick Walker',fontsize=20)
window.mainloop()

