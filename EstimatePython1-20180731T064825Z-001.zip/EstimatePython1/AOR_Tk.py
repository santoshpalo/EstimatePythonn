import pandas as pd
import items as it
import LeadStatementGST as ls1
from tkinter import *
import textwrap
u_s =ls1.u_s
class Concrete:
    def __init__(self,master):
        frame = Frame(master)
        frame.pack()
        self.Label = Label(frame, text = 'Concrete')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.concrete1 = Button(frame,text = "concrete(1:4:8)",command = self.concrete148)
        self.concrete1.pack(side=LEFT)
        self.concrete2 = Button(frame, text="concrete(1:3:6)", command=self.concrete136)
        self.concrete2.pack(side=LEFT)
        self.concrete3 = Button(frame, text="concrete(1:2:4)", command=self.concrete124)
        self.concrete3.pack(side=LEFT)
        self.concrete4 = Button(frame, text="concrete(1:1.5:3)", command=self.concrete123)
        self.concrete4.pack(side=LEFT)
    def concrete148(self):
        d1 = {'quantity': [3.9, 0.18], 'rate': [u_s, 253.5]}
        d2 = {'quantity': [1.72], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [0.96, 0.48], 'rate': [ls1.z['total cost'][11], ls1.z['total cost'][2]]}
        i1 = ['unskilled labour', 'mason II']
        i2 = ['cement']
        i3 = ['40mm h.g. metal', 'fine sand']
        table1 = pd.DataFrame(d1, index=i1, columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=i2, columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=i3, columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.2f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.2f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}cum'.format)

        table4 = table1.append(table2).append(table3)
        table4.tamount = (table4['amount'].sum())
        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['CC(1:4:8)'], '\n', table4, '\n\tCost for 1.00cum of concrete= ',
               'Rs.{:.2f}'.format(table4.tamount) )
    def concrete136(self):
        d1 = {'quantity': [3.9, 0.18], 'rate': [u_s, 253.5]}
        d2 = {'quantity': [2.29], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [0.96, 0.48], 'rate': [ls1.z['total cost'][11], ls1.z['total cost'][2]]}
        i1 = ['unskilled labour', 'mason II']
        i2 = ['cement']
        i3 = ['40mm h.g. metal', 'fine sand']
        table1 = pd.DataFrame(d1, index=i1, columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=i2, columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=i3, columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.2f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.2f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}cum'.format)

        table4 = table1.append(table2).append(table3)
        table4.tamount = (table4['amount'].sum())
        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['CC(1:3:6)'], '\n', table4, '\n\tCost for 1.00cum of concrete= ',
              'Rs.{:.2f}'.format(table4.tamount) )

    def concrete124(self):
        d1 = {'quantity': [4.6, 0.68], 'rate': [u_s, 253.5]}
        d2 = {'quantity': [3.23], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [0.90, 0.45], 'rate': [ls1.z['total cost'][9], ls1.z['total cost'][4]]}
        i1 = ['unskilled labour', 'mason II']
        i2 = ['cement']
        i3 = ['12mm c.b.g. chips', 'fine sand']
        table1 = pd.DataFrame(d1, index=i1, columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=i2, columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=i3, columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.2f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.2f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}cum'.format)

        table4 = table1.append(table2).append(table3)
        table4.tamount = (table4['amount'].sum())
        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['CC(1:2:4)'], '\n', table4, '\n\tCost for 1.00cum of concrete= ',
               'Rs.{:.2f}'.format(table4.tamount) )
    def concrete123(self):
        d1 = {'quantity': [4.6, 0.68], 'rate': [u_s, 253.5]}
        d2 = {'quantity': [4.29], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [0.90, 0.45], 'rate': [ls1.z['total cost'][11], ls1.z['total cost'][4]]}
        i1 = ['unskilled labour', 'mason II']
        i2 = ['cement']
        i3 = ['12mm c.b.g. chips', 'fine sand']
        table1 = pd.DataFrame(d1, index=i1, columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=i2, columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=i3, columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.2f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.2f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}cum'.format)

        table4 = table1.append(table2).append(table3)
        table4.tamount = (table4['amount'].sum())
        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['rcc'], '\n', table4, '\n\tCost for 1.00cum of concrete= ',
               'Rs.{:.2f}'.format(table4.tamount))


root = Tk()
# root.title = 'Concrete'
app = Concrete(root)
root.mainloop()
#===========
class RCC:
    def __init__(self, master):
        frame = Frame(master)
        frame.pack()
        self.Label = Label(frame, text='Graded Concrete')
        self.Label.pack(side=TOP)
        self.button = Button(frame, text='QUIT', fg="red", command=quit)
        self.button.pack(side=LEFT)
        self.rcc1 = Button(frame, text="R.C.C. M-20", command=self.rccm20)
        self.rcc1.pack(side=LEFT)
    def rccm20(self):
        m=5.21*10/15

        table1 = pd.DataFrame({'quantity': [20.0 / 15, 0.86 / 15, 1.5 / 15], 'rate': [u_s, 233.5, 253.5]},
                              index=['unskilled labour', 'semiskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table2 = pd.DataFrame({'quantity': [m], 'rate': [ls1.z['total cost'][4]]}, index=['cement'],
                              columns=['quantity', 'rate'])
        table3 = pd.DataFrame({'quantity': [0.54, 0.36, 0.45],
                               'rate': [ls1.z['total cost'][10], ls1.z['total cost'][8], ls1.z['total cost'][2]]},
                              index=['20mm chips', '10mm chips', 'sand'], columns=['quantity', 'rate'])
        table4 = pd.DataFrame({'quantity': [0.4], 'rate': [177, 253.5]}, index=['concrete mixer', 'generator'],
                              columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table4['amount'] = table4['quantity'] * table4['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.2f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.4f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}cum'.format)
        table4['quantity'] = table4['quantity'].map('{:.1f}hr'.format)

        table = table1.append(table2).append(table3).append(table4)
        tamount = table.amount.sum()
        table['rate'] = table['rate'].map('Rs. {:.2f}'.format)
        table['amount'] = table['amount'].map('Rs. {:.2f}'.format)
        print(it.items['m20'], '\n', table, '\nRate of 1 cum of M-20 graded concrete=',
              'Rs.{:.2f}'.format(tamount) )

root = Tk()
# root.title = 'Graded Concrete'
app = RCC(root)
root.mainloop()


#=======
class Plaster:
    def __init__(self,master):
        frame = Frame(master)
        frame.pack()
        self.Label = Label(frame, text='Plaster')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.plaster1 = Button(frame,text = "12mm plaster(1:6)",command = self.plaster12mm_16)
        self.plaster1.pack(side=LEFT)
        self.plaster2 = Button(frame, text="12mm plaster(1:4)", command=self.plaster12mm_14)
        self.plaster2.pack(side=LEFT)
        self.plaster3 = Button(frame, text="12mm plaster(1:4) punning",command=self.plaster12mm_14_punning)
        self.plaster3.pack(side=LEFT)
        self.plaster4 = Button(frame, text="16mm plaster(1:6)", command=self.plaster16mm_16)
        self.plaster4.pack(side=LEFT)
        self.plaster5 = Button(frame, text="20mm plaster(1:6)", command=self.plaster20mm_16)
        self.plaster5.pack(side=LEFT)
        self.plaster6 = Button(frame, text="6mm plaster(1:4)", command=self.plaster6mm_14)
        self.plaster6.pack(side=LEFT)
        self.plaster7 = Button(frame, text="6mm plaster(1:4)rcc", command=self.plaster6mm_14_rcc)
        self.plaster7.pack(side=LEFT)
        self.plaster8 = Button(frame, text="20mm plaster(1:4)rcc", command=self.plaster20mm_14)
        self.plaster8.pack(side=LEFT)
    def plaster12mm_16(self):
        d1 = {'quantity': [0.12, 0.14], 'rate': [u_s, 253.5]}
        d2 = {'quantity': [.0358], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [.015], 'rate': [ls1.z['total cost'][2]]}
        table1 = pd.DataFrame(d1, index=['unskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=['cement'], columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=['sand'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.4f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.4f}cum'.format)
        table4 = table1.append(table2).append(table3)
        table4.tamount = (table4['amount'].sum())

        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['12cp(1:6)'], '\n', table4, '\n\tCost for 1.00sqm of plaster area = ',
               'Rs.{:.2f}'.format(table4.tamount) )
    def plaster12mm_14(self):
        d1 = {'quantity': [0.12, 0.14], 'rate': [u_s, 253.5]}
        d2 = {'quantity': [.0543], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [.015], 'rate': [ls1.z['total cost'][2]]}
        table1 = pd.DataFrame(d1, index=['unskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=['cement'], columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=['sand'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.4f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.4f}cum'.format)
        table4 = table1.append(table2).append(table3)
        table4.tamount = (table4['amount'].sum())

        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['12cp(1:4)'], '\n', table4, '\n\tCost for 1.00sqm of plaster area = ',
               'Rs.{:.2f}'.format(table4.tamount) )
    def plaster12mm_14_punning(self):
        d1 = {'quantity': [0.11, 0.15], 'rate': [u_s, 253.5]}
        d2 = {'quantity': [.0644], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [.015], 'rate': [ls1.z['total cost'][2]]}
        table1 = pd.DataFrame(d1, index=['unskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=['cement'], columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=['sand'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.4f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.4f}cum'.format)
        table4 = table1.append(table2).append(table3)
        table4.tamount = (table4['amount'].sum())

        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['12cp(1:4)punning'], '\n', table4, '\n\tCost for 1.00sqm of plaster area = ',
               'Rs.{:.2f}'.format(table4.tamount) )
    def plaster16mm_16(self):
        d1 = {'quantity': [0.16, 0.24], 'rate': [u_s, 253.5]}
        d2 = {'quantity': [.043], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [.018], 'rate': [ls1.z['total cost'][2]]}
        table1 = pd.DataFrame(d1, index=['unskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=['cement'], columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=['sand'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.4f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.4f}cum'.format)
        table4 = table1.append(table2).append(table3)
        table4.tamount = (table4['amount'].sum())

        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['16cp(1:6)'], '\n', table4, '\n\tCost for 1.00sqm of plaster area = ',
               'Rs.{:.2f}'.format(table4.tamount) )
    def plaster20mm_16(self):
        d1 = {'quantity': [0.24, 0.16], 'rate': [u_s, 253.5]}
        d2 = {'quantity': [.057], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [.021], 'rate': [ls1.z['total cost'][2]]}
        table1 = pd.DataFrame(d1, index=['unskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=['cement'], columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=['sand'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.4f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.4f}cum'.format)
        table4 = table1.append(table2).append(table3)
        table4.tamount = (table4['amount'].sum())

        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['20cp(1:6)'], '\n', table4, '\n\tCost for 1.00sqm of plaster area = ',
               'Rs.{:.2f}'.format(table4.tamount) )
    def plaster20mm_14(self):
        d1 = {'quantity': [0.24, 0.16], 'rate': [u_s, 253.5]}
        d2 = {'quantity': [.0744], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [.021], 'rate': [ls1.z['total cost'][2]]}
        table1 = pd.DataFrame(d1, index=['unskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=['cement'], columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=['sand'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.4f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.4f}cum'.format)
        table4 = table1.append(table2).append(table3)
        table4.tamount = (table4['amount'].sum())

        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['20cp(1:4)'], '\n', table4, '\n\tCost for 1.00sqm of plaster area = ',
               'Rs.{:.2f}'.format(table4.tamount) )
    def plaster6mm_14(self):
        d1 = {'quantity': [0.12, 0.14], 'rate': [u_s, 253.5]}
        d2 = {'quantity': [.0271], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [.0075], 'rate': [ls1.z['total cost'][2]]}
        table1 = pd.DataFrame(d1, index=['unskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=['cement'], columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=['sand'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.4f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.4f}cum'.format)
        table4 = table1.append(table2).append(table3)
        table4.tamount = (table4['amount'].sum())

        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['6cp(1:4)'], '\n', table4, '\n\tCost for 1.00sqm of plaster area = ',
               'Rs.{:.2f}'.format(table4.tamount) )
    def plaster6mm_14_rcc(self):
        d1 = {'quantity': [0.12, 0.14], 'rate': [u_s, 253.5]}
        d2 = {'quantity': [.0271], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [.0075], 'rate': [ls1.z['total cost'][2]]}
        table1 = pd.DataFrame(d1, index=['unskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=['cement'], columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=['sand'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.4f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.4f}cum'.format)
        table4 = table1.append(table2).append(table3)
        table4.tamount = (table4['amount'].sum())

        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['6cp(1:4)rcc'], '\n', table4, '\n\tCost for 1.00sqm of plaster area = ',
               'Rs.{:.2f}'.format(table4.tamount) )

root = Tk()
root.title = 'Plaster'
app = Plaster(root)
root.mainloop()
#======
class Sand_filling:
    def __init__(self, master):
        frame = Frame(master)
        frame.pack()
        self.Label = Label(frame, text='Concrete')
        self.Label.pack(side=TOP)
        self.button = Button(frame, text='QUIT', fg="red", command=quit)
        self.button.pack(side=LEFT)
        self.foundation = Button(frame, text="Excavation of foundation", command=self.foundation)
        self.foundation.pack(side=LEFT)
        self.sandfilling = Button(frame, text="Sand Filling", command=self.sandfilling)
        self.sandfilling.pack(side=LEFT)
    def foundation(self):
        d1 = {'quantity': [0.43*1.2], 'rate': [u_s]}
        i1 = ['unskilled labour']
        table1 = pd.DataFrame(d1, index=i1, columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)


        table4 = table1
        table4.tamount = (table4['amount'].sum())
        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['efhs'], '\n', table4, '\n\tCost for 1.00cum of sand filling = ',
              'Rs.{:.2f}'.format(table4.tamount))


    def sandfilling(self):
        d1 = {'quantity': [0.1236], 'rate': [u_s]}

        d3 = {'quantity': [1.0], 'rate': [ ls1.z['total cost'][3]]}
        i1 = ['unskilled labour']
        i3= ['filling sand']

        table1 = pd.DataFrame(d1, index=i1, columns=['quantity', 'rate'])

        table3 = pd.DataFrame(d3, index=i3, columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)

        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)

        table3['quantity'] = table3['quantity'].map('{:.2f}cum'.format)

        table4 = table1.append(table3)
        table4.tamount = (table4['amount'].sum())
        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['sand_filling'], '\n', table4, '\n\tCost for 1.00cum of sand filling = ',
              'Rs.{:.2f}'.format(table4.tamount))
root = Tk()
root.title = 'Sand Filling'
app = Sand_filling(root)
root.mainloop()

#rIGID AND SMOOTH CENTERING AND SHUTTERING
class RSCS:
    def __init__(self,master):
        frame = Frame(master)
        frame.pack()
        self.Label = Label(frame, text='CENTERING & SHUTTERING')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.plaster1 = Button(frame,text = "RSCS_FOOTING",command = self.rscs_footing)
        self.plaster1.pack(side=LEFT)
        self.plaster2 = Button(frame, text="RSCS_SLAB", command=self.rscs_slab)
        self.plaster2.pack(side=LEFT)
        self.plaster3 = Button(frame, text="RSCS_LINTEL",command=self.rscs_lintel)
        self.plaster3.pack(side=LEFT)
        self.plaster4 = Button(frame, text="RSCS_COLUMN", command=self.rscs_column)
        self.plaster4.pack(side=LEFT)
        self.plaster5 = Button(frame, text="RSCS_WALL", command=self.rscs_wall)
        self.plaster5.pack(side=LEFT)
        self.plaster6 = Button(frame, text="RSCS_STAIRCASE", command=self.rscs_staircase)
        self.plaster6.pack(side=LEFT)

    def rscs_footing(self):
        d1 = {'quantity': [0, 0, 0, 12.6], 'rate': [104, 60, 104, 49]}
        d2 = {'quantity': [0, .267, .3284], 'rate': [19650, 19650, ls1.z['total cost'][6]]}
        d3 = {'quantity': [0.5, 0.5], 'rate': [233.5, 253.5]}
        s = 10
        table1 = pd.DataFrame(d1, index=['120mm dia sal bullah', '120mm dia nonsal bullan', '80mm dia sal bullan',
                                         '70mm dia nonsal bullah'], columns=['quantity', 'rate'])
        table1 = table1[table1.quantity != 0]
        table2 = pd.DataFrame(d2, index=['nonsal wood scantling', '38mm/25mm nonsal planks', 'conveyance'],
                              columns=['quantity', 'rate'])
        table2 = table2[table2.quantity != 0]

        table3 = pd.DataFrame(d3, index=['semiskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate']
        table3['amount'] = table3['quantity'] * table3['rate']

        tamount1 = table3['amount'].sum()
        table1['quantity'] = table1['quantity'].map('{:.3f}m'.format)
        table2['quantity'] = table2['quantity'].map('{:.3f}cum'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}no'.format)
        table4 = table1.append(table2)
        tamount2 = table4['amount'].sum()
        table3['rate'] = table3['rate'].map('Rs.{:.2f}'.format)
        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table3['amount'] = table3['amount'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['rscs_plinth'], '\n', table4, '\n', 'Cost for ten time use of materials =', '\t\t', 'Rs.{:.2f}'.format(tamount2), \
              '\nCost for one time use of materials =', '\t\t', 'Rs.{:.2f}'.format(tamount2 / 10), '\n', table3,
              '\nLabour charges =', 'Rs.{:.2f}'.format(tamount1), \
              '\nGross cost for', s, ' sqm of area = ', 'Rs.{:.2f}'.format(tamount2 / 10 + tamount1), '\n',
              'For one time use for 1.0 sqm of area cost =', 'Rs.{:.2f}'.format((tamount2 / 10 + tamount1) / s))
    def rscs_slab(self):
        d1 = {'quantity': [56, 0, 0, 0], 'rate': [104, 60, 104, 49]}
        d2 = {'quantity': [.112, .34, 1.142], 'rate': [19650, 19650, ls1.z['total cost'][6]]}
        d3 = {'quantity': [2.75, 2.75], 'rate': [233.5, 253.5]}
        s = 9.0
        table1 = pd.DataFrame(d1, index=['120mm dia sal bullah', '120mm dia nonsal bullan', '80mm dia sal bullan',
                                         '70mm dia nonsal bullah'], columns=['quantity', 'rate'])
        table1 = table1[table1.quantity != 0]
        table2 = pd.DataFrame(d2, index=['nonsal wood scantling', '38mm/25mm nonsal planks', 'conveyance'],
                              columns=['quantity', 'rate'])
        table2 = table2[table2.quantity != 0]

        table3 = pd.DataFrame(d3, index=['semiskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate']
        table3['amount'] = table3['quantity'] * table3['rate']

        tamount1 = table3['amount'].sum()
        table1['quantity'] = table1['quantity'].map('{:.3f}m'.format)
        table2['quantity'] = table2['quantity'].map('{:.3f}cum'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}no'.format)
        table4 = table1.append(table2)
        tamount2 = table4['amount'].sum()
        table3['rate'] = table3['rate'].map('Rs.{:.2f}'.format)
        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table3['amount'] = table3['amount'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['rscs_slab'], '\n', table4, '\n', 'Cost for ten time use of materials =', '\t\t',
              'Rs.{:.2f}'.format(tamount2), \
              '\nCost for one time use of materials =', '\t\t', 'Rs.{:.2f}'.format(tamount2 / 10), '\n', table3,
              '\nLabour charges =', 'Rs.{:.2f}'.format(tamount1), \
              '\nGross cost for', s, ' sqm of area = ', 'Rs.{:.2f}'.format(tamount2 / 10 + tamount1), '\n',
              'For one time use for 1.0 sqm of area cost =', 'Rs.{:.2f}'.format((tamount2 / 10 + tamount1) / s))
    def rscs_lintel(self):
        d1 = {'quantity': [0, 21, 0, 0], 'rate': [104, 60, 104, 49]}
        d2 = {'quantity': [0, .413, 0.689], 'rate': [19650, 19650, ls1.z['total cost'][6]]}
        d3 = {'quantity': [1.25], 'rate': [233.5, 253.5]}
        s = 7.8
        table1 = pd.DataFrame(d1, index=['120mm dia sal bullah', '120mm dia nonsal bullan', '80mm dia sal bullan',
                                         '70mm dia nonsal bullah'], columns=['quantity', 'rate'])
        table1 = table1[table1.quantity != 0]
        table2 = pd.DataFrame(d2, index=['nonsal wood scantling', '38mm/25mm nonsal planks', 'conveyance'],
                              columns=['quantity', 'rate'])
        table2 = table2[table2.quantity != 0]

        table3 = pd.DataFrame(d3, index=['semiskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate']
        table3['amount'] = table3['quantity'] * table3['rate']

        tamount1 = table3['amount'].sum()
        table1['quantity'] = table1['quantity'].map('{:.3f}m'.format)
        table2['quantity'] = table2['quantity'].map('{:.3f}cum'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}no'.format)
        table4 = table1.append(table2)
        tamount2 = table4['amount'].sum()
        table3['rate'] = table3['rate'].map('Rs.{:.2f}'.format)
        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table3['amount'] = table3['amount'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['rscs_lintel'], '\n', table4, '\n', 'Cost for ten time use of materials =', '\t\t',
              'Rs.{:.2f}'.format(tamount2), \
              '\nCost for one time use of materials =', '\t\t', 'Rs.{:.2f}'.format(tamount2 / 10), '\n', table3,
              '\nLabour charges =', 'Rs.{:.2f}'.format(tamount1), \
              '\nGross cost for', s, ' sqm of area = ', 'Rs.{:.2f}'.format(tamount2 / 10 + tamount1), '\n',
              'For one time use for 1.0 sqm of area cost =', 'Rs.{:.2f}'.format((tamount2 / 10 + tamount1) / s))
    def rscs_column(self):
        d1 = {'quantity': [15.2, 0, 8, 0], 'rate': [104, 60, 104, 49]}
        d2 = {'quantity': [.218, 0, 0.456], 'rate': [19650, 19650, ls1.z['total cost'][6]]}
        d3 = {'quantity': [2.75, 2.75], 'rate': [233.5, 253.5]}
        s = 4.2
        table1 = pd.DataFrame(d1, index=['120mm dia sal bullah', '120mm dia nonsal bullan', '80mm dia sal bullan',
                                         '70mm dia nonsal bullah'], columns=['quantity', 'rate'])
        table1 = table1[table1.quantity != 0]
        table2 = pd.DataFrame(d2, index=['nonsal wood scantling', '38mm/25mm nonsal planks', 'conveyance'],
                              columns=['quantity', 'rate'])
        table2 = table2[table2.quantity != 0]

        table3 = pd.DataFrame(d3, index=['semiskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate']
        table3['amount'] = table3['quantity'] * table3['rate']

        tamount1 = table3['amount'].sum()
        table1['quantity'] = table1['quantity'].map('{:.3f}m'.format)
        table2['quantity'] = table2['quantity'].map('{:.3f}cum'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}no'.format)
        table4 = table1.append(table2)
        tamount2 = table4['amount'].sum()
        table3['rate'] = table3['rate'].map('Rs.{:.2f}'.format)
        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table3['amount'] = table3['amount'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['rscs_beam'], '\n', table4, '\n', 'Cost for ten time use of materials =', '\t\t',
              'Rs.{:.2f}'.format(tamount2), \
              '\nCost for one time use of materials =', '\t\t', 'Rs.{:.2f}'.format(tamount2 / 10), '\n', table3,
              '\nLabour charges =', 'Rs.{:.2f}'.format(tamount1), \
              '\nGross cost for', s, ' sqm of area = ', 'Rs.{:.2f}'.format(tamount2 / 10 + tamount1), '\n',
              'For one time use for 1.0 sqm of area cost =', 'Rs.{:.2f}'.format((tamount2 / 10 + tamount1) / s))
    def rscs_wall(self):
        d1 = {'quantity': [0, 100.8, 0, 0], 'rate': [104, 60, 104, 49]}
        d2 = {'quantity': [.269, .954, 2.461], 'rate': [19650, 19650, ls1.z['total cost'][6]]}
        d3 = {'quantity': [13.5], 'rate': [233.5, 253.5]}
        s = 23.9
        table1 = pd.DataFrame(d1, index=['120mm dia sal bullah', '120mm dia nonsal bullan', '80mm dia sal bullan',
                                         '70mm dia nonsal bullah'], columns=['quantity', 'rate'])
        table1 = table1[table1.quantity != 0]
        table2 = pd.DataFrame(d2, index=['nonsal wood scantling', '38mm/25mm nonsal planks', 'conveyance'],
                              columns=['quantity', 'rate'])
        table2 = table2[table2.quantity != 0]

        table3 = pd.DataFrame(d3, index=['semiskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate']
        table3['amount'] = table3['quantity'] * table3['rate']

        tamount1 = table3['amount'].sum()
        table1['quantity'] = table1['quantity'].map('{:.3f}m'.format)
        table2['quantity'] = table2['quantity'].map('{:.3f}cum'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}no'.format)
        table4 = table1.append(table2)
        tamount2 = table4['amount'].sum()
        table3['rate'] = table3['rate'].map('Rs.{:.2f}'.format)
        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table3['amount'] = table3['amount'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['rscs_walls'], '\n', table4, '\n', 'Cost for ten time use of materials =', '\t\t',
              'Rs.{:.2f}'.format(tamount2), \
              '\nCost for one time use of materials =', '\t\t', 'Rs.{:.2f}'.format(tamount2 / 10), '\n', table3,
              '\nLabour charges =', 'Rs.{:.2f}'.format(tamount1), \
              '\nGross cost for', s, ' sqm of area = ', 'Rs.{:.2f}'.format(tamount2 / 10 + tamount1), '\n',
              'For one time use for 1.0 sqm of area cost =', 'Rs.{:.2f}'.format((tamount2 / 10 + tamount1) / s))
    def rscs_staircase(self):
        d1 = {'quantity': [0, 6.5, 0, 0], 'rate': [104, 60, 104, 49]}
        d2 = {'quantity': [0.039, .228, 0.35], 'rate': [19650, 19650, ls1.z['total cost'][6]]}
        d3 = {'quantity': [2.75], 'rate': [233.5, 253.5]}
        s = 5
        table1 = pd.DataFrame(d1, index=['120mm dia sal bullah', '120mm dia nonsal bullan', '80mm dia sal bullan',
                                         '70mm dia nonsal bullah'], columns=['quantity', 'rate'])
        table1 = table1[table1.quantity != 0]
        table2 = pd.DataFrame(d2, index=['nonsal wood scantling', '38mm/25mm nonsal planks', 'conveyance'],
                              columns=['quantity', 'rate'])
        table2 = table2[table2.quantity != 0]

        table3 = pd.DataFrame(d3, index=['semiskilled labour', 'mason II'], columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate']
        table3['amount'] = table3['quantity'] * table3['rate']

        tamount1 = table3['amount'].sum()
        table1['quantity'] = table1['quantity'].map('{:.3f}m'.format)
        table2['quantity'] = table2['quantity'].map('{:.3f}cum'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}no'.format)
        table4 = table1.append(table2)
        tamount2 = table4['amount'].sum()
        table3['rate'] = table3['rate'].map('Rs.{:.2f}'.format)
        table4['rate'] = table4['rate'].map('Rs.{:.2f}'.format)
        table3['amount'] = table3['amount'].map('Rs.{:.2f}'.format)
        table4['amount'] = table4['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['rscs_stair'], '\n', table4, '\n', 'Cost for ten time use of materials =', '\t\t',
              'Rs.{:.2f}'.format(tamount2), \
              '\nCost for one time use of materials =', '\t\t', 'Rs.{:.2f}'.format(tamount2 / 10), '\n', table3,
              '\nLabour charges =', 'Rs.{:.2f}'.format(tamount1), \
              '\nGross cost for', s, ' sqm of area = ', 'Rs.{:.2f}'.format(tamount2 / 10 + tamount1), '\n',
              'For one time use for 1.0 sqm of area cost =', 'Rs.{:.2f}'.format((tamount2 / 10 + tamount1) / s))

root = Tk()
root.title = 'CENTERING'
app = RSCS(root)
root.mainloop()
#Stone Masonry
class StoneMasonry:
    def __init__(self,master):
        frame = Frame(master)
        frame.pack()
        self.Label = Label(frame, text = 'Stone Masonry')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.concrete1 = Button(frame,text = "CRHG(1:6)",command = self.CRHG_Masonry16)
        self.concrete1.pack(side=LEFT)
        self.concrete2 = Button(frame, text="RRHG(1:6)", command=self.RRHG_Masonry16)
        self.concrete2.pack(side=LEFT)
        # self.concrete3 = Button(frame, text="concrete(1:2:4)", command=self.concrete124)
        # self.concrete3.pack(side=LEFT)
        # self.concrete4 = Button(frame, text="concrete(1:1.5:3)", command=self.concrete123)
        #
        # self.concrete4.pack(side=LEFT)
    def CRHG_Masonry16(self):
        d1 = {'quantity': [1.41+.25,1.41, 1.41, 0.35+2.47], 'rate': [u_s, 233.5,253.5, 273.5]}
        d2 = {'quantity': [0.572], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [0.24], 'rate': [ls1.z['total cost'][2]]}

        d4 = {'quantity': [1], 'rate': [ls1.z['total cost'][7]]}
        i1 = ['unskilled labour','semi skilled labour', 'mason II', 'mason I']
        i2 = ['cement']
        i3 = ['fine sand']
        i4 = ['c.b. bricks']
        table1 = pd.DataFrame(d1, index=i1, columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=i2, columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=i3, columns=['quantity', 'rate'])
        table4 = pd.DataFrame(d4, index=i4, columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table4['amount'] = table4['quantity'] * table4['rate'].round(2)
        # table1['quantity']=table1['quantity'].map('{:.0f}no'.format)
        # table2['quantity']=table2['quantity'].map('{:.2f}qtl'.format)
        # table3['quantity']=table3['quantity'].map('{:.2f}cum'.format)
        table1['quantity'] = table1['quantity'].map('{:.2f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.3f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}cum'.format)
        table4['quantity'] = table4['quantity'].map('{:.2f}no'.format)

        table5 = table1.append(table2).append(table3).append(table4)
        table5.tamount = (table5)['amount'].sum()

        # table1['quantity']=table1['quantity'].map('{:.0f}no'.format)
        # table2['quantity']=table2['quantity'].map('{:.2f}qtl'.format)
        # table3['quantity']=table3['quantity'].map('{:.2f}cum'.format)



        table5['rate'] = table5['rate'].map('Rs.{:.2f}'.format)
        table5['amount'] = table5['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['CRHG_(1:6)'], '\n', table5, '\n\tCost for 1.00cum of stone masonry masonry= ',
              'Rs.{:.2f}'.format(table5.tamount))
    def RRHG_Masonry16(self):
        d1 = {'quantity': [1.41*2+.35, 1.41, 0.35], 'rate': [u_s,253.5, 273.5]}
        d2 = {'quantity': [0.8151], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [0.34], 'rate': [ls1.z['total cost'][2]]}

        d4 = {'quantity': [1], 'rate': [ls1.z['total cost'][7]]}
        i1 = ['unskilled labour', 'mason II', 'mason I']
        i2 = ['cement']
        i3 = ['fine sand']
        i4 = ['c.b. bricks']
        table1 = pd.DataFrame(d1, index=i1, columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=i2, columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=i3, columns=['quantity', 'rate'])
        table4 = pd.DataFrame(d4, index=i4, columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table4['amount'] = table4['quantity'] * table4['rate'].round(2)
        # table1['quantity']=table1['quantity'].map('{:.0f}no'.format)
        # table2['quantity']=table2['quantity'].map('{:.2f}qtl'.format)
        # table3['quantity']=table3['quantity'].map('{:.2f}cum'.format)
        table1['quantity'] = table1['quantity'].map('{:.2f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.3f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}cum'.format)
        table4['quantity'] = table4['quantity'].map('{:.2f}no'.format)

        table5 = table1.append(table2).append(table3).append(table4)
        table5.tamount = (table5)['amount'].sum()

        # table1['quantity']=table1['quantity'].map('{:.0f}no'.format)
        # table2['quantity']=table2['quantity'].map('{:.2f}qtl'.format)
        # table3['quantity']=table3['quantity'].map('{:.2f}cum'.format)



        table5['rate'] = table5['rate'].map('Rs.{:.2f}'.format)
        table5['amount'] = table5['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['RRHG_(1:6)'], '\n', table5, '\n\tCost for 1.00cum of stone masonry masonry= ',
              'Rs.{:.2f}'.format(table5.tamount))

root = Tk()
root.title = 'STONE MASONRY'
app = StoneMasonry(root)
root.mainloop()
#Stone Masonry
class BrickMasonry:
    def __init__(self,master):
        frame = Frame(master)
        frame.pack()
        self.Label = Label(frame, text = 'Brick Masonry')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.fabm = Button(frame,text = "FABM(1:6)",command = self.FAB_Masonry16)
        self.fabm.pack(side=LEFT)
        self.cbbm = Button(frame, text="CBBM(1:6)", command=self.CBB_Masonry16)
        self.cbbm.pack(side=LEFT)

    def FAB_Masonry16(self):
        d1 = {'quantity': [2.96, 1.05, 0.35], 'rate': [u_s,253.5, 273.5]}
        d2 = {'quantity': [0.672], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [0.28], 'rate': [ls1.z['total cost'][2]]}

        d4 = {'quantity': [350], 'rate': [ls1.z['total cost'][13]]}
        i1 = ['unskilled labour', 'mason II', 'mason I']
        i2 = ['cement']
        i3 = ['fine sand']
        i4 = ['f.a. bricks']
        table1 = pd.DataFrame(d1, index=i1, columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=i2, columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=i3, columns=['quantity', 'rate'])
        table4 = pd.DataFrame(d4, index=i4, columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table4['amount'] = table4['quantity'] * table4['rate'].round(2)
        # table1['quantity']=table1['quantity'].map('{:.0f}no'.format)
        # table2['quantity']=table2['quantity'].map('{:.2f}qtl'.format)
        # table3['quantity']=table3['quantity'].map('{:.2f}cum'.format)
        table1['quantity'] = table1['quantity'].map('{:.2f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.3f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}cum'.format)
        table4['quantity'] = table4['quantity'].map('{:.2f}no'.format)

        table5 = table1.append(table2).append(table3).append(table4)
        table5.tamount = (table5)['amount'].sum()

        # table1['quantity']=table1['quantity'].map('{:.0f}no'.format)
        # table2['quantity']=table2['quantity'].map('{:.2f}qtl'.format)
        # table3['quantity']=table3['quantity'].map('{:.2f}cum'.format)



        table5['rate'] = table5['rate'].map('Rs.{:.2f}'.format)
        table5['amount'] = table5['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['bmfpfa'], '\n', table5, '\n\tCost for 1.00cum of brick masonry in F & P= ',
              'Rs.{:.2f}'.format(table5.tamount))
    def CBB_Masonry16(self):
        d1 = {'quantity': [2.96, 1.05, 0.35], 'rate': [u_s,253.5, 273.5]}
        d2 = {'quantity': [0.672], 'rate': [ls1.z['total cost'][4]]}
        d3 = {'quantity': [0.28], 'rate': [ls1.z['total cost'][2]]}

        d4 = {'quantity': [350], 'rate': [ls1.z['total cost'][1]]}
        i1 = ['unskilled labour', 'mason II', 'mason I']
        i2 = ['cement']
        i3 = ['fine sand']
        i4 = ['c.b. bricks']
        table1 = pd.DataFrame(d1, index=i1, columns=['quantity', 'rate'])
        table2 = pd.DataFrame(d2, index=i2, columns=['quantity', 'rate'])
        table3 = pd.DataFrame(d3, index=i3, columns=['quantity', 'rate'])
        table4 = pd.DataFrame(d4, index=i4, columns=['quantity', 'rate'])
        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)
        table4['amount'] = table4['quantity'] * table4['rate'].round(2)
        # table1['quantity']=table1['quantity'].map('{:.0f}no'.format)
        # table2['quantity']=table2['quantity'].map('{:.2f}qtl'.format)
        # table3['quantity']=table3['quantity'].map('{:.2f}cum'.format)
        table1['quantity'] = table1['quantity'].map('{:.2f}no'.format)
        table2['quantity'] = table2['quantity'].map('{:.3f}qtl'.format)
        table3['quantity'] = table3['quantity'].map('{:.2f}cum'.format)
        table4['quantity'] = table4['quantity'].map('{:.2f}no'.format)

        table5 = table1.append(table2).append(table3).append(table4)
        table5.tamount = (table5)['amount'].sum()

        # table1['quantity']=table1['quantity'].map('{:.0f}no'.format)
        # table2['quantity']=table2['quantity'].map('{:.2f}qtl'.format)
        # table3['quantity']=table3['quantity'].map('{:.2f}cum'.format)



        table5['rate'] = table5['rate'].map('Rs.{:.2f}'.format)
        table5['amount'] = table5['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['bmfpcb'], '\n', table5, '\n\tCost for 1.00cum of brick masonry= ',
              'Rs.{:.2f}'.format(table5.tamount))

root = Tk()
root.title = 'BRICK MASONRY'
app = BrickMasonry(root)
root.mainloop()
#====Reinforcement
class ReinforcementWorks:
    def __init__(self, master):
        frame = Frame(master)
        frame.pack()
        self.Label = Label(frame, text='Reinforcement works')
        self.Label.pack(side=TOP)
        self.button = Button(frame, text='QUIT', fg="red", command=quit)
        self.button.pack(side=LEFT)
        self.reinforcement = Button(frame, text="Reinforcement works", command=self.reinforcement)
        self.reinforcement.pack(side=LEFT)


    def reinforcement(self):
        t = '''Supplying ,fitting and placing uncoated HYSD bar reinforcement complete
    as per drawing and technical specification.Unit - 1 qtl Taking Output = 1 qtl'''
        table1 = pd.DataFrame({'quantity': [1.05], 'rate': [ls1.z['total cost'][5]]}, index=['uncoated HYSD bars'],
                              columns=['quantity', 'rate'])
        table2 = pd.DataFrame({'quantity': [0.8], 'rate': [75.0]}, index=['binding wire'], columns=['quantity', 'rate'])
        table3 = pd.DataFrame({'quantity': [.8, .044, .3], 'rate': [u_s, 233.5, 273.5]},
                              index=['unskilled labour', 'semiskilled labour', 'mason I'], columns=['quantity', 'rate'])

        table1['amount'] = table1['quantity'] * table1['rate'].round(2)
        table2['amount'] = table2['quantity'] * table2['rate'].round(2)
        table3['amount'] = table3['quantity'] * table3['rate'].round(2)

        table1['quantity'] = table1['quantity'].map('{:.2f}qtl'.format)
        table2['quantity'] = table2['quantity'].map('{:.2f}kg'.format)
        table3['quantity'] = table3['quantity'].map('{:.3f}no'.format)
        table = table1.append(table2).append(table3)
        tamount = table.amount.sum()
        table['rate'] = table['rate'].map('Rs.{:.2f}'.format)
        table['amount'] = table['amount'].map('Rs.{:.2f}'.format)
        print(t, '\n', table, '\nRate of 1 quintal of Reinforcement works=',
              'Rs.{:.2f}'.format(tamount))

root = Tk()
root.title = 'REINFORCEMENT WORKS'
app = ReinforcementWorks(root)
root.mainloop()
#=========Paint
class Paint:
    def __init__(self,master):
        frame = Frame(master)
        frame.pack()
        self.Label = Label(frame, text='Paint')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.paint1 = Button(frame,text = "Wall paint with weather coat",command = self.paint1)
        self.paint1.pack(side=LEFT)
        self.distemper1 = Button(frame, text="Distemper one coat over old walls", command=self.distemper1)
        self.distemper1.pack(side=LEFT)
        self.DWpaintonecoat = Button(frame, text="Old Door and window painting one coat", command=self.D_W_paint_onecoat)
        self.DWpaintonecoat.pack(side=LEFT)
        self.waterproofCP = Button(frame, text="Water proofing cement paint",
                                     command=self.wpcp)
        self.waterproofCP.pack(side=LEFT)
    def paint1(self):
        d1 = {'quantity': [0.64/10, 0.54/10], 'rate': [u_s, 273.5]}

        table1 = pd.DataFrame(d1, index=['unskilled labour', 'mason II'], columns=['quantity', 'rate'])

        table1['amount'] = table1['quantity'] * table1['rate'].round(2)

        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)


        table1.tamount = (table1['amount'].sum())

        table1['rate'] = table1['rate'].map('Rs.{:.2f}'.format)
        table1['amount'] = table1['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['wall_paint'], '\n', table1, '\n\tCost for 1.00sqm of paint area = ',
               'Rs.{:.2f}'.format(table1.tamount) )
    def distemper1(self):
        d1 = {'quantity': [0.4/10, 0.33/10], 'rate': [u_s, 273.5]}

        table1 = pd.DataFrame(d1, index=['unskilled labour', 'mason II'], columns=['quantity', 'rate'])

        table1['amount'] = table1['quantity'] * table1['rate'].round(2)

        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)


        table1.tamount = (table1['amount'].sum())

        table1['rate'] = table1['rate'].map('Rs.{:.2f}'.format)
        table1['amount'] = table1['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['distemper'], '\n', table1, '\n\tCost for 1.00sqm of paint area = ',
               'Rs.{:.2f}'.format(table1.tamount) )
    def D_W_paint_onecoat(self):
        d1 = {'quantity': [0.82/9.3, 0.75/9.3], 'rate': [u_s, 273.5]}

        table1 = pd.DataFrame(d1, index=['unskilled labour', 'mason II'], columns=['quantity', 'rate'])

        table1['amount'] = table1['quantity'] * table1['rate'].round(2)

        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)


        table1.tamount = (table1['amount'].sum())

        table1['rate'] = table1['rate'].map('Rs.{:.2f}'.format)
        table1['amount'] = table1['amount'].map('Rs.{:.2f}'.format)
        print('\n', it.items['paint'], '\n', table1, '\n\tCost for 1.00sqm of paint area = ',
               'Rs.{:.2f}'.format(table1.tamount) )
    def wpcp(self):
        d1 = {'quantity': [.022,.015], 'rate': [u_s, 273.5]}

        table1 = pd.DataFrame(d1, index=['unskilled labour', 'mason II'], columns=['quantity', 'rate'])

        table1['amount'] = table1['quantity'] * table1['rate'].round(2)

        table1['quantity'] = table1['quantity'].map('{:.4f}no'.format)


        table1.tamount = (table1['amount'].sum())

        table1['rate'] = table1['rate'].map('Rs.{:.2f}'.format)
        table1['amount'] = table1['amount'].map('Rs.{:.2f}'.format)
        print('\n', textwrap.fill('''Finishing walls with water proofing cement paint of approved shade on old work one coat to give an even
shade exculding cost of paint.''',80), '\n', table1, '\n\tCost for 1.00sqm of paint area = ',
               'Rs.{:.2f}'.format(table1.tamount) )

root = Tk()
root.title = 'REINFORCEMENT WORKS'
app = Paint(root)
root.mainloop()


#======
if __name__ == "__main__":
    mainloop()
    print('\n\n\nJunior Engineer\t\t\tAssistant Engineer\tBlock Development Officer\nBinka Block Office\t\tBinka Block Office\t\tBinka')