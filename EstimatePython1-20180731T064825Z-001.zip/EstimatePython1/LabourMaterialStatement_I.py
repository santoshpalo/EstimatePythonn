#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 11 16:11:24 2018

@author: spalo
"""

import pandas as pd
import numpy as np
pd.set_option('max_colwidth', 1)
pd.set_option('display.expand_frame_repr', False)
pd.set_option('display.precision', 2)
def conveyance(x):
    'For conveyance of Rough stone, xetal, khoa, chips, moorum, earth and sand etc.(per 1cum.)'
    if x <= 5:
        return 149.67
    elif 5 < x & x <= 50:
        return 149.67 + (x - 5) * 8.8
    else:
        return 149.67 + 45 * 8.8 + 6.220 * (x - 50)


def conveyance_wood(x):
    'For conveyance of wood of 1cum volume'
    if x <= 5:
        return 161.72/ 1.25
    elif 5 < x & x <= 50:
        return (161.72 + (x - 5) * 8.23) / 1.25
    else:
        return (161.72 + 45 * 8.23 + (x - 50) * 6.99) / 1.25


def conveyance_cement(x):
    'For conveyance of wood of 1cum volume'
    if x <= 5:
        return 16.17
    elif 5 < x & x <= 50:
        return (16.172 + (x - 5) * 0.823)
    else:
        return (16.172 + 45 * 0.823 + (x - 50) * 0.699)
def conveyance_distemper(x):
    'For conveyance of wood of 1cum volume'
    if x <= 5:
        return 16.17/100
    elif 5 < x & x <= 50:
        return (16.172 + (x - 5) * 0.823)/100
    else:
        return (16.172 + 45 * 0.823 + (x - 50) * 0.699)/100

def conveyance_paint(x):
    'For conveyance of paint of 1ltr volume'
    if x <= 5:
        return 16.172*1.3/100
    elif 5 < x & x <= 50:
        return (16.172 + (x - 5) * 0.823)*1.3/100
    else:
        return (16.172 + 45 * 0.823 + (x - 50) * 0.699)*1.3/100


def conveyance_brick(x):
    'Bricks of 25cm size for 1 no. '
    if x <= 5:
        return 967.27/ 2000
    elif 5 < x & x <= 50:
        return (967.27 + (x - 5) * 39.62) / 2000
    else:
        return (967.27 + 45 * 39.62 + (x - 50) * 31.87) / 2000
def conveyance_tile(x):
    'Tiles of 1sqm. '
    if x <= 5:
        return 967.27/ 180
    elif 5 < x & x <= 50:
        return (967.27 + (x - 5) * 39.62) / 180
    else:
        return (967.27 + 45 * 39.62 + (x - 50) * 31.87) / 180
u_s=224.3
s_s=244.3
s=264.3
h_s=284.3


index=['unskilled labour','semi skilled labour','mason II','mason I','cement','sand','filling sand','flyash bricks','c.b. bricks','granite stone','40mm cbg metal','20mm cbg chips','12mm cbg chips','10mm cbg chips',
       'generator','CCmixer','floor tile','wall tile','wall primer','enamel paint','redoxide primer','WPC paint','emulsion paint','distemper','wall putty','vitrified tile','white cement']
unit=['no','no','no','no','qtl','cum','cum','no','no','cum','cum','cum','cum','cum','hr','hr','sqm','sqm','ltr','ltr','ltr','kg','ltr','kg','kg','sqm','qtl']
royalty=np.zeros(len(index))
royalty[5:7]=35
royalty[9:14]=130
EGB=np.zeros(len(index))
EGB[4]=2.8455
basic_rate=[224.3,244.3,264.3,284.3,426.56,52.38,45.71,3.57,2.88,221.83,664.76,1076.19,1095.24,1095.24,208.7,153.91,337.8,304.72,121.26,151.97,101.57,27.56,196.06,51.97,30,571.65,1358.27]
GST_percentage=[0,0,0,0,28,5,5,5,5,5,5,5,5,5,0,0,18,18,28,28,28,18,28,28,28,28,28]
lead=[0,0,0,0,20,10,10,20,15,30,40,40,40,40,0,0,20,20,20,20,20,20,20,20,20,20,20]
conveyance_cost=np.zeros(27)
conveyance_cost[4]=conveyance_cement(lead[4])
conveyance_cost[5]=conveyance(lead[5])
conveyance_cost[6]=conveyance(lead[6])
conveyance_cost[7]=conveyance_brick(lead[7])
conveyance_cost[8]=conveyance_brick(lead[8])
conveyance_cost[9]=conveyance(lead[9])
conveyance_cost[10]=conveyance(lead[10])
conveyance_cost[11]=conveyance(lead[11])
conveyance_cost[12]=conveyance(lead[12])
conveyance_cost[13]=conveyance(lead[13])
conveyance_cost[16]=conveyance_tile(lead[16])
conveyance_cost[17]=conveyance_tile(lead[17])
conveyance_cost[18]=conveyance_paint(lead[18])
conveyance_cost[19]=conveyance_paint(lead[19])
conveyance_cost[20]=conveyance_paint(lead[20])
conveyance_cost[21]=conveyance_distemper(lead[21])
conveyance_cost[22]=conveyance_paint(lead[22])
conveyance_cost[23]=conveyance_distemper(lead[23])
conveyance_cost[24]=conveyance_distemper(lead[24])
conveyance_cost[25]=conveyance_tile(lead[25])
conveyance_cost[26]=conveyance_cement(lead[26])




#print(index)
coefficient={'ewhs':np.zeros(len(index)),'efhs': np.zeros(len(index)),'sandfill': np.zeros(len(index)),'C.C.(1:3:6)': np.zeros(len(index)),'C.C.(1:4:8)': np.zeros(len(index)),'C.C.(1:2:4)': np.zeros(len(index)),
             'R.C.C. M-20': np.zeros(len(index)),'fabmfp(1:6)': np.zeros(len(index)),'fabmss(1:6)': np.zeros(len(index)),'cbbmfp(1:6)': np.zeros(len(index)),'cbbmss(1:6)': np.zeros(len(index)),
             'R.R.H.G.(1:6)':np.zeros(len(index)),'C.R.H.G.(1:6)':np.zeros(len(index)),'asfloor':np.zeros(len(index)),'floortile':np.zeros(len(index)),'walltile':np.zeros(len(index)),
             'primingWall':np.zeros(len(index)),'D/W paint':np.zeros(len(index)),'WPC paint':np.zeros(len(index)),'plastic paint':np.zeros(len(index)),'distempering':np.zeros(len(index)),
             'wallputty':np.zeros(len(index)),'12mm cp(1:6)':np.zeros(len(index)),'20mm cp(1:6)':np.zeros(len(index)),'16mm cp(1:6)':np.zeros(len(index)),'12mm cp(1:4)':np.zeros(len(index)),
             '20mm cp(1:4)':np.zeros(len(index)),'6mm cp(1:4)':np.zeros(len(index)),'vitrified tile':np.zeros(len(index))}
coefficient['ewhs'][0]=0.43
coefficient['efhs'][0]=0.43*1.2
coefficient['sandfill'][0]=0.1236
coefficient['C.C.(1:3:6)'][0]=3.9
coefficient['C.C.(1:3:6)'][2]=0.18
coefficient['C.C.(1:3:6)'][4]=2.29
coefficient['C.C.(1:3:6)'][5]=0.48
coefficient['C.C.(1:3:6)'][10]=0.96
coefficient['C.C.(1:4:8)'][0]=3.9
coefficient['C.C.(1:4:8)'][2]=0.18
coefficient['C.C.(1:4:8)'][4]=1.72
coefficient['C.C.(1:4:8)'][5]=0.48
coefficient['C.C.(1:4:8)'][10]=0.96
coefficient['C.C.(1:2:4)'][0]=4.6
coefficient['C.C.(1:2:4)'][2]=0.68
coefficient['C.C.(1:2:4)'][4]=3.23
coefficient['C.C.(1:2:4)'][5]=0.45
coefficient['C.C.(1:2:4)'][12]=0.9
coefficient['R.C.C. M-20'][0]=20/15
coefficient['R.C.C. M-20'][2]=1.5/15
coefficient['R.C.C. M-20'][1]=0.86/15
coefficient['R.C.C. M-20'][4]=52.1/15
coefficient['R.C.C. M-20'][5]=6.75/15
coefficient['R.C.C. M-20'][11]=8.1/15
coefficient['R.C.C. M-20'][13]=5.4/15
coefficient['fabmfp(1:6)'][0]=2.96
coefficient['fabmfp(1:6)'][2]=1.05
coefficient['fabmfp(1:6)'][3]=0.35
coefficient['fabmfp(1:6)'][4]=0.672
coefficient['fabmfp(1:6)'][5]=0.28
coefficient['fabmfp(1:6)'][7]=350
coefficient['fabmss(1:6)'][0]=2.96+33/u_s
coefficient['fabmss(1:6)'][2]=1.05
coefficient['fabmss(1:6)'][3]=0.35
coefficient['fabmss(1:6)'][4]=0.672
coefficient['fabmss(1:6)'][5]=0.28
coefficient['fabmss(1:6)'][7]=350
coefficient['cbbmfp(1:6)'][0]=2.96
coefficient['cbbmfp(1:6)'][2]=1.05
coefficient['cbbmfp(1:6)'][3]=0.35
coefficient['cbbmfp(1:6)'][4]=0.672
coefficient['cbbmfp(1:6)'][5]=0.28
coefficient['cbbmfp(1:6)'][8]=350
coefficient['cbbmss(1:6)'][0]=2.96+33/u_s
coefficient['cbbmss(1:6)'][2]=1.05
coefficient['cbbmss(1:6)'][3]=0.35
coefficient['cbbmss(1:6)'][4]=0.672
coefficient['cbbmss(1:6)'][5]=0.28
coefficient['cbbmss(1:6)'][8]=350
coefficient['R.R.H.G.(1:6)'][0]=2.82+.35
coefficient['R.R.H.G.(1:6)'][2]=1.41
coefficient['R.R.H.G.(1:6)'][3]=0.35
coefficient['R.R.H.G.(1:6)'][4]=0.8151
coefficient['R.R.H.G.(1:6)'][5]=0.34
coefficient['R.R.H.G.(1:6)'][9]=1
coefficient['C.R.H.G.(1:6)'][0]=1.41+.25
coefficient['C.R.H.G.(1:6)'][1]=1.41
coefficient['C.R.H.G.(1:6)'][2]=1.41
coefficient['C.R.H.G.(1:6)'][3]=0.35+2.47
coefficient['C.R.H.G.(1:6)'][4]=0.572
coefficient['C.R.H.G.(1:6)'][5]=0.24
coefficient['C.R.H.G.(1:6)'][9]=1
coefficient['asfloor'][0]=0.36
coefficient['asfloor'][3]=0.13
coefficient['asfloor'][4]=0.0858
coefficient['asfloor'][5]=0.012
coefficient['asfloor'][12]=.023
coefficient['floortile'][0]=0.216
coefficient['floortile'][3]=0.216
coefficient['floortile'][4]=(0.44+1.857)/10
coefficient['floortile'][5]=0.013
coefficient['floortile'][16]=1.0
coefficient['walltile'][0]=0.325
coefficient['walltile'][3]=0.325
coefficient['walltile'][4]=(0.66+0.715)/10
coefficient['walltile'][5]=0.015
coefficient['walltile'][17]=1.0
coefficient['primingWall'][0]=0.5/9.3
coefficient['primingWall'][3]=0.5/9.3
coefficient['primingWall'][18]=0.84/10
coefficient['D/W paint'][0]=1.1/9.3
coefficient['D/W paint'][3]=1.75/9.3
coefficient['D/W paint'][19]=1.25/10
coefficient['D/W paint'][20]=0.54/10
coefficient['WPC paint'][0]=.032
coefficient['WPC paint'][3]=.022
coefficient['WPC paint'][21]=0.25
coefficient['plastic paint'][0]=.064
coefficient['plastic paint'][3]=.054
coefficient['plastic paint'][22]=0.125
coefficient['distempering'][0]=.062
coefficient['distempering'][3]=.052
coefficient['distempering'][23]=0.25
coefficient['wallputty'][0]=.057
coefficient['wallputty'][2]=.05
coefficient['wallputty'][24]=0.8
coefficient['12mm cp(1:6)'][0]=.12
coefficient['12mm cp(1:6)'][2]=.14
coefficient['12mm cp(1:6)'][4]=0.0358
coefficient['12mm cp(1:6)'][5]=0.015
coefficient['20mm cp(1:6)'][0]=.16
coefficient['20mm cp(1:6)'][2]=.24
coefficient['20mm cp(1:6)'][4]=0.057
coefficient['20mm cp(1:6)'][5]=0.021
coefficient['16mm cp(1:6)'][0]=.16
coefficient['16mm cp(1:6)'][2]=.24
coefficient['16mm cp(1:6)'][4]=0.043
coefficient['16mm cp(1:6)'][5]=0.018
coefficient['12mm cp(1:4)'][0]=.12
coefficient['12mm cp(1:4)'][2]=.14
coefficient['12mm cp(1:4)'][4]=0.0543
coefficient['12mm cp(1:4)'][5]=0.015
coefficient['20mm cp(1:6)'][0]=.16
coefficient['20mm cp(1:6)'][2]=.24
coefficient['20mm cp(1:6)'][4]=0.0744
coefficient['20mm cp(1:6)'][5]=0.021
coefficient['6mm cp(1:4)'][0]=.12
coefficient['6mm cp(1:4)'][2]=.14
coefficient['6mm cp(1:4)'][4]=0.0372
coefficient['6mm cp(1:4)'][5]=0.0075
coefficient['vitrified tile'][0]=.216
coefficient['vitrified tile'][3]=.216
coefficient['vitrified tile'][4]=(0.744+.33)/10
coefficient['vitrified tile'][5]=0.021
coefficient['vitrified tile'][25]=1
coefficient['vitrified tile'][26]=0.0076



        
        
    







table= pd.DataFrame(data=coefficient,index=index)
#print (table)
if __name__ == "__main__":
    table1=(table['efhs']*27.36+
            table['sandfill']*10.88+
            table['C.C.(1:3:6)']*24.96+
            table['C.C.(1:2:4)']*21.61+
            
            table['12mm cp(1:6)']*0
                  +table['16mm cp(1:6)']*0
                  +table['floortile']*0
                  +table['walltile']*0
                  +table['cbbmfp(1:6)']*0
                  +table['C.C.(1:4:8)']*0
                  +table['6mm cp(1:4)']*0
                  +table['20mm cp(1:4)']*0
                  +table['vitrified tile']*0
                  +table['WPC paint']*0
                  +table['D/W paint']*0
                  +table['distempering']*0).to_frame('quantity')
    table1.insert(1,'unit',unit)
    table1.insert(2,'royalty',royalty*table1['quantity'])
    table1.insert(3,'EGB',table1['quantity']*EGB)
    table1.insert(4,'basic rate',basic_rate)
    table1.insert(5,'GST%',GST_percentage)
    table1.insert(6,'GST',GST_percentage*table1['basic rate']/100)
    table1.insert(7,'Gross rate',table1['GST']+table1['basic rate'])
    table1.insert(8,'lead',lead)
    table1.insert(9,'conveyance',conveyance_cost)
    table1.insert(10,'Gross+conveyance',table1['conveyance']+table1['Gross rate'])
    table1.insert(11,'Gross Total',(table1['conveyance']+table1['Gross rate'])*table1['quantity'])
    table1['royalty']=table1['royalty'].map('\u20B9{:.2f}'.format)
    table1['EGB']=table1['EGB'].map('\u20B9{:.2f}'.format)
    table1['basic rate']=table1['basic rate'].map('\u20B9{:.2f}'.format)
    table1['GST']=table1['GST'].map('\u20B9{:.2f}'.format)
    table1['Gross rate']=table1['Gross rate'].map('\u20B9{:.2f}'.format)
    table1['conveyance']=table1['conveyance'].map('\u20B9{:.2f}'.format)
    table1['Gross+conveyance']=table1['Gross+conveyance'].map('\u20B9{:.2f}'.format)
    table1['Gross Total']=table1['Gross Total'].map('\u20B9{:.2f}'.format)
    table1['lead']=table1['lead'].map('{:.2f}km'.format)
    table1['GST%']=table1['GST%'].map('{:.0f}%'.format)
    table11=table1[table1['quantity']!=0]
    print(table11)
    

    
    

