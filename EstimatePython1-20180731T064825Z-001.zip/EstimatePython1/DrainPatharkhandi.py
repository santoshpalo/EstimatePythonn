import ClassLibrary as cl
import items as it
import FunctionLibraryR as fr
l=36



if __name__ == "__main__":
    print('Name of the work:-Construction of drain at Pathar Khandi ')
    print('Head of Account:-14th CFC(2016-17)\t\t\tEstimated Cost:-\u20B91,00,000.00')
    print('-'*80)
    print(it.items['efhs'])
    excavation= cl.Quantity([['drain foundation',1,l,1.2,0.75],
                             ])
    excavation.rate=fr.foundation(1)
    excavation.volume()
    print(it.items['sand_filling'])
    sand = cl.Quantity([['foundation of drain',1,l,1.2,0.1]])
    sand.rate=fr.sandfilling()
    sand.volume()
    print(it.items['CC(1:3:6)'])
    concrete=cl.Quantity([['foundation concrete',1,l,1.2,0.1],
                          ['both sidewalls',2,l,0.3,0.5]])
    concrete.rate=fr.concrete(2)
    concrete.volume()
    concrete = cl.Quantity([['inside drain concrete', 1, l, 0.6, 0.1],
                            ['both sidewalls', 2, l, 0.3, 0.1]])
    print(it.items['CC(1:2:4)'])
    concrete.rate = fr.concrete(3)
    concrete.volume()
    print(it.items['12cp(1:6)'])
    plaster=cl.Quantity([['walls sides',2,l,0.6],
                         ['wall tops',2,l,0.3 ]])
    plaster.rate=fr.plaster(1)
    plaster.vArea()
    print(it.items['rscs_walls'])
    rscs=cl.Quantity([['walls',2,l,0.6],
                      ])
    rscs.rate=fr.rscs(6)
    rscs.vArea()
    print('Labour cess=\u20B91000.00')
    print('Work contingency =\u20B9500.00')
    print('Labour Registration cess=\u20B9100.00')
    print('Display board and photograph\u20B91000.00')
    print('Estimated cost limited to \u20B91,00,000.00')
    print('-'*80)
    fr.signature(100000,'One lakh rupees only',3,'Julund G.P.')

