import ClassLibrary as cl
import FunctionLibrary as fl
import items as it
import textwrap






if __name__ == "__main__":
    print(textwrap.fill('Name of the work:-Construction of commercial shed at weekly market place at Baunsuni',80))
    print('Estimated Cost:-\u20B92,50,000.00\tHead of Account:-4th SFC')
    print('='*80)
    print(textwrap.fill(it.items['efhs']))
    foundation=cl.Quantity([['columns',24,1.5,1.5,1.2],
                            ['wall foundation',1,71.36-24*1.5,0.7,0.4]])
    foundation.rate=103.2
    foundation.volume()
    print(textwrap.fill(it.items['m20'],80))
    rcc=cl.Quantity([['footings',24,1.2,1.2,0.3],
                     ['columns',24,0.25,0.25,0.7],
                     pli
                     ])

