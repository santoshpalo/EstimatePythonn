import pandas as pd
pd.set_option('max_colwidth', 0)
pd.set_option('display.expand_frame_repr', False)
pd.set_option('display.precision', 4)
data = [['Excavation of foundation trench in h/s',1.2*0.43,0,0,0,0,0,0,0,0,0,0,0,0],
        ['C.C.(1:3:6) using 40mm h.g. metal',3.9,0,0.18,0,2.29,0.48,0,0.96,0,0,0,0,0],
        ['C.C.(1:4:8) using 40mm h.g. metal',3.9,0,0.18,0,1.72,0.48,0,0.96,0,0,0,0,0],
        ['Brick Masonry in c.m.(1:6)',2.96,0,1.41,0.35,0.672,0.28,350,0,0,0,0,0,0],
        ['plaster c.m.(1:6) 12mm thick',0.12,0,0.14,0,.0358,.015,0,0,0,0,0,0,0],
        ['plaster c.m.(1:6) 16mm thick', 0.24, 0, 0.16, 0, .043, .018, 0, 0, 0, 0,0,0,0],
        ['M-20 grade concrete', 20.0/15, 0.86/15.0, 1.50/15, 0, 5.210*10/15, 6.75/15, 0, 0,8.1/15, 0,5.4/15,   0.4, 0.4]]
table1=pd.DataFrame(data,index = range(1,len(data)+1),columns = ['description','u/s','s/s','mason II','mason I','cement','sand','bricks','h.g. metal 40mm','20mm cbg chips','12mm cbg chips','10mm cbg chips','H/R of Concrete mixer','H/R of generator'])
print(table1.drop(['description'],axis = 1))