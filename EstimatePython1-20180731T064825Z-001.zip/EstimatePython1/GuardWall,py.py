import ClassLibrary as cl
import FunctionLibrary as fl
import items as it
import textwrap

l=26.00





if __name__ == "__main__":
    print(textwrap.fill("Name of the work:-Construction of Guard wall at High School Play Ground at Baunsuni",80))
    print('Estimated Cost:-\u20B91,00,000\t\tHead of Account:-14th CFC')
    print('='*80)
    print(textwrap.fill(it.items['efhs']))
    foundation_trench=cl.Quantity([['wall',1,l,1.1,1.2]])
    foundation_trench.rate=103.2
    foundation_trench.volume()
    print(textwrap.fill(it.items['sand_filling']))
    sandfill=cl.Quantity([['wall trench',1,l,1.1,0.15]])
    sandfill.rate=313.52
    sandfill.volume()
    print((textwrap.fill(it.items['CC(1:3:6)'],80)))
    wall=cl.Quantity([['guard wall',1,l,0.75,0.45,1.2]])
    wall.rate=3700.47
    wall.trapezoidalVolume()
    print(textwrap.fill(it.items['rscs_walls']))
    wallcentering=cl.Quantity([['wall',2,l,1.2]])
    wallcentering.rate=387.07
    wallcentering.vArea()
    print('Cess for welfare of labourers =  \u20B91,000.00')
    print('Display board and photograph = \u20B9 1,500.00')
    print('Departmental contingency = \u20B91,000.00')
    print('Labour registration cess = \u20B9100.00')
    print('-'*80)
    fl.signature(100000,'One lakh rupees only',3,'Baunsuni G.P.')



