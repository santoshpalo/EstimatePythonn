import items as it
import FunctionLibrary as fl
import ClassLibrary as cl






if __name__ == "__main__":
    efhs=cl.Quantity([['foundation',1,15,.6,.6]])
    efhs.rate=100
    efhs.volume()



    bkfp = cl.Quantity([['1st footing',1,15,0.38,0.6],
                        ])
    bkfp.rate =100
    bkfp.volume()
    bkss=cl.Quantity([['0.25 thick wall',1,15,.25,1.2],
                      ['pillar extra thickness',6,.13,.38,1.2]])
    bkss.rate=100
    bkss.volume()
    plaster12=cl.Quantity([['walls one side',1,15,1.3],
                           ['offsets',6,.13,1.2]])
    plaster12.rate=100
    plaster12.vArea()
    plaster16=cl.Quantity([['walls one side',1,15,1.3],
                       ['offsets',6,.13,1.2]])
    plaster16.rate=100
    plaster16.vArea()
    CC=cl.Quantity([['foundation',1,15,.6,.1]])
    CC.rate=100
    CC.volume()
