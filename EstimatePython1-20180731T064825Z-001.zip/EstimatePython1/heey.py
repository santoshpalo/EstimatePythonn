from tkinter import *
class Application(Frame):
    def __init__(self,master):
        Frame.__init__(self,master)
        self.grid()

        self.d = 0
        self.size=0
        self.mil=0
        self.create_widgets()
    def create_widgets(self):
        self.L1=Label(self)
        self.L2=Label(self)
        self.L3=Label(self)

        self.L1.grid(column = 1,row = 1)
        self.L2.grid(column = 1, row =2)
        self.L3.grid(column = 1,row = 3)

        self.L1["text"]="Distance from Target"+str(self.d)+"m"
        self.L2["text"] = "Size of Target" + str(self.size) + "mils"
        self.L3["text"] = "Mil Dot adj" + str(self.mil)

        # self.entryd=Entry(self,bd=5)
        # self.entryd.grid(column = 2, row=1)
        self.entrysize = Entry(self, bd=5)
        self.entrysize.grid(column=2, row=2)
        self.entrymil = Entry(self, bd=5)
        self.entrymil.grid(column=2, row=3)

        self.button1=Button(self)
        self.button1["text"]="Calculate Kill Shot"
        self.button1["command"]=self.calc
        self.button1.grid(column = 2,row = 4)

    def calc(self):
        # self.d=self.entryd.get()
        self.size=self.entrysize.get()
        self.mil=self.entrymil.get()

        self.L1["text"] = "Distance from Target" + str(self.d) + "m"
        self.L2["text"] = "Size of Target" + str(self.size) + "mils"
        self.L3["text"] = "Mil Dot adj" + str(self.mil)

        self.d=int(self.size)*1000/int(self.mil)
        # return self.d
root=Tk()
root.title("heey")
root.geometry("400x400")
app= Application(root)

root.mainloop()


