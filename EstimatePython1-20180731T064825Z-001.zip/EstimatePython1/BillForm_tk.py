import pandas as pd
import textwrap
from tkinter import *
from quitter import Quitter

pd.set_option('max_colwidth', 0)
pd.set_option('display.expand_frame_repr', False)
pd.set_option('display.precision', 2)


item = {'efhs': 'Excavation of foundation in h/s',
     'ewhs': 'Earth work in hard soil',
     'cc(1:4:8)': 'C.C. (1:4:8) using 40mm h.g. metal',
     'cc(1:3:6)': 'C.C. (1:3:6) using 40mm h.g. metal',
     'cc(1:2:4)': 'C.C. (1:2:4) using 12mm h.g. chips',
     'rcc': 'R.C.C. (1:1.5:3) using 12mm h.g. chips',

     'm20': 'R.C.C. m-20 grade concrete ',
     '20cp': '20mm thick grading plaster c.m.(1:4)',
     '12cp': '12mm thick plaster with c.m. (1:6)',
     '16cp': '16mm thick plaster with c.m. (1:6)',
     '6cp': '6mm thick plaster with c.m. (1:4)',
     'vTile': 'Vitrified tile floor white cement fill',
     'wTile': 'Ceramic glazed wall tile fixing',
     'wpcp': 'Finishing water proofing cement paint',
     'slab': 'Rigid/smooth centering shuttering slab',
     'beam': 'Rigid/smooth centering shuttering beam',
     'plinth': 'Rigidsmooth centeringshuttering plint',
     'lintel': 'Rigidsmooth centeringshuttering lintel',
     'wall': 'Rigidsmooth centeringshuttering wall',
     'stair': 'Rigidsmooth centeringshuttering stair',
     'hysd': 'HYSD bar Reinforcement works in R.C.C.',
     'w_tile': 'Cost of ceramic glazed wall tiles',
     'cess': 'Cess for welfare of labourers',
     'contingency': 'Work contingency',
     'display': 'Cost of Display Board and photograph',
     'fill_sand': 'Filling sand, watering & ramming',
     'vibrator': 'Hire & Running of [late vibrator',
     'bmfp': 'F.A. Brick masonry in c.m.(1:6) in F&P',
     'bmss': 'F.A. Brick masonry in c.m.(1:6) in S/S',
     'msdoor': 'Supplying of M.S. doors and windows',
     'paint': 'Painting 2 coats over a coat of priming',
     'asf': '2.5cm thick A.S. flooring with c.c.(1:2:4)',
     'mechanical': 'Earth work by mechanical means'

     }
d1 = {'us': 'differential cost of u/s labour',
      'ss': 'differential cost of s/s labour',
      's': 'differential cost of mason II',
      'hs': 'differential cost of mason I',
      'cement': 'differential cost of cement',
      'sand': 'differential cost of fine sand',
      'chips12': 'differential cost of 12mm cbg chips',
      'metal40': 'differential cost of 40mm hgb metal',
      'sandf': 'differential cost of filling sand',
      'bricks': 'differential cost of bricks'}





class deduction():
    def __init__(self, data, columns=['description', 'realisation']):
        self.data = data
        self.columns = columns

    def deduct(self):
        table = pd.DataFrame(self.data, columns=self.columns, index=range(1, len(self.data) + 1, 1))
        t_deduction = table['realisation'].sum()
        table['realisation'] = table['realisation'].map('\u20B9{:.2f}'.format)

        print(table, '\n\t\t\t\t\t', 'Total deduction = ', '\u20B9{:.2f}'.format(t_deduction))


def bill_form(item,q,r):
    fields = ('ewhs', 'efhs',
              'filling sand',
              'C.C.(1:3:6)',
              'C.C.(1:4:8)',
              'C.C.(1:2:4)',
              'C.C.(1:1.5:3)',
              'P.C.C. M-20',
              'R.C.C. M-20',
              'Reinforcement',
              'R.S./C.S. Plinth',
              'R.S./C.S. Column',
              'R.S./C.S. Lintel',
              'R.S./C.S. Slab',
              'R.S./C.S. Staircase',
              'R.S./C.S. Wall',
              'B.M.F.P.C.B.(1:6)',
              'B.M.F.P.F.A.(1:6)',
              'B.M.S.S..C.B.(1:6)',
              'B.M.S.S.F.A.(1:6)',
              'R.R.H.G.S.M.(1:6)',
              'C.R.H.G.S.M.(1:6)',
              '12mm C.P.(1:6)',
              '16mm C.P.(1:6)',
              '20mm C.P.(1:6)',
              '12mm C.P.(1:4)',
              '20mm C.P.(1:4)',
              '6mm C.P.(1:4) on R.C.C.',
              'A.S.F. with C.C. (1:2:4)',
              'Vitrified Tile Floor',
              'Ceramic Tile Floor',
              'Ceramic Wall Tile',
              'Painting 2 coats Priming 1 coat',
              '2 coats water proofing cement paint',
              'Distemper 2 coats',
              'Weather coat on external wlls 2 coat'
              )
    fields1=('ewhs by mechanical means',
             'cess',
             'L.R.C.',
             'W.C.',
             'displaboard & photograph',
             'plate vibrator',
             'M.S. D & W',
             'diff. cost cement',
             'diff. cost hysd bar',
             'deff. cost u/s labour',
             'diff cost s/s labour',
             'diff cost Mason II',
             'diff cost Mason I',

             )
    d = {'efhs': 'Excavation of foundation in h/s',
         'ewhs': 'Earth work in hard soil',
         'cc148': 'C.C. (1:4:8) using 40mm h.g. metal',
         'cc136': 'C.C. (1:3:6) using 40mm h.g. metal',
         'cc124': 'C.C. (1:2:4) using 12mm h.g. chips',
         'rcc': 'R.C.C. (1:1.5:3) using 12mm h.g. chips',
         'm20': 'R.C.C. m-20 grade concrete ',
         'pm20': 'P.C.C. m-20 grade concrete ',
         '20cp': '20mm thick grading plaster c.m.(1:4)',
         '20cp6': '20mm thick plaster on R.R.S.M. c.m.(1:6)',
         '12cp': '12mm thick plaster with c.m. (1:6)',
         '12cp4': '12mm thick plaster with c.m. (1:4)',
         '16cp': '16mm thick plaster with c.m. (1:6)',
         '6cp': '6mm thick plaster with c.m. (1:4)',
         'vTile': 'Vitrified tile floor white cement fill',
         'wTile': 'Ceramic glazed wall tile fixing',
         'wpcp': 'Finishing water proofing cement paint',
         'slab': 'Rigid/smooth centering shuttering slab',
         'beam': 'Rigid/smooth centering shuttering beam',
         'plinth': 'Rigidsmooth centeringshuttering plint',
         'lintel': 'Rigidsmooth centeringshuttering lintel',
         'wall': 'Rigidsmooth centeringshuttering wall',
         'stair': 'Rigidsmooth centeringshuttering stair',
         'hysd': 'HYSD bar Reinforcement works in R.C.C.',
         'w_tile': 'Cost of ceramic glazed wall tiles',
         'cess': 'Cess for welfare of labourers',
         'contingency': 'Work contingency',
         'display': 'Cost of Display Board and photograph',
         'fill_sand': 'Filling sand, watering & ramming',
         'vibrator': 'Hire & Running of [late vibrator',
         'bmfp': 'F.A. Brick masonry in c.m.(1:6) in F&P',
         'bmss': 'F.A. Brick masonry in c.m.(1:6) in S/S',
         'msdoor': 'Supplying of M.S. doors and windows',
         'paint': 'Painting 2 coats over a coat of priming',
         'distemper': 'Distempering 2 coats on new walls',
         'weather coat':'Weather coat painting on external wall',
         'asf': '2.5cm thick A.S. flooring with c.c.(1:2:4)',
         'vitrified':'Vitrified tile flooring ',
         'floor_tile':"Ceramic tile flooring on c.m. mortar",
         'wall_tile': "Ceramic wall tile  on c.m. mortar",
         'bmfps':"Clamp burnt brick masonry in c.m.(1:6)",
         'bmfps1': "Fly Ash brick masonryin c.m.(1:6)",
         'rrhg': 'R.R.H.G. stone masonry in c.m.(1:6)',
         'crhg': 'C.R.H.G. stone masonry in c.m.(1:6)'
          }
    d1= {'ewhs by mechanical means':'Earth work by mechanical means',
             'cess':'Cess for welfare of labourers',
             'L.R.C.':'Labour registration cess',
             'W.C.':'Departmental contingency',
             'displaboard & photograph':'Cost of Display board and photograph',
             'plate vibrator':'H&R charges of plate vibrator',
             'M.S. D & W':'Supplying and fixing of M.S. D & W',
             'diff. cost cement':'Differential cost of cement',
             'diff. cost hysd bar':'Differential cost of hysd bar',
             'deff. cost u/s labour':'differential cost of u.s. labour',
             'diff cost s/s labour':'differential cost of s.s. labour',
             'diff cost Mason II':'differential cost of skilled labour',
             'diff cost Mason I':'differential cost of h.s. labour',}

    unit = {'efhs': 'cum',  # 1
            'ewhs': 'cum',  # 2
            'cc148': 'cum',  # 3
            'cc136': 'cum',  # 4
            'cc124': 'cum',  # 5
            'rcc': 'cum',  # 6
            'm20': 'cum',
            'pm20': 'cum',  # 7
            '20cp': 'sqm',
            '20cp6': 'sqm',  # 8
            '12cp': 'sqm',  # 9
            '12cp4': 'sqm',
            '16cp': 'sqm',  # 10
            '6cp': 'sqm',  # 11
            'vTile': 'sqm',  # 12
            'wTile': 'sqm',  # 13
            'wpcp': 'sqm',  # 14
            'slab': 'sqm',  #
            'beam': 'sqm',
            'plinth': 'sqm',
            'lintel': 'sqm',
            'wall': 'sqm',
            'stair':'sqm',
            'hysd': 'qtl',
            'w_tile': 'sqm',
            'cess': '',
            'contingency': '',
            'display': '',
            'fill_sand': 'cum',
            'vibrator': 'hr',
            'bmfp': 'cum',
            'bmss': 'cum',
            'msdoor': 'qtl',
            'paint': 'ltr',
            'distemper': 'ltr',
            'weather coat':'ltr',
            'asf': 'sqm',
            'vitrified': 'sqm',
            'rrhg': 'cum',
            'crhg': 'cum',
            'bmfps': 'cum',
            'bmfps1': 'cum',
            'floor_tile': 'sqm',
            'wall_tile': 'sqm',
            }
    unit1 ={'ewhs by mechanical means':'cum',
             'cess':'',
             'L.R.C.':'',
             'W.C.':'',
             'displaboard & photograph':'',
             'plate vibrator':'hr',
             'M.S. D & W':'qtl',
             'diff. cost cement':'qtl',
             'diff. cost hysd bar':'qtl',
             'deff. cost u/s labour':'no',
             'diff cost s/s labour':'no',
             'diff cost Mason II':'no',
             'diff cost Mason I':'no'}

    if item == 'bmfp':
        c = ['Unit']
        i = [d['bmfp']]
        data = {'Unit':unit['bmfp']}
        table = pd.DataFrame(data,index = i,columns = c)
        table.insert(0,'Quantity',q)
        table.insert(1,'Rate',r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)



    elif item == 'rcc':
        c = [ 'Unit']
        i = [d['rcc']]
        data = { 'Unit':unit['rcc']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)


    elif item == 'cc148':
        c = [ 'Unit']
        i = [d['cc148']]
        data = { 'Unit':unit['cc148']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)


    elif item == 'rscscolumn':
        c = [ 'Unit']
        i = [d['beam']]
        data = { 'Unit':unit['beam']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)


    elif item == 'rscsplinth':
        c = [ 'Unit']
        i = [d['plinth']]
        data = { 'Unit':unit['plinth']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)


    elif item == 'efhs':
        c = [ 'Unit']
        i = [d['efhs']]
        data = { 'Unit':unit['efhs']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'hysd':
        c = [ 'Unit']
        i = [d['hysd']]
        data = { 'Unit':unit['hysd']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'paint':
        c = [ 'Unit']
        i = [d['paint']]
        data = {'Unit':unit['paint']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'wpcp':
        c = [ 'Unit']
        i = [d['wpcp']]
        data = {'Unit':unit['wpcp']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == '12cp(1:6)':
        c = [ 'Unit']
        i = [d['12cp']]
        data = { 'Unit':unit['12cp']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == '12cp(1:4)':
        c = [ 'Unit']
        i = [d['12cp4']]
        data = { 'Unit':unit['12cp4']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'sandfill':
        c = [ 'Unit']
        i = [d['fill_sand']]
        data = { 'Unit':unit['fill_sand']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'asf(1:2:4)':
        c = [ 'Unit']
        i = [d['asf']]
        data = { 'Unit':unit['asf']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == '16cp(1:6)':
        c = [ 'Unit']
        i = [d['16cp']]
        data = { 'Unit':unit['16cp']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'rcc M-20':
        c = [ 'Unit']
        i = [d['m20']]
        data = { 'Unit':unit['m20']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'pcc M-20':
        c = [ 'Unit']
        i = [d['pm20']]
        data = { 'Unit':unit['pm20']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'rscsslab':
        c = [ 'Unit']
        i = [d['slab']]
        data = { 'Unit':unit['slab']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'rscswalls':
        c = [ 'Unit']
        i = [d['wall']]
        data = { 'Unit':unit['wall']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == '20cp(1:4)':
        c = [ 'Unit']
        i = [d['20cp']]
        data = { 'Unit':unit['20cp']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'cc136':
        c = [ 'Unit']
        i = [d['cc136']]
        data = { 'Unit':unit['cc136']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'cc124':
        c = [ 'Unit']
        i = [d['cc124']]
        data = { 'Unit':unit['cc124']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'rscslintel':
        c = [ 'Unit']
        i = [d['lintel']]
        data = { 'Unit':unit['lintel']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == '20cp(1:6)':
        c = ['Unit']
        i = [d['20cp6']]
        data = { 'Unit':unit['20cp6']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == '6cp(1:4)':
        c = [ 'Unit']
        i = [d['6cp']]
        data = { 'Unit':unit['6cp']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'distemper':
        c = [ 'Unit']
        i = [d['distemper']]
        data = { 'Unit':unit['distemper']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)
    elif item == 'Weather coat':
        c = [ 'Unit']
        i = [d['weather coat']]
        data = { 'Unit':unit['Weather coat']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'vitrified':
        c = [ 'Unit']
        i = [d['vitrified']]
        data = { 'Unit':unit['vitrified']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'ewhs':
        c = [ 'Unit']
        i = [d['ewhs']]
        data = { 'Unit':unit['ewhs']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'rrhg':
        c = [ 'Unit']
        i = [d['rrhg']]
        data = { 'Unit':unit['rrhg']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'crhg':
        c = [ 'Unit']
        i = [d['crhg']]
        data = {'Unit':unit['crhg']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'bmfps':
        c = [ 'Unit']
        i = [d['bmfps']]
        data = { 'Unit':unit['bmfps']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'bmfps1':
        c = [ 'Unit']
        i = [d['bmfps1']]
        data = { 'Unit':unit['bmfps1']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)

    elif item == 'floor_tile':
        c = [ 'Unit']
        i = [d['floor_tile']]
        data = { 'Unit':unit['floor_tile']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount'] = table['Quantity'] * table['Rate'].round(0)


    elif item == 'wall_tile':
        c = [ 'Unit']
        i = [d['wall_tile']]
        data = { 'Unit':unit['wall_tile']}
        table = pd.DataFrame(data, index=i, columns=c)
        table.insert(0, 'Quantity', q)
        table.insert(1, 'Rate', r)
        table['Amount']=table['Quantity']*table['Rate'].round(0)

    else :
        pass
    return table
fields=(('Name of the work',
         'Estimated Cost',
         'Head of Account',
         'Case Record No.',
         'Name of the executant',
         'Measurement Book No.',
         'Page No.',
         'Date',
         'Serial No. of the Bill',
         'ewhs','efhs',
        'filling sand',
        'C.C.(1:3:6)',
        'C.C.(1:4:8)',
        'C.C.(1:2:4)',
        'C.C.(1:1.5:3)',
        'P.C.C. M-20',
        'R.C.C. M-20',
        'Reinforcement',
        'R.S./C.S. Plinth',
        'R.S./C.S. Column',
        'R.S./C.S. Lintel',
        'R.S./C.S. Slab',
        'R.S./C.S. Staircase',
        'R.S./C.S. Wall',
        'B.M.F.P.C.B.(1:6)',
        'B.M.F.P.F.A.(1:6)',
        'B.M.S.S..C.B.(1:6)',
        'B.M.S.S.F.A.(1:6)',
        'R.R.H.G.S.M.(1:6)',
        'C.R.H.G.S.M.(1:6)',
        '12mm C.P.(1:6)',
        '16mm C.P.(1:6)'),
        ('20mm C.P.(1:6)',
        '12mm C.P.(1:4)',
        '20mm C.P.(1:4)',
        '6mm C.P.(1:4) on R.C.C.',
        'A.S.F. with C.C. (1:2:4)',
        'Vitrified Tile Floor',
        'Ceramic Tile Floor',
        'Ceramic Wall Tile',
        'Painting 2 coats Priming 1 coat',
        '2 coats water proofing cement paint',
        'Distemper 2 coats',
         'Weather coat',
        'ewhs by mechanical means',
       'cess',
       'L.R.C.',
       'W.C.',
       'displaboard & photograph',
       'plate vibrator',
       'M.S. D & W',
       'diff. cost cement',
       'diff. cost hysd bar',
       'deff. cost u/s labour',
       'diff cost s/s labour',
       'diff cost Mason II',
       'diff cost Mason I')

        )

def maketable(entries,entries1):
    a = bill_form('bmfp',float(entries['B.M.F.P.C.B.(1:6)'].get()),float(entries1['B.M.F.P.C.B.(1:6)'].get()))
    b = bill_form('rcc', float(entries['C.C.(1:1.5:3)'].get()),float(entries1['C.C.(1:1.5:3)'].get()))
    c = bill_form('cc148', float(entries['C.C.(1:4:8)'].get()),float(entries1['C.C.(1:4:8)'].get()))
    d = bill_form('rscscolumn', float(entries['R.S./C.S. Column'].get()), float(entries1['R.S./C.S. Column'].get()))
    e = bill_form('rscsplinth', float(entries['R.S./C.S. Plinth'].get()), float(entries1['R.S./C.S. Plinth'].get()))
    f = bill_form('efhs', float(entries['efhs'].get()), float(entries1['efhs'].get()))
    g = bill_form('hysd', float(entries['Reinforcement'].get()),float(entries['Reinforcement'].get()))
    h = bill_form('paint', float(entries['Painting 2 coats Priming 1 coat'].get()), float(entries1['Painting 2 coats Priming 1 coat'].get()))
    i = bill_form('wpcp',float(entries['2 coats water proofing cement paint'].get()),float(entries1['2 coats water proofing cement paint'].get()))
    j = bill_form('12cp(1:6)', float(entries['12mm C.P.(1:6)'].get()), float(entries1['12mm C.P.(1:6)'].get()))
    k = bill_form('sandfill', float(entries['filling sand'].get()), float(entries1['filling sand'].get()))
    l = bill_form('asf(1:2:4)', float(entries['A.S.F. with C.C. (1:2:4)'].get()), float(entries1['A.S.F. with C.C. (1:2:4)'].get()))
    m = bill_form('16cp(1:6)', float(entries['16mm C.P.(1:6)'].get()), float(entries1['16mm C.P.(1:6)'].get()))
    n = bill_form('rcc M-20', float(entries['R.C.C. M-20'].get()), float(entries1['R.C.C. M-20'].get()))
    o = bill_form('rscsslab', float(entries['R.S./C.S. Slab'].get()), float(entries1['R.S./C.S. Slab'].get()))
    p = bill_form('rscswalls', float(entries['R.S./C.S. Slab'].get()), float(entries1['R.S./C.S. Slab'].get()))
    q = bill_form('20cp(1:4)', float(entries['20mm C.P.(1:4)'].get()), float(entries1['20mm C.P.(1:4)'].get()))
    r = bill_form('cc136', float(entries['C.C.(1:3:6)'].get()), float(entries1['C.C.(1:3:6)'].get()))
    s = bill_form('cc124', float(entries['C.C.(1:2:4)'].get()), float(entries1['C.C.(1:2:4)'].get()))
    t = bill_form('rscslintel', float(entries['R.S./C.S. Lintel'].get()), float(entries1['R.S./C.S. Lintel'].get()))
    u = bill_form('20cp(1:6)', float(entries['20mm C.P.(1:6)'].get()), float(entries1['20mm C.P.(1:6)'].get()))
    v = bill_form('6cp(1:4)', float(entries['6mm C.P.(1:4) on R.C.C.'].get()), float(entries1['6mm C.P.(1:4) on R.C.C.'].get()))
    w = bill_form('distemper', float(entries['Distemper 2 coats'].get()), float(entries1['Distemper 2 coats'].get()))
    x = bill_form('vitrified', float(entries['Vitrified Tile Floor'].get()), float(entries1['Vitrified Tile Floor'].get()))
    y = bill_form('ewhs', float(entries['ewhs'].get()), float(entries1['ewhs'].get()))
    a1 = bill_form('rrhg', float(entries['R.R.H.G.S.M.(1:6)'].get()), float(entries1['R.R.H.G.S.M.(1:6)'].get()))
    a2 = bill_form('bmfps', float(entries['B.M.F.P.F.A.(1:6)'].get()), float(entries1['B.M.F.P.F.A.(1:6)'].get()))
    a3 = bill_form('bmfps1', float(entries['B.M.S.S.F.A.(1:6)'].get()), float(entries1['B.M.S.S.F.A.(1:6)'].get()))
    a4 = bill_form('floor_tile', float(entries['Ceramic Tile Floor'].get()), float(entries1['Ceramic Tile Floor'].get()))
    a5 = bill_form('wall_tile', float(entries['Ceramic Wall Tile'].get()), float(entries1['Ceramic Wall Tile'].get()))
    a6 = bill_form('12cp(1:4)', float(entries['12mm C.P.(1:4)'].get()), float(entries1['12mm C.P.(1:4)'].get()))
    a7 = bill_form('pcc M-20', float(entries['P.C.C. M-20'].get()), float(entries1['P.C.C. M-20'].get()))
    a8 = bill_form('crhg', float(entries['C.R.H.G.S.M.(1:6)'].get()), float(entries1['C.R.H.G.S.M.(1:6)'].get()))
    z = a.append(b).append(c).append(d).append(e).append(f).append(g).append(h).append(i).append(j).append(k).append(l). \
        append(m).append(n).append(o).append(p).append(q).append(r).append(s).append(t).append(u).append(v).append(w). \
        append(x).append(y).append(a1).append(a2).append(a3).append(a4).append(a5).append(a6).append(a7).append(a8)



    total_amount=z['Amount'].sum()
    z['Amount']=z['Amount'].map('Rs.{:.2f}'.format)
    z['Rate'] = z['Rate'].map('Rs.{:.2f}'.format)
    x = deduction([['E.G.B.', 126],
                   ['S.D.', 0],
                   ['Royalty', 0],
                   ['Cess', 480],
                   ['W.C.', 0],
                   ['VAT', 73]])
    x.deduct()
    print('Comp. Voucher No.\t  RUNNING ACCOUNT BILL\t Voucher No.')
    print('Date___________\t\t\t\t\t\tDate_______')
    print('\tTo be used for payment for work (Supplies actually measured)')
    print('-' * 80)
    print('-')
    print('Name of work:-',entries['Name of the work'].get())
    print('Head of Account:-',entries['Head of Account'].get())
    print('Estimated Cost:-Rs.',entries['Estimated Cost'].get())
    # print('Tendered Value:-\u20B91,25,00,000.00')
    print('Serial number of this bill:-',entries['Serial No. of the Bill'].get())
    print('Date of commencement of the work:-______________')
    print('Date of completion of the work:-________________')
    print('Name of the executant/V.L.L.:-',entries['Name of the executant'].get(),'\n')
    print('\t\tACCOUNT OF WORK DONE OR SUPPLY MADE')
    print('-' * 80)
    print(z[z['Quantity'] != 0],'\n\n\t\tTotal Amount = ',total_amount)#bill body
    print('-' * 80)
    x = deduction([['E.G.B.', 126],
                   ['S.D.', 0],
                   ['Royalty', 0],
                   ['Cess', 480],
                   ['W.C.', 0],
                   ['VAT', 73]])
    x.deduct()
    print(textwrap.fill(
        '''\tThe full name of the work as given in the estimate should be entered here expent in the case of bill for stock materials. The purpose of supply applicable to case should be filled in and the last scored out. Not required in the case of work done or supplies made under a piece work agreement. If the outlay on the work is recorded by subheads the total for each sub heads should be shown in column 5 and against this total there should be an entry in column 6 also in on other case should any entries be made in column 6'''),
          80)
    print('\t\t\tCERTIFICATE AND SIGNATURE')
    print('\t\t\t', '-' * 24)
    print('The measurements were made by me on',entries['Date'].get(),'and are recorded at pages',entries['Page No.'].get(),'\n',' of the measurement book no.',entries['Measurement Book No.'].get())
    print(textwrap.fill('''No advance payment has been made previously with
    measurement the work has been done with due deligence in approved specification.''',80))
    print('\n\n\n\tExecutant\tAssistant Engineer\tJunior Engineer\n')
    print('\t\t\tMEMORANDUM OF PAYMENT')
    print('\t\t\t', '-' * 20)
    print('1. Total value of work done.........................')
    print('2. DEDUCTION')
    print('\t a. Advance.......................................')
    print('\t b. Amount paid in the R/A........................')
    print('3. Balance..........................................')
    print('4. REALISATION')
    x.deduct()
    print('\t\t\t\t\t\tNet Payable \u20B9')
    print('-' * 80)
    print('''Passed for payment of \u20B9...........(Rupees...........................) only ''')
    print(textwrap.fill('''Realise a sum of \u20B9........... (Rupees..................................)only
    as detailed above.'''), 80)
    print('Net Payable: \u20B9..........(Rupees....................................... )only')
    print('Countersigned\n\n')
    print('Chairman\t\t\t\tBlock Development Officer')
    print('''Received \u20B9........(Rupees...........\tPaid \u20B9 vide cheque no..........''')
    print('\t\t\t\t\tDated............A/C No............')
    print('\t\t\t\t\t& Realised\u20B9..............vide MR No.....')
    print('\t\t\t\t\tDated......... Total \u20B9..........')
    print('Recipient')
    print('\n\n\t\t\t\t\tBlock Development Officer')

def makeform(root,fields):
    entries={}
    entries1 = {}
    for fields in fields:
        column = Frame(root,bg='blue')
        column.pack(side=LEFT,fill=X,padx=0,pady=0)
        for field in fields :
            row=Frame(column,bg ='red')
            lab = Label(row,width=30,text=field+":",relief=RAISED,activebackground='red',anchor='w',bg="yellow",fg="black")
            ent= Entry(row,bg="blue",fg="white")
            ent1 = Entry(row,bg="white",fg="blue")
            ent.insert(0,"0")
            ent1.insert(0,"0")
            row.pack(side=TOP,fill=X,padx=0,pady=0)
            lab.pack(side=LEFT)
            ent1.pack(side=RIGHT, expand=YES, fill=X)
            ent.pack(side=RIGHT,expand = YES,fill=X)
            entries[field]=ent
            entries1[field] = ent1

    return [entries,entries1]
def fetch(entries):
    for entry in entries:
        print('Input => "%s"' % entry.get())


if __name__ == "__main__":
    root = Tk()
    root.title("Form No. XXXVII")
    ents = makeform(root, fields)
    # ent1s = makeform(root, fields)
    root.bind('<Return>', (lambda event, e=ents: fetch(e)))
    # root.bind('<Return>', (lambda event, e1=ent1s: fetch(e1)))

    b1 = Button(root, text='Create', bg='cyan', relief=RAISED,bd=10,activeforeground='yellow',activebackground='red',command=(lambda e=ents[0], e1=ents[1]: maketable(e,e1)))
    b1.pack(side=BOTTOM, padx=5, pady=5)
    # b2 = Button(root, text='Return1', bg='cyan', command=(lambda e1=ent1s: maketable( e1)))
    # b2.pack(side=BOTTOM, padx=5, pady=5)
    root.mainloop()