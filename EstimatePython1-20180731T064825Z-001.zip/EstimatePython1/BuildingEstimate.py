#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jul 29 17:58:36 2018

@author: spalo
"""
import pandas as pd
import numpy as np

class Building():
    def __init__(self,foundation):
        self.foundation = foundation
    def foundation():



