import ClassLibrary as cl
import items as it
import FunctionLibraryR as fr




print(it.items['efhs'])
foundation=cl.Quantity([['walls of tube well platform',4,2.2,1.5,1.5],
                        ['Drain',1,4.5,0.9,0.3]])
foundation.rate=fr.foundation(1)
foundation.volume()
print(it.items['CC(1:3:6)'])
pcc=cl.Quantity([['']])







































































