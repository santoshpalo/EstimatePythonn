import ClassLibrary as cl
import items as it
import FunctionLibraryR as fr





print('Calculation of Total Centre Line length')
tcl =[['long walls',2,15.54],
      ['short walls',3,5.18+.25]]
tcl = cl.Quantity(tcl)
tcl.tcl()
print(it.items['12cp(1:6)'])
cp12=[['all walls sides',1,47.37+3*.25,4.37],
      ['parapet inner side',1,2*15.54+2*5.18-4*.25-1.2,0.6],

      ['door 1 opening',-1/2,1.85,2.05],
      ['door 2 opening',-1/2,1.17,2.05],
      ['windows opening',7/2,1.8,1.3],
      ['back side chajja ',4*2,2.1,0.5],
      ['front side chajja slant portion ',3*2,2.1,1.5],
      ['front side chajja top and bottom',3,1.8,0.5+0.43],
      ['front side chajja side triangular faces',3*2*2*0.5,1.2,0.8],
      ['chajja bottom projections top',7*2,0.65/2,0.55],
      ['chajja bottom projections top',7*2,0.35,0.75],
      ['window sill projections',7,1.92,0.35]]
cp12=cl.Quantity(cp12)
cp12.rate=100
cp12.vArea()
print(it.items['16cp(1:6)'])
cp16=[['all walls sides',1,47.37-5*.25,3.3],
      ['door 1 opening',-1/2,1.85,2.05],
      ['door 2 opening',-1/2,1.17,2.05],
      ['windows opening',-0.5*7,1.8,1.3]
      ]
cp16=cl.Quantity(cp16)
cp16.rate=100
cp16.vArea()
print(it.items['vitrified'])
vitrified=[['hall',1,13.08,5.18],
           ['inside room',1,5.2,1.95],
           ['steps at front',2,1.8,0.25]]
vitrified=cl.Quantity(vitrified)
vitrified.rate=100
vitrified.hArea()
walltile=[['hall long wall',2,13.08,0.75],
          ['hall short wall',2,5.18,0.75],
          ['inner hall',2,5.2,0.75],
          ['inner hall 2',2,1.96,0.9],
          ['door 1 opening', -1, 1.85-.5,0.75],
          ['door 2 opening', -1, 1.17-.5,0.75],
          ['steps in puja',2,0.7,0.2],
          ['steps in puja 1',2,0.4,0.2],
          ['steps in puja 2',2,0.25,0.2]]
walltile=cl.Quantity(walltile)
walltile.rate=100
walltile.vArea()
print(it.items['bmsscb'])
brick=[['over the chajjas',6,0.25,0.08,0.7]]
brick=cl.Quantity(brick)
brick.rate=100
brick.volume()
print(it.items['msdoor'])
print('\n 7 nos. windows @ 115.00kg / window = 785.00kg @ \u20B965.00= \u20B951025.00')
print('\n 1 no door at entrance = 140.00kg @ \u20B965.00/kg. =\u20B99100.00')
print('\n 1 no door at internal wall = 90.00kg @ \u20B965.00/kg = \u20B9 5850.00 ')





