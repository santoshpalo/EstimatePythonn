# IPython log file

6.4+.4-.08
#[Out]# 6.720000000000001
6.4+.4-.08
#[Out]# 6.720000000000001
12*6.72
#[Out]# 80.64
4.5+.4-.08
#[Out]# 4.82
4.82*6*2
#[Out]# 57.84
80.64+57.84
#[Out]# 138.48000000000002
138.48*.062
#[Out]# 8.585759999999999
138.48*.62
#[Out]# 85.85759999999999
21.8/.15
#[Out]# 145.33333333333334
.32+.11
#[Out]# 0.43
2*.43+.08
#[Out]# 0.94
.94*145*.0395
#[Out]# 5.38385
.86+.54
#[Out]# 1.4
1.4/1.05
#[Out]# 1.3333333333333333
1.33-85.86
#[Out]# -84.53
1.33-.8586
#[Out]# 0.47140000000000004
47.14/53.84*145
#[Out]# 126.95579494799405
127*.94
#[Out]# 119.38
119.38*.395
#[Out]# 47.1551
85.86+47.16
#[Out]# 133.01999999999998
133.02*1.05
#[Out]# 139.67100000000002
4519+6948+8840+5380+0
#[Out]# 25687
runfile('/home/spalo/Documents/EstimatePython1/JabdaCommunityCentre.py')
runfile('/home/spalo/Documents/EstimatePython1/JabdaCommunityCentre.py')
runfile('/home/spalo/Documents/EstimatePython1/JabdaCommunityCentre.py')
runfile('/home/spalo/Documents/EstimatePython1/JabdaCommunityCentre.py')
runfile('/home/spalo/Documents/EstimatePython1/JabdaCommunityCentre.py')
6020/1.4
#[Out]# 4300.0
runfile('/home/spalo/Documents/EstimatePython1/JabdaCommunityCentre.py')
1.33*4868.07
#[Out]# 6474.5331
4519+6948+8840+5380+6475+526+1282+300
#[Out]# 34270
34270+345
#[Out]# 34615
get_ipython().run_line_magic('clear', '')
runfile('/home/spalo/Documents/EstimatePython1/JabdaCommunityCentre.py')
runfile('/home/spalo/Documents/EstimatePython1/JabdaCommunityCentre.py')
