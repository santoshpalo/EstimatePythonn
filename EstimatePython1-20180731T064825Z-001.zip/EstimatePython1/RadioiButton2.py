from tkinter import *
def royalty():
    selection = var.get()
    if selection == 1:
        Royalty = [0,0]
    else:
        Royalty = [38.4,138.3]
    return (Royalty)
master = Tk()
var = IntVar()
Label(master,text = "Select Scheme for Royalty").grid(row=0,sticky=W)
Radiobutton(master,text="MGNREGS",variable = var,value = 1).grid(row = 1,sticky=W)
Radiobutton(master,text="OTHERS",variable = var,value = 2).grid(row = 2,sticky=W)
Button(master,text="OK",command= royalty).grid(row=3,sticky=W)
mainloop()
