import ClassLibrary as cl
import pandas as pd
import FunctionLibraryR as fl
pd.set_option('max_colwidth', 0)
pd.set_option('display.expand_frame_repr', False)
pd.set_option('display.precision', 2)


data=[['Excavation of foundation trench',63.22,'cum',115.74],
      ['Filling sand in F & P',27.96,'cum',304.39],
      ['Cement concrete (1:3:6)',12.89,'cum',3523.92],
#      ['Cement concrete (1:2:4)',6.28,'cum',4679.56],
      ['Brick masonry fly ash (1:6) F&P',7.38,'cum',3187.1],
      ['R.C.C. M-20 grade concrete',28.4,'cum',4113.08],
      ['Fly ash Brick Masonry (1:6) S/S',28.01,'cum',3220.1],
      ['Reinforcement works in R.C.C.',25,'qtl',6035.43],
      ['R/S C/S works in plinth and footiong',139.16,'sqm',80.36],
      ['R/S C/S works in beam & Column',73.16,'sqm',482.61],
      ['R/S C/S works in lintel', 16.43, 'sqm', 198.12],
      ['R/S C/S works in slab and chajja',52.91,'sqm',308.92],
#      ['R/S C/S works in stair case',18.34,'sqm',387.23],
#      ['R/S C/S works in walls',171,'sqm',411.48],
      ['20mm thick plaster(1:4)',58.95,'sqm',144.82],
#      ['20 mm thick plaster (1:6)',101.86,'sqm',134.82],
      ['16mm thiock plaster (1:6)',138.94,'sqm',125.93],
      ['12mm thick plaster (1:6)',108.23,'sqm',88.74],
      ['12mm thick plaster(1:4)',8.1,'sqm',109.77],
      ['6mm thick plaster (1:4)',81.27,'sqm',94.15],
      ['M.S. Doors and windows',3.5,'qtl',7000],
      ['A.C. sheet doors for toilets',3,'nos',5000],
      ['A.S. flooring (1:2:4)',3.0,'sqm',208.35],
      ['vitrified tile floor',28.56,'sqm',860.87],
      ['Ceramic tiles flooring',12,'sqm',245.51],
      ['Ceramic wall tile',64.98,'sqm',248.55],
      ['Door and window painting',21.24,'sqm',92.09],
      ['Priming on plastered surface',1218.16,'sqm',27.34],
      ['Finishing wall surface with putty',121.54,'sqm',26],
      ['Wall painting with 2 coats weather paint',111.19,'sqm',29.71],
      ['Distempering 2 coats on finished wall surface',132.43,'sqm',30.85],
#      ['Water proofing cement paint',33.1,'sqm',14.03],
      ['Cost of distemper',33.1,'kg',66.81],
      ['Cost of weather coat',13.9,'ltr',193.88],
      ['Cement based wall putty',97.23,'kg',38.69],
      ['wall primer',102.36,'ltr',155.58],
      ['enamel paint',2.66,'ltr',194.89],
      ['red oxide primer',1.15,'ltr',120.22],
#      ['water proofing cement paint',39.65,'kg',32.81],
      ['ceramic glazed wall tile',64.98,'sqm',368.24],
      ['ceramic glazed floor tile',12,'sqm',407.28],
#      ['Stainless steel hand railing',40,'m',2933.4],
      ['Cess for welfare of labourers',1,'unit',10000],
      ['Cost towards dispaly board, photograph, T&P',1,'unit',5000],
      ['Provision for electrification and sanitary ',1,'unit',248383]]
table=cl.Quantity(data)
table.cost_material()
fl.signature(4000000,'Forty lakh only',6,'')