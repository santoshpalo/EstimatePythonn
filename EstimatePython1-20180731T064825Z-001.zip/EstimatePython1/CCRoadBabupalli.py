import items as it
import ClassLibrary as cl
import FunctionLibraryR as fr
t1=.1
t2=.09
t3=0.15



surface_area = [['bell mouth',1,5.18,(5.49+3.2)/2],
                ['patch 1',1,13.72,(3.2+2.94)/2],
                ['patch 2',1,13.72,(2.94+2.82)/2],
                ['patch 3',1,18.9,(2.82+3.05+2.75)/3],
                ['patch 3',1,3.96,2.75],
                ['patch 4',1,4.14,3.81],
                ['patch 5',1,3.96,1.2]]
surface_area = cl.Quantity(surface_area)
surface_area.surface_area()
cut_off_wall=[['normal cut-off wall',2,45,0.2],
              ['deep cut-off wall 1',1,15,0.3],
              ['deep cut-off wall 2',1,15,0.25]]
cut_off_wall=cl.Quantity(cut_off_wall)
cut_off_wall.surface_area()
foundation=[['normal cut-off wall',2,45,0.2,0.15],
              ['deep cut-off wall 1',1,15,0.3,.45],
              ['deep cut-off wall 2',1,15,0.25,0.25]]
foundation=cl.Quantity(foundation)
foundation.rate=110.17
foundation.volume()
cc124 = [['bell mouth',1,5.18,(5.49+3.2)/2,t1],
                ['patch 1',1,13.72,(3.2+2.94)/2,t1],
                ['patch 2',1,13.72,(2.94+2.82)/2,t1],
                ['patch 3',1,18.9,(2.82+3.05+2.75)/3,t1],
                ['patch 3',1,3.96,2.75,t1],
                ['patch 4',1,4.14,3.81,t1],
                ['patch 5',1,3.96,1.2,t1]]
cc124=cl.Quantity(cc124)
cc124.rate=4383.35
cc124.volume()
cc124 = [['bell mouth',1,5.18,(5.49+3.2)/2,t2],
                ['patch 1',1,13.72,(3.2+2.94)/2,t2],
                ['patch 2',1,13.72,(2.94+2.82)/2,t2],
                ['patch 3',1,18.9,(2.82+3.05+2.75)/3,t2],
                ['patch 3',1,3.96,2.75,t2],
                ['patch 4',1,4.14,3.81,t2],
                ['patch 5',1,3.96,1.2,t2],
         ['normal cut-off wall', 2, 45, 0.2,0.15],
         ['deep cut-off wall 1', 1, 15, 0.3,0.45],
         ['deep cut-off wall 2', 1, 15, 0.25,0.25]
         ]
cc124=cl.Quantity(cc124)
cc124.rate=3524.35
cc124.volume()
sand_filling=[['builtup area',189.86,0.2],
              ['cut-off wall area',-26.25,0.20]
              ]
sand_filling=cl.Quantity(sand_filling)
sand_filling.rate=304.17
sand_filling.areaVolume()
mechanical_earth_fill=[['deep area filling 1',1,15,0.6,1.2,1.5],
                       ['deep area filling 1', 1, 15, 1.5, 3, 1.5],
                       ['oher area filling',2,45,0.6,0.9,0.3]]
mechanical_earth_fill=cl.Quantity(mechanical_earth_fill)
mechanical_earth_fill.rate=fr.earthwork_mechanical()
mechanical_earth_fill.trapezoidalVolume()
cutoffcentering=[['normal cut-off wall',2*2,45,0.3],
              ['deep cut-off wall 1',1*2,15,.5],
              ['deep cut-off wall 2',1*2,15,0.35]]
cutoffcentering=cl.Quantity(cutoffcentering)
cutoffcentering.rate=83.43
cutoffcentering.vArea()
print('Hire and Running Charges of Plate Vibrator = 9.10 hr @\u20B9106.00/hr. \u20B9965')
print('Cost for display board and photograph = \u20B92000.00')
print('Departmental contingency = \u20B91000.00')
print('Cess for welfare of labourers = \u20B92000.00')



