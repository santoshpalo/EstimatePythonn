#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 11 16:38:36 2018

@author: spalo
"""

import pandas as pd
import FunctionLibraryR as fl
import items as it
import math as mt
class RenovateTank():
    def __init__(self,length,breadth,depth):
        self.length=length
        self.breadth=breadth
        self.depth=depth
    def excavationR(self):
        data=[[self.length,self.breadth,self.depth]]
        table=pd.DataFrame(data,index=['tank excavation'],columns=['length','breadth','depth'])
        table['volume']=round(table['length']*table['breadth']*table['depth'],2)
        sumVolume=table['volume'].sum()
        table['length']=table['length'].map('{:.2f}m'.format)
        table['breadth']=table['breadth'].map('{:.2f}m'.format)
        table['depth']=table['depth'].map('{:.2f}m'.format)
        table['volume']=table['volume'].map('{:.2f}cum'.format)
        return [table,sumVolume,sumVolume*fl.earthwork_mechanical(0)]
    def excavation(self):
        print('\n',it.items['Earth_work_mechanical'],'\n',self.excavationR()[0],'\n\t\t\t','{:.2f}cum'.format(self.excavationR()[1]),'@ \u20B9{:.2f}/cum = '.format(fl.earthwork_mechanical(0)),'\u20B9{:.2f}'.format(mt.ceil(self.excavationR()[2])))
    def miscellaneousR(self):
        return 2500.00
    def miscellaneous(self):
        print('\nProvisional cost for display board and photograph = \u20B9',self.miscellaneousR())
    def cessR(self):
        return mt.ceil((self.excavationR()[2]+self.miscellaneousR())*.01)
    def cess(self):
        print('\nProvision for cess for welfare of labourers = \u20B9',self.cessR())
    def totalR(self):
        return mt.ceil(self.cessR()/.01*1.01)