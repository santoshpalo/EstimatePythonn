gifdir = "/home/spalo/Pictures/"
from tkinter import *
win = Tk()
img = PhotoImage(file=gifdir + "a_girl.png")
can = Canvas(win)
can.pack(fill=BOTH)
can.config(width=img.width(), height=img.height())
can.create_image(15, 15, image=img, anchor=NW)
win.mainloop()