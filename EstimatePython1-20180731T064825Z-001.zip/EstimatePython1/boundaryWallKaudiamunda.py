import ClassLibrary as cl
import FunctionLibraryR as fl
import items as it
print(it.items['efhs'])
foundation = [['length of wall',1,79.71,0.7,0.75]]
foundation=cl.Quantity(foundation)
foundation.rate = fl.foundation(1)
foundation.volume()
print(it.items['CC(1:4:8)'])
concrete = [['walls',1,79.71,0.75,0.1]]
concrete = cl.Quantity(concrete)
concrete.rate=fl.concrete(1)
concrete.volume()
print(it.items['bmfpfa'])
bmfp= [['long wall',1,79.71,0.38,0.6],
       ['deduct rcc',-1,79.71,0.25,0.13]]
bmfp=cl.Quantity(bmfp)
bmfp.rate=fl.brickmasonry(2)[0]
bmfp.volume()
print(it.items['bmssfa'])
bmss = [['wall',1,79.71,0.25,1.68],
        ['pillars',17,0.38,0.13,1.68]]
bmss=cl.Quantity(bmss)
bmss.rate = fl.brickmasonry(2)[1]
bmss.volume()
print(it.items['m20'])
rcc= [['plinth bend',1,79.71,0.25,0.13]]
rcc=cl.Quantity(rcc)
rcc.rate = fl.gradedconcrete(2)
rcc.volume()
print(it.items['12cp(1:6)'])
plaster12=[['wall one side',1,79.71,1.68],
           ['pillars',9*2,0.065,1.68]]
plaster12=cl.Quantity(plaster12)
plaster12.rate=fl.plaster(1)
plaster12.vArea()
print(it.items['16cp(1:6)'])
plaster16=[['wall one side',1,79.71,1.68],
           ['pillars',9*2,0.065,1.68]]
plaster16=cl.Quantity(plaster16)
plaster16.rate=fl.plaster(2)
plaster16.vArea()
print(it.items['hysd'])
reinforcement=[['main bars',4,79.71,0.62],
               ['stirrups',530,.06*2+.18*2+.07,.395]]
reinforcement=cl.Quantity(reinforcement)
reinforcement.rate=fl.reinforcement()
reinforcement.reinforcement()
print('Cess for welfare of labourers = \u20B92500.00')
print('Display Board = \u20B92000.00')
print('Work contingency = \u20B91250.00')
print('='*80)
print('Limited to \u20B92,50,000.00')
print(fl.signature(250000,'Rupees two lakh fifty thousand only',3,'Sankara G.P.'))