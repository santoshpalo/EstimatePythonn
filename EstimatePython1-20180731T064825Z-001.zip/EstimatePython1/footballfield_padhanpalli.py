import ClassLibrary as cl
import items as it
import FunctionLibraryR as fr
L=10
l=6.0








if __name__ == "__main__":
    print('Name of the work :-Improvement of Footbill field at Padhanpalli of Jullunda G.P. ')
    print('Estimated Cost:-\u20B91,50,000.00\tHead of Account:-M.P.L.A.D.(2014-15)')
    print('-'*80)
    tcl=cl.Quantity([['long walls',1,L],
                     ['short walls',2,l]])
    tcl.tcl()
    print(it.items['efhs'])
    foundation = cl.Quantity([['alround length',1,22.0,0.75,0.75],
                              ['steps',3,1.8,0.4]])
    foundation.rate=fr.foundation(1)
    foundation.volume()
    print(it.items['CC(1:3:6)'])
    pcc = cl.Quantity([['alround walls',1,22.0,0.75,0.1],
                       ['steps',3,1.8,0.1],
                       ['sub base',1,9.5,5.5,0.1]])
    pcc.rate=fr.concrete(2)
    pcc.volume()
    brick=cl.Quantity([['alround walls ist footing',1,22,0.38,0.6],
                       ['alround walls 2nd footings',1,22,0.25,1.2],
                       ['steps footing 1',3,1.8,1.8,0.25],
                       ['steps footiongs 2',3,1.8,1.5,0.15],
                       ['steps footings 3',3,1.8,1.25,0.15],
                       ['steps footings 4',3,1.8,1.0,0.15],
                       ['steps footings 5',3,1.8,0.75,0.15],
                       ['steps footings 6',3,1.8,0.5,0.15],
                       ['steps footings 7',3,1.8,0.25,0.15]])
    brick.rate= fr.brickmasonry(2)[0]
    brick.volume()
    print(it.items['sand_filling'])
    sandfill=cl.Quantity([['under the pendal',1,L-0.5,l-0.5,1.2],
                          ['in the foundation',1,22,0.75,0.1]])
    sandfill.rate=fr.sandfilling()
    sandfill.volume()
    print(it.items['m20'])
    rcc=cl.Quantity([['bend at top of wall',1,22,0.25,0.1],
                     ])
    rcc.rate=fr.gradedconcrete(2)
    rcc.volume()
    print(it.items['hysd'])
    reinforcement=cl.Quantity([['longwalls main bars',2*2,L-.08,0.62],
                               ['short walls main bars',2*2,6.0-.08,0.62],
                               ['stirrups',170,0.28,0.395]])
    reinforcement.rate=fr.reinforcement()
    reinforcement.reinforcement()
    print(it.items['CC(1:2:4)'])
    pcc124=cl.Quantity([['pendal top',1,L,l,0.1]])
    pcc124.rate=fr.concrete(3)
    pcc124.volume()
    print(it.items['12cp(1:6)'])
    plaster12=cl.Quantity([['alround walls',1,22+1,1.5]])
    plaster12.rate=fr.plaster(1)
    plaster12.vArea()
    print(it.items['wpcp'])
    wpcp = cl.Quantity([['alround walls',1,22+1,1.5]])
    wpcp.rate = fr.waterproofpaint()
    wpcp.vArea()
    print('Cess for weelfare of labourers = \u20B91500.00')
    print('Display board and photograph = \u20B91500.00')
    print('Cost of waterproofing cement paint = 8.63kg @ \u20B935.00 = \u20B9305.00')
    print('Labour registration cess = \u20B9100.00')
    print('='*80)
    fr.signature(150000,'one lakh fifty thousand only',1,'')






