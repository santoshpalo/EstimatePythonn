import PyEstimate.ClassLibrary as cl
import items as it
import FunctionLibrary as fl

l = 25
l1 = 4











if __name__ == "__main__":
    print('Expenditure incurred in first R / A bill vide M.B. No. 563 pages(177-182) =''\u20B9{:.2f}'.format(275988))
    print('\nDETAILED OF THE WORKS EXECUTED IN THE 2nd R/A BILL vide M.B. No.   /Page No.(        )')
    print(it.items['efhs'])
    exc = cl.Quantity([['road',2,l,0.2,0.25],
                       ['Guard wall at Nallah',1,l1,1.2,0.9]])
    exc.rate=103.2
    exc.volume()


    print(it.items['sand_filling'])
    sandfilling = cl.Quantity([['builtup area',1,l,3.65-.4,.05],
                               ['Guard wall foundation',1,l1,0.9,0.15]])
    sandfilling.rate = 302.62
    sandfilling.volume()

    print(it.items['CC(1:3:6)'])
    subbase=cl.Quantity([['subbase',1,l,3.45,0.09],
                         ['cut-off wall',2,l,0.2,0.25]])
    subbase.rate= 3647.57
    subbase.volume()
    guardwall = cl.Quantity([['guard wall 1',1,l1,0.4,0.75,2.1]
                             ])
    
    guardwall.rate =3647.57
    guardwall.trapezoidalVolume()
    print(it.items['CC(1:2:4)'])

    crust=cl.Quantity([['area of crust',1,l,3.65,0.08]
                       ])
    crust.rate=4749.14
    crust.volume()

    print(it.items['rscs_plinth'])
    centeringcutoff = cl.Quantity([
                             ['cut-off walls of road',2*2,l,(.05+.05+.2)/2]])
    centeringcutoff.rate = 82.08
    centeringcutoff.vArea()
    print(it.items['Earth_work_mechanical'])
    earthwork=cl.Quantity([['in berms',1,10,10,1.3]])
    earthwork.rate = 118.9
    earthwork.volume()
    print('Hire and running charges of plate vibrator =2.92 hr @ Rs.106.00/ hour = Rs.310.00 ')
    print('Cess for welfare of labourers = ','\u20B9{:.2f}'.format(1080))
    print('Departmental contingency = ','\u20B9{:.2f}'.format(1080))
    print('-'*80)
    fl.signature(383000,'Three lakh eighty three thousand only',1,'')
    
    
    
    
    
    
    
    