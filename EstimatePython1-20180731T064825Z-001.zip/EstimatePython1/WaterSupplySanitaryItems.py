import textwrap
items = {'Indian W.C. Pan':textwrap.fill('''Fixing water closet, squatting pan (Indian type W.C. pan conforming to IS 2556: Part3 -2004 duly embeddedin cement
caloncrete (1:4:8) using hard granite metal 4cm nominal size all complete as per specification'''),
         'P or S trap':textwrap.fill('''Fixing 100mm size P or S trap (with horn or without horn) for water closet squatting pan including jointing the trap with pan in cement mortar (1:1) as per specification'''),
         'fixing pvc pipes':textwrap.fill('Providing and fixing to wallor celing and floor pvc pipes class conforming to ASTM-D1785/04(Sch-80) and pipe fittings of the following nominal bore with clamps including making good to the wall, ceiling and floor all complete as per specification',80),
}