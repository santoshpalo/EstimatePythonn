import ClassLibrary as cl 
import FunctionLibrary as fl
import items as it










if __name__ == "__main__":
    print('''Name of the Work:- Construction of C.C. road from P.M.G.S.Y. road to
Khairapada via GaiGoth''')
    print('Head of Account:-G.G.Y. (2016-17)\tEstimated Cost:-\u20B92,00,000.00')
    print('-'*80)
    print(it.items['efhs'])
    foundation = cl.Quantity([['cut-off walls',2,53,0.2,0.2]
                              ])
    foundation.rate = 103.2
    foundation.volume()
    print(it.items['sand_fill'])
    sand_fill = cl.Quantity([['road subgrade',1,53,3.65-.4,.15]])
    sand_fill.rate = 313.52
    sand_fill.volume()
    print(it.items['CC(1:3:6)'])
    metal_concrete = cl.Quantity([['cut-off walls',2,53,0.2,0.25],
                                  ['sub-base concrete',1,53,3.65,0.1],
                                  
                                  ])
    metal_concrete.rate = 3700.47
    metal_concrete.volume()
    print(it.items['CC(1:2:4)'])
    chips_concrete = cl.Quantity([['crust of the road',1,53,3.65,0.1]])
    chips_concrete.rate =4814.96
    chips_concrete.volume()
    print(it.items['rscs_plinth'])
    cut_off = cl.Quantity([['outside cut-off',2,53,0.05+.2],
                           ['inside cut-off',2,53,0.05]
                           ])
    cut_off.rate = 82.08
    cut_off.vArea()
    #===========================================================================
    # print('\nCost and conveyance of hume pipes 5.0m @\u20B01884.00 = \u20B99420.00')
    #===========================================================================
    #===========================================================================
    # print('\nConveyance and laying of hume pipes at position = \u20B91000.00')
    #===========================================================================
    print('\nCost towards hire and running of plate vibrator')
    print('\n\t\t\t7.73 hour @ \u20B9 106.00/ hour = \u20B9 819.00')
    print('\n\t\t\tCess for welfare of labourers = \u20B9 3000.00')
    print('\n\t\t\tDepartmental contingency \u20B9 3000.00')
    print('\n\t\t\tDisplay board and photograph = \u20B9 2000.00')
    print('-'*80)
    fl.signature(20000,'Rupees two lakh only', 1, '')
    
    
    
    
    
    
    
     