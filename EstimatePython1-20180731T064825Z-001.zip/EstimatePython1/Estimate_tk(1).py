from tkinter import *
import pandas as pd
import ClassLibrary as cl
def tcl(data,index=rangelen(1,(data)),columns=):








fields_tcl=(('length_X_1',
             'length_X_2',
             'length_X_3',
             'length_X_4',
             'length_X_5',
             'length_X_6'),
            ('length_Y_1',
             'length_Y_2',
             'length_Y_3',
             'length_Y_4',
             'length_Y_5',
             'length_Y_6')
            )




def makeform_tcl(root,fields):
    entries={}
    entries1 = {}
    for fields in fields:
        column = Frame(root,bg='blue')
        column.pack(side=LEFT,fill=X,padx=0,pady=0)
        for field in fields :
            row=Frame(column,bg ='red')
            lab = Label(row,width=30,text=field+":",relief=RAISED,activebackground='red',anchor='w',bg="yellow",fg="black")
            ent= Entry(row,bg="blue",fg="white")
            ent1 = Entry(row,bg="white",fg="blue")
            ent.insert(0,"0")
            ent1.insert(0,"0")
            row.pack(side=TOP,fill=X,padx=0,pady=0)
            lab.pack(side=LEFT)
            ent1.pack(side=RIGHT, expand=YES, fill=X)
            ent.pack(side=RIGHT,expand = YES,fill=X)
            entries[field]=ent
            entries1[field] = ent1

    return [entries,entries1]
def fetch(entries):
    for entry in entries:
        print('Input => "%s"' % entry.get())

if __name__ == "__main__":
    root = Tk()
    root.title("Total Centre Line Length")
    ents = makeform_tcl(root, fields_tcl)
    # ent1s = makeform(root, fields)
    root.bind('<Return>', (lambda event, e=ents: fetch(e)))
    # root.bind('<Return>', (lambda event, e1=ent1s: fetch(e1)))

    b1 = Button(root, text='Create', bg='cyan', relief=RAISED,bd=10,activeforeground='yellow',activebackground='red',command=(lambda e=ents[0], e1=ents[1]: maketable(e,e1)))
    b1.pack(side=BOTTOM, padx=5, pady=5)
    # b2 = Button(root, text='Return1', bg='cyan', command=(lambda e1=ent1s: maketable( e1)))
    # b2.pack(side=BOTTOM, padx=5, pady=5)
    root.mainloop()