from tkinter import *
root = Tk()
v = IntVar()
def sel():
    selection = "You selected the option"+str(v.get())
    label.config(text=selection)
Label(root,
      text ="""Choose scheme:""",
      justify= LEFT,
      padx =20).pack()
Radiobutton (root,
             text="MGNREGS",
             padx = 20,
             variable=v,
             value = 0,command=sel).pack(anchor=W)
Radiobutton(root,
            text="OTHER",
            padx = 20,
            variable = v,
            value = 38.4,command = sel).pack(anchor=W)
label = Label(root)
label.pack()
root.mainloop()