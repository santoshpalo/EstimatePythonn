from tkinter import *
root =Tk()
T =Text(root,height=2,width=80,)
T.pack()
T.insert(END,"Insert the text here")
mainloop()