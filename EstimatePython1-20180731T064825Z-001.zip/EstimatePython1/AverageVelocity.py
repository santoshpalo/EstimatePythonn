#! /usr/bin/python3

from tkinter import *
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
matplotlib.use("TkAgg")
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
fields=('Position_1','Position_2','Time_1','Time_2' )
# class mclass:
#     def __init__(self,window):
#         # self.box = Entry(window)
#         self.button = Button(window,text="check",command = self.plott)
#         # self.box.pack()
#         self.button.pack()
#
def average_velocity(entries):
    v = (float(entries['Position_2'].get())-float(entries['Position_1'].get()))/(float(entries['Time_2'].get())-float(entries['Time_1'].get()))
    print('v',v)
def makeform(root,fields):
    entries={}
    for field in fields:
        row=Frame(root)
        lab = Label(row,width=22,text=field+":",anchor='w')
        ent= Entry(row)
        ent.insert(0,"0")
        row.pack(side=TOP,fill=X,padx=5,pady=5)
        lab.pack(side=LEFT)
        ent.pack(side=RIGHT,expand = YES,fill=X)
        entries[field]=ent
    return entries
def fetch(entries):
    for entry in entries:
        print('Input => "%s"' % entry.get())
def plott(entries):
    x=np.linspace(float(entries['Position_1'].get()),float(entries['Position_2'].get()),10)
    y = np.linspace(float(entries['Time_1'].get()), float(entries['Time_2'].get()), 10)
    plt.plot(x,y,color = 'blue')
    plt.show()


if __name__ == '__main__':
    root=Tk()
    ents= makeform(root,fields)
    root.bind('<Return>',(lambda event,e =ents: fetch(e)))
    b1=Button(root,text='Calculate Average Velocity',command=(lambda e= ents: average_velocity(e)))
    b1.pack(side=LEFT,padx=5,pady=5)
    b2 = Button(root, text='Draw Average Velocity', command=lambda e= ents : plott(e))
    b2.pack(side=RIGHT, padx=5, pady=5)
    root.mainloop()
