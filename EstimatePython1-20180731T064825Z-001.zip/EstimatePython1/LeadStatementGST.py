# coding=utf-8
# import AnalysisRates as ar
# import Estimate_1 as es1
import numpy as np
# import LeadStatement as ls
import math as mt
import pandas as pd

pd.set_option('max_colwidth', 0)
pd.set_option('display.expand_frame_repr', False)
pd.set_option('display.precision', 2)
from tkinter import *

def conveyance(x):
    'For conveyance of Rough stone, xetal, khoa, chips, moorum, earth and sand etc.(per 1cum.)'
    if x <= 5:
        return 149.67
    elif 5 < x & x <= 50:
        return 149.67 + (x - 5) * 8.8
    else:
        return 149.67 + 45 * 8.8 + 6.220 * (x - 50)


def conveyance_wood(x):
    'For conveyance of wood of 1cum volume'
    if x <= 5:
        return 161.72/ 1.25
    elif 5 < x & x <= 50:
        return (161.72 + (x - 5) * 8.23) / 1.25
    else:
        return (161.72 + 45 * 8.23 + (x - 50) * 6.99) / 1.25


def conveyance_cement(x):
    'For conveyance of wood of 1cum volume'
    if x <= 5:
        return 16.17
    elif 5 < x & x <= 50:
        return (16.172 + (x - 5) * 0.823)
    else:
        return (16.172 + 45 * 0.823 + (x - 50) * 0.699)
def conveyance_distemper(x):
    'For conveyance of wood of 1cum volume'
    if x <= 5:
        return 16.17/100
    elif 5 < x & x <= 50:
        return (16.172 + (x - 5) * 0.823)/100
    else:
        return (16.172 + 45 * 0.823 + (x - 50) * 0.699)/100

def conveyance_paint(x):
    'For conveyance of paint of 1ltr volume'
    if x <= 5:
        return 16.172*1.3/100
    elif 5 < x & x <= 50:
        return (16.172 + (x - 5) * 0.823)*1.3/100
    else:
        return (16.172 + 45 * 0.823 + (x - 50) * 0.699)*1.3/100


def conveyance_brick(x):
    'Bricks of 25cm size for 1 no. '
    if x <= 5:
        return 967.27/ 2000
    elif 5 < x & x <= 50:
        return (967.27 + (x - 5) * 39.62) / 2000
    else:
        return (967.27 + 45 * 39.62 + (x - 50) * 31.87) / 2000
def conveyance_tile(x):
    'Tiles of 1sqm. '
    if x <= 5:
        return 967.27/ 180
    elif 5 < x & x <= 50:
        return (967.27 + (x - 5) * 39.62) / 180
    else:
        return (967.27 + 45 * 39.62 + (x - 50) * 31.87) / 180
def selection():
    selection = var.get()
    if selection == 1:
        Royalty = [35, 130]
        Unskilled = 213.5
    else:
        Royalty = [0, 0]
        Unskilled = 182.00
    return [Royalty,Unskilled]
master = Tk()
var = IntVar()
Label(master, text="Select Scheme for Royalty").grid(row=0, sticky=W)
rb1=Radiobutton(master, text="MAIN STREAM", variable=var, value=1).grid(row=1, sticky=W)

rb2=Radiobutton(master, text="M.G.N.R.E.G.S.", variable=var, value=2).grid(row=2, sticky=W)

but1 = Button(master, text="OK", command=selection).grid(row=3, sticky=W)
var.set(1)
mainloop()
royalty1 = selection()[0][0]
royalty2 = selection()[0][1]
u_s=selection()[1]
m = [[' clamp burnt bricks', 1, 'local', 15, 2877.45/1000,5, 0], ['sand', 1, 'Mahanadi', 10, 52.38,5, royalty1],
     ['course sand', 1, 'local', 10, 45.71,5, royalty1],
     ['cement', 1, 'Binka', 20, 273/1.18*2,18, 0], ['HYSD bar', 1, 'Binka', 20, 5300/1.18,18, 0], ['wood', 1, 'local', 5, 0,5, 0],
     ['stone', 1, 'SingiJuba', 20, 221.83,5, royalty2], ['10mm c.b.g. chips', 1, 'SingiJuba', 30, 1095.24,5, royalty2],
     ['12mm c.b.g. chips', 1, 'SingiJuba', 30, 1095.24,5, royalty2],
     ['20mm c.b.g. chips', 1, 'SingiJuba', 30, 1076.19,5, royalty2], ['40mm h.g. metal', 1, 'SingiJuba',30,664.76,5, royalty2],
     ['moorum',1,'Local',5,47.62,5,royalty1],['fly ash bricks',1,'Binka',20,3574.47/1000,5,0],
     ['vitrified tiles',1,'Binka',20,571.65,18,0],['ceramic glazed floor tile',1,'Binka',20,337.8,18,0],
     ['ceramic glazed wall tiles',1,'Binka',20,304.72,18,0],['red oxide primer',1,'Binka',20,101.57,18,0],
     ['enamel paint ',1,'Binka',20,151.97,18,0],['plastic emulsion paint',1,'Binka',20,196.06,18,0],
     ['weather coat paint',1,'Binka',20,151.18,18,0],['distemper',1,'Binka',20,51.97,18,0],
     ['water proof cement paint',1,'Binka',20,27.56,18,0],['white cement',1,'Binka',20,13.5827,18,0],
     ['wall putty', 1, 'Binka', 20, 30, 18, 0],['wall cement primer water bound',1,'Binka',20,121.26,18,0]
     ]


def cost_of_material(mm, i, c=['Description', 'qty', 'quarry', 'lead', 'basic cost','GST%', 'Royalty']):
    table = pd.DataFrame(mm, index=i, columns=c)
    return table
a = cost_of_material([m[0]], [1])
a.insert(4,'conveyance',conveyance_brick(m[0][3]))
a['qty']=a['qty'].map('{:.0f}no'.format)

b=cost_of_material([m[1]],[2])
b.insert(4,'conveyance',conveyance(m[1][3]))
b['qty']=b['qty'].map('{:.0f}cum'.format)

c=cost_of_material([m[2]],[3])
c.insert(4,'conveyance',conveyance(m[2][3]))
c['qty']=c['qty'].map('{:.0f}cum'.format)

d=cost_of_material([m[3]],[4])
d.insert(4,'conveyance',conveyance_cement(m[3][3]))
d['qty']=d['qty'].map('{:.0f}qtl'.format)

e=cost_of_material([m[4]],[5])
e.insert(4,'conveyance',conveyance_cement(m[4][3]))
e['qty']=e['qty'].map('{:.0f}qtl'.format)

f=cost_of_material([m[5]],[6])
f.insert(4,'conveyance',conveyance_wood(m[5][3]))
f['qty']=f['qty'].map('{:.0f}cum'.format)

g=cost_of_material([m[6]],[7])
g.insert(4,'conveyance',conveyance(m[6][3]))
g['qty']=g['qty'].map('{:.0f}cum'.format)

h=cost_of_material([m[7]],[8])
h.insert(4,'conveyance',conveyance(m[7][3]))
h['qty']=h['qty'].map('{:.0f}cum'.format)

i=cost_of_material([m[8]],[9])
i.insert(4,'conveyance',conveyance(m[8][3]))
i['qty']=i['qty'].map('{:.0f}cum'.format)

j=cost_of_material([m[9]],[10])
j.insert(4,'conveyance',conveyance(m[9][3]))
j['qty']=j['qty'].map('{:.0f}cum'.format)

k=cost_of_material([m[10]],[11])
k.insert(4,'conveyance',conveyance(m[10][3]))
k['qty']=k['qty'].map('{:.0f}cum'.format)

l=cost_of_material([m[11]],[12])
l.insert(4,'conveyance',conveyance(m[11][3]))
l['qty']=l['qty'].map('{:.0f}cum'.format)

n=cost_of_material([m[12]],[13])
n.insert(4,'conveyance',conveyance_brick(m[12][3]))
n['qty']=n['qty'].map('{:.0f}no'.format)

o=cost_of_material([m[13]],[14])
o.insert(4,'conveyance',conveyance_tile(m[13][3]))
o['qty']=o['qty'].map('{:.0f}sqm'.format)

p=cost_of_material([m[14]],[15])
p.insert(4,'conveyance',conveyance_tile(m[14][3]))
p['qty']=p['qty'].map('{:.0f}sqm'.format)

q=cost_of_material([m[15]],[16])
q.insert(4,'conveyance',conveyance_tile(m[15][3]))
q['qty']=q['qty'].map('{:.0f}sqm'.format)

r=cost_of_material([m[16]],[17])
r.insert(4,'conveyance',conveyance_paint(m[16][3]))
r['qty']=r['qty'].map('{:.0f}ltr'.format)

s=cost_of_material([m[17]],[18])
s.insert(4,'conveyance',conveyance_paint(m[17][3]))
s['qty']=s['qty'].map('{:.0f}ltr'.format)

t=cost_of_material([m[18]],[19])
t.insert(4,'conveyance',conveyance_paint(m[18][3]))
t['qty']=t['qty'].map('{:.0f}ltr'.format)

u=cost_of_material([m[19]],[20])
u.insert(4,'conveyance',conveyance_paint(m[19][3]))
u['qty']=u['qty'].map('{:.0f}ltr'.format)

v=cost_of_material([m[20]],[21])
v.insert(4,'conveyance',conveyance_distemper(m[20][3]))
v['qty']=v['qty'].map('{:.0f}kg'.format)

w=cost_of_material([m[21]],[22])
w.insert(4,'conveyance',conveyance_distemper(m[21][3]))
w['qty']=w['qty'].map('{:.0f}kg'.format)

x=cost_of_material([m[22]],[23])
x.insert(4,'conveyance',conveyance_distemper(m[22][3]))
x['qty']=x['qty'].map('{:.0f}kg'.format)

y=cost_of_material([m[23]],[24])
y.insert(4,'conveyance',conveyance_distemper(m[23][3]))
y['qty']=y['qty'].map('{:.0f}kg'.format)

z1=cost_of_material([m[24]],[25])
z1.insert(4,'conveyance',conveyance_paint(m[24][3]))
z1['qty']=z1['qty'].map('{:.0f}ltr'.format)




z = a.append(b).append(c).append(d).append(e).append(f).append(g).append(h).append(i).append(j).append(k).append(
        l).append(n).append(o).append(p).append(q).append(r).append(s).append(t).append(u).append(v).append(w).append(
    x).append(y).append(z1)

z.insert(7,'GST',z['basic cost']*z['GST%']/100)
z.insert(9, 'total cost', z['conveyance'] + z['basic cost'] + z['Royalty']+z['GST'])
# z['total cost'] = z['total cost'].map('\u20B9 {:.2f}'.format)
# z['Royalty'] = z['Royalty'].map('\u20B9 {:.2f}'.format)
# z['basic cost'] = z['basic cost'].map('\u20B9 {:.2f}'.format)
# z['conveyance'] = z['conveyance'].map('\u20B9 {:.2f}'.format)
# z['lead'] = z['lead'].map('{:.0f}km'.format)




if __name__ == "__main__":
    z = a.append(b).append(c).append(d).append(e).append(f).append(g).append(h).append(i).append(j).append(k).append(
        l).append(n).append(o).append(p).append(q).append(r).append(s).append(t).append(u).append(v).append(w).append(
        x).append(y).append(z1)
    z.insert(7, 'GST', z['basic cost'] * z['GST%'] / 100)
    z.insert(9, 'total cost', z['conveyance'] + z['basic cost'] + z['Royalty']+z['GST'])
    z['GST'] = z['GST'].map('\u20B9 {:.2f}'.format)
    z['total cost'] = z['total cost'].map('\u20B9 {:.2f}'.format)
    z['Royalty'] = z['Royalty'].map('\u20B9 {:.2f}'.format)
    z['basic cost'] = z['basic cost'].map('\u20B9 {:.2f}'.format)
    z['conveyance'] = z['conveyance'].map('\u20B9 {:.2f}'.format)
    z['lead'] = z['lead'].map('{:.0f}km'.format)

    print(z, '\n\n\n', 'The lead of different materials as stated above is least and economical.')
    print('\n\n\n\tJunior Engineer\t\tAssistant Engineer\t\tBlock Development Officer')
    print('\tBinka Block Office\tBinka Block Office\t\t\t\tBinka')





