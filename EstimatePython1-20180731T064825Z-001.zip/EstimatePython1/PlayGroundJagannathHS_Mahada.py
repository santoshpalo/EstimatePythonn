#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 11 16:21:53 2018

@author: spalo
"""

import PlayGround as pg
import FunctionLibraryR as fl
print('\t\t\t\tDETAILED ESTIMATE')
print('\nName of the work:-Improvement of Play Ground at Jagannath High School, Mahada')
print('Estimated Cost:-\u20B91,87,500.00\tH/A:-4th SFC Devolution of Fund(2017-18)')
print('-'*80)
ground=pg.PlayGround(45.5,45.5,0.6)
ground.earthwork()
ground.finedressing()
ground.miscellaneous()
ground.cess()
print('\nTotal estimated cost = \u20B9','{:.2f}'.format(ground.totalR()),'limited to \u20B91,87,500.00')
print('-'*80)
fl.signature(187500,'Rupees one lakh eighty seven thousand five hundred only',1,'')