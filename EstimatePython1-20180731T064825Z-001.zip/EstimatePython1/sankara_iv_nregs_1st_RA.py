import FunctionLibrary as fl
import ClassLibrary as cl
import items as it










if __name__ == "__main__":
    print('Calculation of totalk centre line length\n')
    tcl= cl.Quantity([['long walls 1',2,10.75],
                      ['long walls2',1,8.5],
                      ['long walls 3',2,6.0],
                      ['short wall 1',1,3.7],
                      ['short wall 2',2,2.15]])
    tcl.rate =0
    print(tcl.tcl()['y0'],tcl.tcl()['y1'])
    print(it.items['m20'])
    rcc = cl.Quantity([['slab part 1',1,11.3,4.25,0.1],
                       ['slab part 2',1,9.05,2.15,0.1],
                       ['beams',2,3.95,0.25,0.25],
                       ['roof bend',1,50-8*0.25,0.25,0.15],
                       ['rcc columns',4,0.25,0.25,0.8]])
    rcc.rate=4142.32
    rcc.volume()
    reinforcement= cl.Quantity([['beams main bar',2*5,3.95-.08,0.89],
                                
                                ['extra top bars at top',2*2,1.15,0.89],
                                ['long walls 1',2*4,10.75+.17,0.62],
                                ['long walls2',1*4,8.5+.17,0.62],
                                ['long walls 3',2*4,6.0+.17,0.62],
                                ['short wall 1',1*4,3.7+.17,0.62],
                                ['short wall 2',2*4,2.15+.17,0.62],
                                ['stirrups of beam',26*2,0.96,.395],
                                ['stirrups of roof bend',333,.87,.395],
                                ['panel 1 bottom 1',8,3.43,.395],
                                ['panel 1 bottom 2',8,3.83,.395],
                                ['panel 2 bottom ',16,2.83+.25+.2+2.58/4,.395],
                                ['panel 3 bottom 1',8,2.83+.25+.2+2.58/4,.395],
                                ['panel 3 bottom 2',8,2.83+.25+.2+1.9/4,.395],
                                ['panel 4 bottom 1',8,2.15+.25+.1+2.58/4,.395],
                                ['panel 4 bottom 2',8,2.15+.25+.1+.2,.395],
                                ['panel 1 top 1',6,3.7+.25+.1+1.9/4,.395],
                                ['panel 1 top 2',5,.2+3.95+.1,.395],
                                ['panel 2 top 1 ',5,3.7+.25+.1+1.9/4,.395],
                                ['panel 2 top 2',5,.2+3.95+.1,.395],
                                ['panel3 top 1',5,3.7+.25+.1+1.9/4,.395],
                                ['panel 3 top 2',5,.2+3.95+.1,.395],
                                ['panel 4 top 1',5,3.7+.25+.2,.395],
                                ['panel 4 top 2',4,3.7+.25+.2,.395],
                                ['panel 5 bottom 1',5,2.83+.25+.1+2.58/4,.395],
                                ['panel 5 bottom 2',4,2.83+.25+.2+.1,.395],
                                ['panel 6 bottom ',9,2.83+.25+2.58/4+.2,.395],
                                ['panel 7 bottom 1',4,2.83+.25+.1+2.58/4,.395],
                                ['panel 7 bottom 2',5,2.83+.25+.2+.1,.395],
                                ['panel 5 top 1',5,2.15+.25+.1+.2,.395],
                                ['panel 5 top 2',6,2.15+.25+.1+.9,.395],
                                ['panel 6 top 1 ',5,2.15+.25+.1+.9,.395],
                                ['panel 6 top 2 ',4,2.15+.25+.1+.2,.395],
                                ['panel 7 top 1',6,2.15+.25+.1+.9,.395],
                                ['panel 7 top 2',5,2.15+.1+.2,.395],
                                ['distributions long 1',2,10.75+.25+.2,.395],
                                ['distributions long 2',2,6.00+.25+.2,.395],
                                ['distributions long 3                                         ',2,8.5+.25+.2,.395],
                                ['distributions short 1',2,2.15+.25,.395],
                                ['distributions short 2',2,2.5,.395],
                                ['distributions short 2',2,3.7+.25,.395],
                                ['distribution inside 1',18,8.5,.395],
                                ['distribution outside 1',33,8.5,.395],
                                ['distribution inside 2',10,3.95,.395],
                                ['extra bars at end of the slab',20,0.9,.395],
                                ['extra bars at top of slab',20,0.6,.395],
                                ['extra bars at top 2',25,0.75,0.395]
                                ])
    print(reinforcement.reinforcement()['y0'],reinforcement.reinforcement()['y1'])
    print('Cost of reinforcement works = 7.70q @ Rs.4513.66/q =  Rs.34,755.00')
    print(it.items['20cp(1:4)'])
    grading = cl.Quantity([['slab part 1',1,10.75+.25+.3,3.7+.25+.3],
                           ['slab part 2',1,8.5+.25+.3,2.15]])
    grading.rate=121.98
    grading.hArea()
    print(it.items['rscs_slab'])
    slab = cl.Quantity([['slab part 1',1,11.3,4.25],
                       ['slab part 2',1,9.05,2.15],
                       ['beams',-2,3.95,0.25],
                       ['roof bend',1,50-8*0.25,0.05]])
    slab.rate = 305.67
    slab.hArea()
    print(it.items['rscs_beam'])
    beam=cl.Quantity([['columns',4*4,0.25,0.8],
                      ['beams',2*3,3.7-.25,0.25]])
    beam.rate=462.1
    beam.vArea()
    print(it.items['bmss'])
    brick = cl.Quantity([['total centre line length',1,50-6*.25,0.25,.9]])
    brick.rate=2823.95
    brick.volume()
    print(it.items['CC(1:4:8)'])
    metal_concrete = cl.Quantity([['class room',1,8.06,3.23,0.1],
                                  ['verandah,kitchen and store',3,2.49,1.68,0.1],
                                  ['toilets',1,3.23,1.8,0.1],
                                  
                                  ])
    metal_concrete.rate=2835.52
    metal_concrete.volume()




