import pandas as pd

import items as it
import LeadStatement1 as ls1
from tkinter import *
import FunctionLibraryR as fr
import textwrap

#Total centre line length calculation
tcl = ([['Walls X I',3,6.45],
        ['Walls Y I',1,5.59],
        # ['Walls X III',1,2.01],
        ['Walls Y II',1,1.93]])

weather_coat=([['long walls',2,6.45+.25,3.05],
                  ['short walls',2,5.59+.25,3.05],
                  ['plinth long walls',2,6.85,0.45],
                  ['plinth short walls',2,5.85+.15,0.45],
                  ['deduct verandah openings 1',-1,1.65,1.98],
                ['deduct verandah openings II',-1,2.97,1.98],
                ['window openings',-2/2,0.9,1.2],
               ['window opening 2',-.5,0.75,1.08],
                ['window chajjas',3*2,1.2,0.45],
           ['verandah chajja long',2,2.97+.25+.15+.45,0.45],
               ['verandah chajja short',1,2.05,0.45],

           ['slab p[rojection long',2,7.0,0.25],
           ['slab projection short',2,5.85+.25,0.25]
                  ])
wpcp=([['roof area', 1, 6.7, 5.85],
            ['deduct wall bearing', -1, 26.87 - 0.5, 0.25]])
distemper=([['walls both sides',2,26.87,3.3],
            ['deduct weather coat external area',-2,6.7+5.85,3.3],
            ['deduct door openings 1', -0.5, 1.1, 1.98],
            ['deduct door opening 2',-0.5,0.75,1.98],

            ['deduct verandah openings 1', -0.5, 1.65, 1.98],
            ['deduct verandah openings II', -0.5, 2.97, 1.98],

            ['window openings', -2 / 2, 0.9, 1.2],
            ['window opening 2', -.5, 0.75, 1.08]
            ])

door_window=([['Doors1',2.25,1.1,1.98],
              ['Door2',2.25,0.75,1.98],
              ['Windows',3*2.75,0.9,1.2],
              ['window2',2.75,0.75,1.08]])






class AWC:
    def __init__(self,master):
        frame = Frame(master,bg = 'red')
        frame.pack()
        self.Label = Label(frame, text = 'Quantity')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.TCL = Button(frame,text = "Total centre line length",command = self.TCL)
        self.TCL.pack(side=TOP)
        self.distemper = Button(frame, text="Distempering", command=self.distemper)
        self.distemper.pack(side=TOP)
        self.weather_coating = Button(frame, text="Weather coating", command=self.weather_coating)
        self.weather_coating.pack(side=TOP)
        self.painting = Button(frame, text="Door and Window painting", command=self.Painting)
        self.painting.pack(side=TOP)
        self.wpcp = Button(frame, text="Water proofing cement paint", command=self.wpcp)
        self.wpcp.pack(side=TOP)
    def TCL(self):
        d = tcl
        table = pd.DataFrame(d, index=range(1, len(d) + 1),
                             columns=['description', 'no', 'length'])
        table['quantity'] = table['no'] * table['length'] .round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)

        print('\n', 'Total centre line length', '\n', table, '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}m'.format(table.tquantity))
    def distemper(self):
        d = distemper
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['distemper'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(17.57),'\u20B9{:.2f} '.format(round(17.57*table.tquantity,0)))
    def weather_coating(self):
        d = weather_coat
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['wall_paint'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(28.43),'\u20B9{:.2f} '.format(round(28.43,2)*table.tquantity,0))
    def Painting(self):
        d = door_window
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['paint'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(40.88),'\u20B9{:.2f} '.format(round(40.88*table.tquantity,0)))
    def wpcp(self):
        d = wpcp
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n',textwrap.fill('''Finishing walls with water proofing
cement paint of approved shade on
new work two coat to give an even
shade exculding cost of paint.''',80), '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(8.80),'\u20B9{:.2f} '.format(round(8.8*table.tquantity,0)))




if __name__ == "__main__":
    print('Name of AWC:-Babupalli I\tEstt. Cost:-\u20B914,000.00\tH/A:-State Plan ICDS (2016-17)')
    print('-'*80)
    root = Tk()
    app = AWC(root)
    root.mainloop()
    print('\nCost of Distemper 54.18 kg @ \u20B9 66.00 / kg = \u20B9 3618.00')
    print('\n Cost of weather coat 13.42ltr. @ \u20B9 192.00 /ltr. = \u20B9 2577.00')
    print('\nCost of paint 1.86ltr. @ \u20B9 193.00/ltr. = \u20B9 359.00')
    print('\nCost of water proofing cement paint 7.02kg @ \u20B9 45.00/kg. = \u20B9 316.00')
    print('\n\t\t\tProvision for T & P = \u20B9280.00')
    print('\nCess for welfare of labourers = \u20B9140.00')
    print('Work contingenecy \u20B970.00')
    print('Display Board and photograph\u20B9 500.00')
    print('\nTotal cost = \u20B918,027.00 limitetd to\u20B9 14,000.00 (Rupees fourtenen thousand only')
    print('\n\n\nJunior Engineer\t\t\tAssistant Engineer\tBlock Development Officer\nBinka Block Office\t\tBinka Block Office\t\tBinka')




































































# #Mahada I
# import numpy as np
#
# x1 = ([['external long wall',2,5.5],
#        ['external short wall',2,8.23]])
# TCL = x1
# y= ([['total wall area',1,39.1-3*0.25-27.46,3.3],
#      ['verandah opening 1',-2/2.0,2.45,1.98],
#      ['verandah opening 2',-1/2.0,1.4,1.98],
#      ['Door 1',-3/2.0,1.08,1.98],
#      ['Windows',-5/2.0,0.9,1.2]])
