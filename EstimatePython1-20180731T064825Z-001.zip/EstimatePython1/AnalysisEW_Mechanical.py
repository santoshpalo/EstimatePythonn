import items as it
import textwrap
import FunctionLibrary as fl
print(it.items['Earth_work_mechanical'])
print('Per 1cum')
print('A. Excavation by Mechanical means\n')
print(textwrap.fill('Capacity of excavator for excavation of loose earth = 127.46 cum',80))
print(textwrap.fill('Considering a swell factor of 0.715 for D.I. rock, Quantity of soil excavation per hour = 91.13 cum',80))
print(textwrap.fill('Hire charge of Hydraulic Excavator of 2cum bucket excluding supervision charges = \u20B91868.00 / hour',80))
print('Cost of excavation per 1 cum = \u20B91868.00 / 91.13cum = \u20B9 20.50 /cum')
print('B. Trasportation cost\n')
print(textwrap.fill('Conveyance of excavated earth by mechanical means = \u20B9156.40 / cum',80))
print('Deduct for loading and unloading\t\t\t\t= -\u20B9 79.00 / cum')
print('Add for trimming of slope and bed manually = \u20B9 2.00 / cum')
print('Total charges for excavation of earth = \u20B997.90 / cum')
print('\n\n\n\tJunior Engineer\t\t\t\tAssistant Engineer\t\t\t\tSarpanch')
print('\tBinka Block Office\t\t\tBinka Block Office\t\t\t\tMahada G.P.')


