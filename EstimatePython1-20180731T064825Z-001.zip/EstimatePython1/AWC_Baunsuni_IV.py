import ClassLibrary as cl
import FunctionLibrary as fl
import items as it












if __name__ == "__main__":
    tcl = cl.Quantity([['long walls',2,9.58],
                       ['short walls',1,6.95],
                       ['short walls',1,2.57],
                       ['short walls3',3,5.89],
                       ['short walls 4',1,1.95]])
    tcl.tcl()
    print(tcl.tcl()['y0'],tcl.tcl()['y1'])
    flooring = cl.Quantity([['class room',1,6.71,3.66],
                            ['store room',1,2.13,1.68],
                            ['kitchen',1,3.17,2.31],
                            ['verandah',1,4.31,1.92],
                            ['W.C.',1,2.36,1.00],
                            ['urinal',1,2.36,0.95]])