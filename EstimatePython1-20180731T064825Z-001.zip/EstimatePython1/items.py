import textwrap
items = {'ewhs':textwrap.fill('''Earth work in hard soil including breaking of clods from 5 to 7cm in size and laying in layers not exceeding 30cm in height within initial lead of 50m and lift of 1.50m etc. complete''',80),
'ewss':'''\nEarth work in slushy soil (in water upto 0.6m depth requiring the aid of pans and vessels) within 50m. Initial lead and 1.5m initial lift as per the direction and specification of the Deparment.\n''',
'rcc':textwrap.fill('''\nR.C.C. work (1:1.5:3) with 12mm size black hard granite (crusher broken) stone chips including hoisting and laying including cost,conveyance and royalty of all materials etc. complete.\n''',80),
'm20':textwrap.fill('''\nR.C.C. work of M-20 grade with 20mm and down grade black hard granite(crusher broken) stone chips including hoisting and laying including cost,conveyance and royalty of all materials etc. complete.\n''',80),
'm25':textwrap.fill('''\nR.C.C. work of M-25 grade with 20mm and down grade black hard granite (crusher broken) stone chips including hoisting and laying including cost, conveyance and royalty of all materials etc. complete.\n''',80),
'hysd':textwrap.fill('''\nSupplying ,fitting and placing uncoated HYSD bar reinforcement complete as per drawing and technical specification.''',80),
'bmfpcb':textwrap.fill('''\nBrick work with clamp burnt bricks 25cm x 12cm x 8cm size having crushing strength not less than 75Kg/cm2 with dimensional tolerance ± 8 percent cement mortar (1:6) in foundation and plinth\n''',80),
'bmsscb':textwrap.fill('''\nBrick work with clamp burnt bricks 25cm x 12cm x 8cm size having crushing strength not less than 75Kg/cm2 with dimensional tolerance ± 8 percent cement mortar (1:6) in super structure\n''',80),
'rscs_plinth':textwrap.fill('''\nRigid and smooth centering and shuttering for R.C.C. works including false works and dismantling them after casting including cost of materials complete in ground floor-footings and plinth bend\n''',80),
'rscs_lintel':textwrap.fill('''\nRigid and smooth centering and shuttering for R.C.C. works including false works and dismantling them after casting including cost of materialscomplete in ground floor- lintel\n''',80),
'rscs_beam':textwrap.fill('''\nRigid and smooth centering and shuttering for R.C.C. works including false works and dismantling them after casting including cost of materials complete in ground floor- beams and columns\n''',80),
'rscs_slab':textwrap.fill('''\nRigid and smooth centering and shuttering for R.C.C. works including false works and dismantling them after casting including cost of materials complete in ground floor- roof slab and chajja\n''',80),
'rscs_stair':textwrap.fill('''\nRigid and smooth centering and shuttering for R.C.C. works including false works and dismantling them after casting including cost of materials complete in ground floor- R.C.C. stairs excluding landing but including railing\n''',80),
'rscs_walls':textwrap.fill('''\nRigid and smooth centering and shuttering for R.C.C. works including false works and dismantling them after casting including cost of materials complete in ground floor- R.C.C. walls and fins including attached pillasters\n''',80),
'20cp(1:4)':textwrap.fill('''\n20mm, thick cement mortar plaster (1:4) on roof slab top as grading plaster including cost, conveyance and royalty etc. complete. \n'''),
'20cp(1:6)':textwrap.fill('''\n20mm, thick cement mortar plaster (1:6) on stone masonry walls plaster including cost, conveyance and royalty etc. complete. \n''',80),
'6cp(1:4)':textwrap.fill('''\n6mm, thick cement mortar plaster (1:4) on brick walls including cost, conveyance and royalty etc. complete. \n''',80),
'6cp(1:4)rcc':textwrap.fill('''\n6mm, thick cement mortar plaster (1:4) on R.C.C. works including closely deep chipping and slurry treatment plaster including cost, conveyance and royalty etc. complete. \n''',80),
'bmfpfa':textwrap.fill('''\nBrick work with fly ash bricks 25cm x 12cm x 8cm size having crushing strength not less than 75Kg/cm2 with dimensional tolerance ± 8 percent cement mortar (1:6) in foundation & plinth\n''',80),
'bmssfa':textwrap.fill('''\nBrick work with fly ash bricks 25cm x 12cm x 8cm size having crushing strength not less than 75Kg/cm2 with dimensional tolerance ± 8 percent cement mortar (1:6) in super structure\n''',80),
'rrhg':textwrap.fill('''\nRandom rubble stone masonry using hard granite stones in foundation and plinth including cost, conveyance and royalty etc. complete.'''),
'12cp(1:6)':textwrap.fill('''\n12mm thick cement mortar plaster (1:6) on brick masonry walls including cost, conveyance and royalty etc. complete. \n''',80),
'12cp(1:4)':textwrap.fill('''\n12mm thick cement mortar plaster (1:4) on brick masonry walls including neat cement punning cost, conveyance and royalty etc. complete. \n''',80),
'12cp(1:4)punning':textwrap.fill('''\n12mm thick cement mortar plaster (1:4) on brick masonry walls including neat cement punning cost, conveyance and royalty etc. complete. \n''',80),
'16cp(1:6)':textwrap.fill('''\n16mm, thick cement mortar plaster (1:6) on brick masonry walls including cost, conveyance and royalty etc. complete. \n''',80),
'CC(1:4:8)':textwrap.fill('''\nCement concrete (1:4:8) using 40mm size h.g. metal including cost,conveyance and royalty etc. complete.\n''',80),
'CC(1:3:6)':textwrap.fill('''\nCement concrete (1:3:6) using 40mm size h.g. metal including cost,conveyance and royalty etc. complete.\n''',80),
'CC(1:5:10)':'''\nCement concrete (1:5:10) using 40mm size h.g. metal including cost,conveyance and royalty etc. complete.\n''',
'wpcp':textwrap.fill('''\nFinishing walls with water proofing cement paintincluding all labour cost and T & P etc. complete.\n''',80),
'wall_paint1':textwrap.fill('''Wall painting 1 coat with weather coat (I.S.I.) of approved shade on old work to give an even shade exculding cost of paint.'''),
'msdoor':'\nSupplying and fixing of M.S. doors and windows in proper position etc. complete\n',
'paint':textwrap.fill('''\n2 coats of painting over new M.S. doors and windows including 1 coat of priming, T & P and labour charges etc. complete.\n''',80),
'asfloor':textwrap.fill('''\n2.5cm thick A.S. flooring using c.c. (1:2:4) with 12 mm size c.b.g. chips including cost, conveyance and royalty etc. complete.\n''',80),
'dpc':textwrap.fill('''\n2.5 cm. Damp proof course using c.c. (1:2:4) with 12 mm size c.b.g. chips including cost, conveyance and royalty etc. complete.\n''',80),
'walltile':'''\nFixing tiles in dados skirting and risers of stepson 12mm thick cement plaster (1:3) jointed with neat cement slurry mixed with pigments to match the shade of the tiles including rubbing and polishing complete excluding cost of precast tiles.\n''',
'efhs':textwrap.fill('''\nExcavation of foundation trench in hard soil including dressing of sides and levelling of bed etc. complete.\n''',80)
,'CC(1:2:4)':textwrap.fill('''\nCement concrete (1:2:4) using 12mm size c.b.g. chips including cost,conveyance and royalty etc. complete.\n''',80)
,'sand_filling':textwrap.fill('''\nFilling sand in foundation and plinth well watered and rammed including cost, conveyance and royalty etc. complete.\n''',80),
'Earth_work_mechanical':textwrap.fill('''\nExcavation, loading, unloading and carriage by mechanical means of all kinds of soil, including stoney earth, gravel and moorum etc interspread with boulders upto 1/2 cum size with all lifts and delifts including trimming of slopes and bed to design section specification and as directed by the Engineer-in-charge within initial lead of 5.0km including royalty and labour charges for loading.\n''',80),
'vitrified':textwrap.fill('''\nSupplying, fitting and fixing vitrified tile in floors of size 600mm x 600mm of approved make with application of cement mortar bed of required thickness and filling joints with white cement of approved quality including cost of all materials, labour T&P etc required for the work.\n''',80),
'wall_tile':'''\nFixing tiles in dados skirting and risers of steps on 12mm thick cement plaster (1:3) jointed with neat cement slurry mixed with pigments to match the shade of the tiles including rubbing and polishing complete excluding cost of precast tiles.\n''',
'distemper':textwrap.fill('''\nDistempering one coat to walls with distemper of approved shade on old work to give an even shade exculding cost of distemper.\n''',80),
'wall_paint2':textwrap.fill('''\nWall painting 2 coat with weather coat paint of approved shade on new work to give an even shade exculding cost of paint\n''',80),
'sand_fill':textwrap.fill('''\nFilling sand in foundation and plinth well watered and rammed including cost, conveyance and royalty etc. complete.\n''',80),
'subbase':textwrap.fill('''Labour for laying sub-base in layers not exceeding 100mm watering and compacting to the required density in O.M.C with PRR but excluding cost and conveyance of sub base materials\n''',80),
'gradeI':textwrap.fill('''\nLabour for spreading metal and packing the voids with small stones and hand packing the same to proper camber including conveying spreading of filler materials and filling the interstices by spreading the same over the surface, watering and consolidation with PRR including hire and running charges of PRR complete but excluding cost and conveyance of metal and filler materials\n''',80),
'moorumcollection':textwrap.fill('''\nCollection of good qualty laterite moorum on both sides of road in regular stacks of size 1.50m x 1.50m x 0.5m. Taking each stack to be 1 cum each after exclusion of voids. The cost is inclusive of cost, conveyance and royalty etc. complete.\n''',80),
'metalcollection':'''\nCollection of hand broken granite stone 63mm size on both sides of road in regular stacks of size 1.50m x 1.50m x 0.5m. Taking each stack to be 1 cum each after exclusion of voids. The cost is inclusive of cost, conveyance and royalty etc. complete.\n''',
'floor tile':textwrap.fill('''Fixing tiles in floors treads or steps and landing on 25mm thick bed of cement mortar 1:1 (1cement : 1sand) jointed with neat cement slury mixed with pigment to match the shades of the tiles including rubbing & polishing complete excluding cost of precast tiles''',80),
'wall tile':textwrap.fill('''\n Fixing tiles in dados skirting and risers of steps on 12mm thick cement plaster (1:3) jointed with neat cement slurry mixed with pigments to match the shade of the tiles including rubbing and polishing complete excluding cost of precast tiles.''',80),
'water closet I':textwrap.fill('Fixing water closet squatting pan (Indian Type w.c. pan)duly embeddedin c.c. (1:4:8) using hard granite metal 4cm nominal size all complete as per specification 500mm x 440mm size white glazed vitreous china orissa pattern squatting pan ',80),
'p or s trap':textwrap.fill('fixing 100 mm size p or s trap (with horn or without horn) for water closet squatting pan including joining the trap with cement mortar (1:1) as per specification'),
'pvc pipe':textwrap.fill('Providing and fixing to wall ceiling and floor PVC pipes and pipe fittings of the filling bore with clamps including making good the wall, ceiling & floor all complete as per specification complete'),
'pvc soil pipe':textwrap.fill('Providing and fixing on wall face unplasticised rigid PVC soil, waste and rain water pipes, conforming to IS 5382, leaving 10mm gap for thermal expansion'),
'pvc moulded fitting':textwrap.fill('Providing and fixing on wall face unplasticised pvc moulded fittings/accessories for unplasticised rigid pvc rain water pipes including joining with seal ring complete leaving 10mm gap for the expansion',80),
'gci_roofing':textwrap.fill('''Labour for fixing G.C.I. Sheet in roof drilling hole in wind ties including fixing of ridges valleys wind ties etc. excluding cost of fitting'''),
'RRHG_(1:6)':textwrap.fill('''Random rubble hard Granite stone masonry (first class) in cement mortar (1.6) in foundation and plinth'''),
'CRHG_(1:6)':textwrap.fill('''Coursed rubble hard Granite stone masonry (first class) in cement mortar (1.6) in foundation and plinth'''),
'dismantle brick work':textwrap.fill('''Dismantling brick or stone masonry in lime or cement mortar under 3m. height including stacking the useful materials for reuse and removing the debris within 50m. Lead'''),
'wall primer':textwrap.fill('Priming 1 coat with any appproved Primer on newly plastered wall surface',80),
'wall putty':textwrap.fill('Finishing wall surface of walls with Acrylic wall putty (Water based ) of approved make and finished smooth and even surface to'
                           'receive painting including cost of scaffolding staging charges with cost of all materials taxes, labour T&P etc complete.',80),
'hand railing':textwrap.fill('Supplying, fitting and fixing of stainless steel of 304 grade in hand railing using 50mm dia of 2mm thick circular pipe with balustrade of size 32mm x 32mm x 2mm @ 0.90m c/c and stainless square pipe bracing of size 32mm x 32mm x 2mm in 3 rows in stair case as per approved design and specification, buffing, polishing etc with cost, conveyance, taxes of all materials, labour, T&P etc. required for the complete in all respect.,80 '),
'finedressing':textwrap.fill('Fine dressing of earth work in ordinary or hard soli according the direction of engineer-in-charge including cutting or filling of earth uptp 0.15m depth of surface',80)






}






if __name__ == "__main__":
    
    print(sorted(items.keys()))
    
    
    
    
