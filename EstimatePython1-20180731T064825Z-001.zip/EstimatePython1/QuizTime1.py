from tkinter import *
import textwrap
def response():
    selection = var.get()
    if selection == 1:
        reaction = "No. You are wrong."
    elif selection == 2:
        reaction = "You are right.Do you need one more question ?"
    elif selection == 3:
        reaction = "No. You are wrong."
    else:
        pass
    print(reaction)
master = Tk()
var = IntVar()
var.set(1)
answers =[
    ("10.00 %",1),
    ("25.00 %",2),
    ("20.00 %",3),
    ("Sorry, I don't know.",4)]
def ShowChoice():
    print(var.get())

label=Label(master,text = textwrap.fill("""A person sold an object at \u20B91250.00. If he made a profit of \u20B9250.00, what is his percentage of profit ?""",50),font=("Courier",30)).grid(row=0,sticky=W)

# Radiobutton(master,text="10.00%",variable = var,value = 1,font=("Courier",30)).grid(row = 1,sticky=W)
# Radiobutton(master,text="25.00%",variable = var,value = 2,font=("Courier",30)).grid(row = 2,sticky=W)
Button(master,text="OK",command= response,font=("Courier",30)).grid(row=3,sticky=W)
mainloop()
