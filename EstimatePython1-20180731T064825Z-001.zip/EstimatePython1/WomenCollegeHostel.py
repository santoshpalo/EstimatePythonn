import ClassLibrary as cl
import FunctionLibrary as fl





if __name__ == "__main__":
    plinth_main=cl.Quantity([['back side walls',4,45.00,.62],
                             ['students toilet back & front',2*4,4.35,0.62],
                             ['toilet and gas bank partition',5,2.21+.5-.08,.89],
                             ['gas bank and store wall',4,4.76,0.62],
                             ['wash and stair case wall',4,4.84,0.62],
                             ['mid corridor wall',4*2,26.88,0.62],
                             ['kitchen and dining walls',4,15.7,0.62],
                             ['store,office and lobby wall',4,17.32,0.62],
                             ['toilet wall',4,3.63,0.62],
                             ['front long wall',4,36.43,0.62],
                             ['spdt. bed and kitchen',4,5.88,0.62],
                             ['kitchen & gas bank',4,9.14,0.62],
                             ['gas bank and store',4,4.76,0.62],
                             ['Dining through spdt. bed',4,18.13,0.62],
                             ['spdt. toilet & kitchen',4,5.9,0.62],
                             ['store & office',4,3.47,.62],
                             ['living & stair',4,3.62,0.62],
                             ['Dining & lobby wall',4,15.89,0.62],
                             ['wash and stair',4,4.84,0.62],
                             ['rooms and stair',4,15.62,0.62],
                             ['walls of rooms',10*4,6.98,0.62],
                             ['walls of toilet',4,13.06,0.62]])