import ClassLibrary as cl
import items as it
import FunctionLibraryR as fr
print('Name of the work:-Completion of CC hall at village Siali')
print('Estimated Cost:-\u20B95,00,000.00\t\tHead of Account:-Biju K.B.K.(2015-16)')
print('-'*80)
print('Amount expended in the first R/A bill= \u20B93,29,770.00')
tcl = [['long wall',2,12.15],
       ['short wall',2,9.7]]
tcl=cl.Quantity(tcl)
tcl.tcl()
print(it.items['12cp(1:6)'])
cp12 = [['alround walls',1,43.7+1,3.65],
        ['rcc pillrs',6*3,0.25,3.65],
        ['rcc beams',3,8.95,1.45],
      ['deduct door openings',-2*0.5,1.2,2.1],
      ['deduct window openings',-4*0.5,1.5,1.2]]
cp12=cl.Quantity(cp12)
cp12.rate=fr.plaster(1)
cp12.vArea()
print(it.items['16cp(1:6)'])
cp16=[['alround walls',1,43.7-1,3.65],
      ['deduct door openings',-2*0.5,1.2,2.1],
      ['deduct window openings',-4*0.5,1.5,1.2]]
cp16=cl.Quantity(cp16)
cp16.rate=fr.plaster(2)
cp16.vArea()
print(it.items['bmfpcb'])
brickmasonry=cl.Quantity([['1st footing',2,1.45,0.88,0.12],
                          ['2nd footings',2,1.45,0.88/3*2,0.12],
                          ['3rd footings',2,1.45,0.88/3,0.12]])
brickmasonry.rate=fr.brickmasonry(1)[0]
brickmasonry.volume()
print(it.items['vitrified'])
floor=cl.Quantity([['hall',1,12.15-.25,9.7-.25],
                   ['steps',3,1.45,0.3]])
floor.rate=907.07
floor.hArea()
print('Cost and conveyance of M.S.Doors and windows =')
print ('4nos. windows @ \u20B9 90.00kg @ \u20B9 65.00/kg = \u20B923,400.00')
print('2nos. Doors @ \u20B9 100.00 kg @ \u20B9 65.00/kg = \u20B9 13,000.00')
print('Total estimated cost=\u20B95,01,128.00\tlimited to \u20B95,00,000.00')
print('='*80)
fr.signature(500000,'',6,'')



