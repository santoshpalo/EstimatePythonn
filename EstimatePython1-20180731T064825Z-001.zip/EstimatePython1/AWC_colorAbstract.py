import textwrap
import FunctionLibraryR as fr
import items as it
print(textwrap.fill('Name of the work:-Uniform color coding of AWC Building of Jullunda G.P.',80))
print(textwrap.fill('Head of Account:-Stateplan (ICDS) 2016-17    Estimated Cost:-56,000.00'))
print('-'*80)
print(it.items['distemper'])
print('provisional area of surface area=600.00sqm @ \u20B9 17.57/sqm =\u20B910,542.00 \n')
print(textwrap.fill('''Painting on walls 2 coats with weather coat to give an even shade to the surfaces.''',80))
print('provisional area of surface area=460.00.00sqm @ \u20B9 28.43/sqm =\u20B913,078.00\n ')
print(it.items['paint'])
print('provisional area of surface area=110.00sqm @ \u20B9 40.88/sqm =\u20B94,497.00\n ')
print(it.items['wpcp'])
print('provisional area of surface area=200.00sqm @ \u20B9 8.88/sqm =\u20B91,776.00\n ')
print('Provisional cost for T &P = \u20B9600.00\n')
print('Cost of materials\n\t\t\tdistemper 99.6kg @ \u20B966.00/kg = \u20B96,573.00\n\t\t\tweather coat 57.5l @ \u20B9192.00/kg = \u20B911,040.00\n\t\t\tenamel paint 8.87l @ \u20B9193.00/kg = \u20B91,712.00\n\t\t\twater proofing cement paint 26.56kg @ \u20B945.00/kg = \u20B91,195.00 ')
print('\nCess for welfare of labourers = 560.00')
print('\nW.C. = 280.00')
print('='*80)
print('Total estimated cost limited to \u20B956,000.00')
fr.signature(56000,'fifty six thousands only',1,'')


