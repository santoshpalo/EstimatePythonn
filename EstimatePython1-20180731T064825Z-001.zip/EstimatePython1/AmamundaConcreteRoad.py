#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 11 16:57:30 2018

@author: spalo
"""

import ConcreteRoad as cr
import textwrap
import FunctionLibrary as fl

print(textwrap.fill('Name of the work:-Construction of concrete road near culvert on road from Amamunda to Kuhibahal'))
print('Estimated Cost:-\u20B92,00,000.00\t\tHead of Account:-')
print('-'*80)
road = cr.VariableWidth([['patch 1',2,4.77,3.2],
                          ['patch 2',13.24,3.2,3.12],
                          ['patch 3',15.24,3.12,3.07],
                          ['patch 4',26.06,3.1,3.07],
                          ['patch 5',4,3.07,4.5],
                          ['patch 6',9.75,3.15,3.81],
                          ['patch 7',3.2,3.81,4.72]],[0.15,0.15],[.05,.09,.09])
#print(road.surface_areaR())
#road.foundation()
#road.sand_fill()
#road.metal_concrete()
#road.chips_concrete()
#road.vibrator()
#road.rscs()
#road.miscellaneous()
#print(road.cessR())
#print('-'*80,'\n','Total estimated cost amounts to \u20B9',road.totalR(),'limited to \u20B9 2,00,000.00')
#fl.signature(200000,'Rupees two lakh only',1,'')

road.labour_material()