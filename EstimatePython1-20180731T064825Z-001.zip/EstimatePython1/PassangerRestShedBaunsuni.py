import ClassLibrary as cl 
import FunctionLibrary as fl 
import items as it





if __name__ == "__main__":
    print(it.items['efhs'])
    foundation=cl.Quantity([['both side guard walls',2,7,1.4,1.5]])
    foundation.rate=103.2
    foundation.volume()
    print(it.items['CC(1:3:6)'])
    concrete=cl.Quantity([['walls',2,7,.7,2.0],
                          ['sub-base',1,7.3,7.0,0.1]])
    concrete.rate=3397.01
    concrete.volume()
    print(it.items['CC(1:2:4)'])
    pcc=cl.Quantity([['crust',1,7.3,7,0.1]])
    pcc.rate=4780.38
    pcc.volume()
    print(it.items['asfloor'])
    floor=cl.Quantity([['floor',1,5.95,2.9]])
    floor.rate=201.47
    floor.hArea()
    plaster12=cl.Quantity([['out side walls',1,19.7,3.2],
                           
                           ['doors',-2,1.68,2],
                           ['windows',-2,0.9,0.9],
                           ['below plinth',1,13.25,1.8]
                           ])
    plaster12.rate=84.21
    plaster12.vArea()
    plaster16=cl.Quantity([
                           ['inside of walls',1,17.7,3.2],
                           ['doors',-2,1.68,2],
                           ['windows',-1,0.9,0.9],
                           ['walls under seat',1,6*.45+.25,0.45]
                           
                           ])
    plaster16.rate=118.36
    plaster16.vArea()
    print('Area of water proofing cement paint = 146.25sqm @ Rs. 12.07/sqm = Rs.1765.00 ')
    print(it.items['rscs_walls'])
    wall=cl.Quantity([['walls sides',4,7,2.0]])
    wall.rate=387.3
    wall.vArea()

    
    
    
    
    
    
    