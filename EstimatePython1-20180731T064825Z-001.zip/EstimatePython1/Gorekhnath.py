import math as mt
Length_boundary = 170.08
foundation = ([['Boundary wall',1,170.08,0.75,0.75],
               ['chequered tile portion 1',2,29.26,0.2,0.2],
               ['chequered tile portion 2', 2, 27.23, 0.2,0.2],
               ['chequered tile portion 3', 2, 9.14, 0.2,0.2],
               ['sambalpuri stone portion 1',1,58.83,0.2,0.2],
               ['sambalpuri stone portion 2',1,18.29,0.2,0.2],
               ['Garage long wall',1,31.39,0.6,0.6],
               ['Garage short walls',2,5.49,0.6,0.6],
               ['Drain ',1,28.65,0.75,0.45],
               ['circular pindi 1',1,8.23,0.6,0.6],
               ['circular pindi 2',3,10.06,0.6,0.6],
               ['circular pindi 3',3,9.14,0.6,0.6],
               ['circular pindi 4',2,9.45,0.6,0.6],
               ['circular pindi 5',1,9.75,0.6,0.6],
               ['pastime shed pillars',4,1.2,1.2,1.2]])
metal_concrete = ([['Boundary wall',1,Length_boundary,0.75,0.15],
                  ['chequered tile portion 1 cutoff', 2, 29.26, 0.2, 0.25],
                  ['chequered tile portion 1 base', 1, 29.26,4.27 , 0.1],
                  ['chequered tile portion 2', 2, 27.23, 0.2, 0.25],
                  ['chequered tile portion 2 base', 1, 27.23, 4.88, 0.1],
                  ['chequered tile portion 3', 2, 9.14, 0.2, 0.25],
                  ['chequered tile portion 3 base', 1, 9.14, 1.68, 0.1],
                  ['sambalpuri stone portion 1', 2, 58.83, 0.2, 0.25],
                  ['sambalpuri stone portion 1 base', 1, 58.83, 1.22, 0.1],
                  ['sambalpuri stone portion 2', 2, 18.29+10.06, 0.2, 0.25],
                  ['sambalpuri stone portion 2 base', 1, 18.29, 10.06, 0.1],
                  ['Garage long wall', 1, 31.39, 0.6, 0.15],
                  ['Garage short walls', 2, 5.49, 0.6, 0.15],
                  ['Garage base concrete',1,31.39,5.49,0.1],
                  ['Drain ', 1, 28.65, 0.75, 0.15],
                  ['circular pindi 1', 1, 8.23, 0.6, 0.15],
                  ['circular pindi 2', 3, 10.06, 0.6, 0.15],
                  ['circular pindi 3', 3, 9.14, 0.6, 0.15],
                  ['circular pindi 4', 2, 9.45, 0.6, 0.15],
                  ['circular pindi 5', 1, 9.75, 0.6, 0.15],
                  ['pastime shed pillars', 6, 1.2, 1.2, 1.15]])
asflooring = ([['Garage long wall', 1, 31.39, 0.2, 0.25],
                  ['Garage short walls', 2, 5.49, 0.2, 0.25],
                  ['Garage base concrete',1,31.39,5.49,0.1],
                  ['Garage brick pillars', 8, 0.6, 0.6, 0.15],
                  ['Drain ', 1, 28.65, 0.75, 0.15],
                  ['circular pindi 1', 1, 8.23, 0.6, 0.15],
                  ['circular pindi 2', 3, 10.06, 0.6, 0.15],
                  ['circular pindi 3', 3, 9.14, 0.6, 0.15],
                  ['circular pindi 4', 2, 9.45, 0.6, 0.15],
                  ['circular pindi 5', 1, 9.75, 0.6, 0.15],
                  ['pastime shed pillars', 6, 1.2, 1.2, 1.15]])
sand_filling = ([['Boundary wall',1,Length_boundary,0.75,0.15],
                  ['chequered tile portion 1 base', 1, 29.26,4.27 , 0.05],
                  ['chequered tile portion 2 base', 1, 27.23, 4.88, 0.05],
                  ['chequered tile portion 3 base', 1, 9.14, 1.68, 0.05],
                  ['sambalpuri stone portion 1 base', 1, 58.83, 1.22, 0.05],
                  ['sambalpuri stone portion 2 base', 1, 18.29, 10.06, 0.05],
                  ['Garage long wall', 1, 31.39, 0.2, 0.25],
                  ['Garage short walls', 2, 5.49, 0.2, 0.25],
                  ['Garage base concrete',1,31.39,5.49,0.1],
                  ['Garage brick pillars', 8, 0.6, 0.6, 0.15],
                  ['Drain ', 1, 28.65, 0.75, 0.1],
                  ['circular pindi 1', 1*mt.pi, 1.86+.38, 0.6, 0.1],
                  ['circular pindi 2', 3*mt.pi, 2.44+.38,0.6, 0.1],
                  ['circular pindi 3', 3*mt.pi, 2.15+.38,0.6, 0.1],
                  ['circular pindi 4', 2*mt.pi, 2.25+.38,0.6, 0.1],
                  ['circular pindi 5', 1*mt.pi, 2.34+.38,0.6, 0.1],
                  ['circular pindi 1', 1*mt.pi/4, 1.86, 1.86, 0.6],
                  ['circular pindi 2', 3*mt.pi/4, 2.44,2.44, 0.6],
                  ['circular pindi 3', 3*mt.pi/4, 2.15,2.15, 0.6],
                  ['circular pindi 4', 2*mt.pi/4, 2.25,2.25, 0.6],
                  ['circular pindi 5', 1*mt.pi/4, 2.34, 2.34, 0.6],
                 ['pastime shed',1,15.01,0.6,0.1],
                  ['pastime shed',1,4.72,4.42,0.6],
                  ['pastime shed pillars', 6, 1.2, 1.2, 0.1]])
rrhg_masonry =([['Boundary wall 1st Footing',1,Length_boundary,0.6,0.3],
                ['Boundary wall 2nd Footing', 1, Length_boundary, 0.45, 0.3],
                ['Boundary wall 3rd Footing', 1, Length_boundary, 0.38, 0.6],
                ['circular pindi 1', 1, 7.05, 0.38, 1.2],
                ['circular pindi 2', 3, 8.87, 0.38, 1.2],
                ['circular pindi 3', 3,7.95, 0.38, 1.2],
                ['circular pindi 4', 2, 9.45, 0.38, 1.2],
                ['circular pindi 5', 1, 9.75, 0.38, 1.2],
                ['pastime shed walls', 1,17.98-4*0.25, 0.38, 1.2]
                ])
brick_masonry = ([['Boundary wall',1,Length_boundary,0.25,1.8],
                  ['Garage pillars',8,0.38,0.38,3.65],
                  ['Garage back side wall extra height',1,31.39,0.25,1.8]])
plaster_16 = ([['Boundary wall',1,Length_boundary,1.8],
               ['Garage pillars', 8*4, 0.38, 3.65],
               ['Garage back side wall extra height', 2, 31.39, 1.8],
               ['circular pindi 1',1,8.23,0.75],
               ['circular pindi 2',3,10.06,0.75],
               ['circular pindi 3',3,9.14,0.75],
               ['circular pindi 4',2,9.45,0.75],
               ['circular pindi 5',1,9.75,0.75],
               ['pastime shed',1,19.51,0.75]
               ])
dpc = ([['Boundary Wall',1,Length_boundary,0.38]])
wpcp = ([['Boundary wall',2,Length_boundary,1.8],
         ['Garage pillars', 8*4, 0.38, 3.65],
         ['Garage back side wall extra height', 2, 31.39, 1.8]

         ])
ceramic_tile = ([['chequered tile portion 1',1,29.26,4.27],
               ['chequered tile portion 2', 1, 27.23,4.88],
               ['chequered tile portion 3', 1, 9.14, 1.68],
               ['sambalpuri stone portion 1',1,58.83,1.2],
               ['sambalpuri stone portion 2',1,18.29,10.06]])
rcc = ([['columns footings',4,1.2,1.2,0.3],
        ['columns',4,0.25,0.25,4.6],
        ['rcc beams',2,5.18,0.25,0.25],
        ['rcc beams 2',2,5.49,0.25,0.25],
        ['rcc slab',1,5.5,5.2,0.1]])
rscs_column = ([['columns ',4*4,0.25,3.65],
                ['beams 1',2,4.68,0.75],
                ['beams 2',2,4.98,0.75]])
rscs_slab = ([['slab',1,6.09,5.79]])
rscs_footings = ([
                  ['chequered tile portion 1 cutoff', 2*2, 29.26, 0.25+.35],
                  ['chequered tile portion 2 cutoff', 2*2, 27.23, 0.25+.35],
                  ['chequered tile portion 3 cutoff', 2*2, 9.14, 0.25+.35],
                  ['sambalpuri stone portion 1 cutoff', 2*2, 58.83, 0.25+.35],
                  ['sambalpuri stone portion 2 cutoff', 2*2, 18.29+10.06, 0.25+.35],
                  ['column footings of pastime shed',4*4,1.2,0.3]

                 ])
gci_roofing =([['Garage and Godown roofing',1,31.39,6.0]])

#==========================

