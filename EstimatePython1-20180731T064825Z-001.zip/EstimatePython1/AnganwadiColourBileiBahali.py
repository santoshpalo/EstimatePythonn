import pandas as pd

import items as it
import LeadStatement1 as ls1
from tkinter import *
import FunctionLibraryR as fr
import textwrap
print(textwrap.fill('Name of the work:-',80))
print('Estimated Cost:-               \t\t\tHead of Account:-')
print('-'*80)
#Total centre line length calculation
tcl_MahadaII = ([['']])
x5=  ([['long walls',3,6.07],
          ['short walls 1',2,6.63],
          ['short wall 2',1,2.73]
          ])

distemper=([['walls both sides',2,34.2-0.5,3.3],
            ['deduct weather coat external area',-2,6.32+6.63+.25,3.3],
            ['deduct door1', -0.5*2, 1.1, 1.98],
            ['deduct door2',-1,0.9,1.98],
            ['deduct windows',-2*0.5,1.08,1.08],
            ['deduct windows2',-2*0.5,0.75,1.98]


            ])
weathercoat= ([['effective length',2,6.32+6.88,3.3],
               ['plinth',2,6.32+6.88+.26,0.45],
      ['Door opening', -0.5, 1.08, 1.98],
      ['Window openings', -2*0.5, 1.08, 1.08],
               ['window openings 2',-2*0.5,0.75,1.08]])
wpcp=([['roof area',1,6.63+0.25,6.07+.25],
       ['bearing area',-1,34.19-0.5,0.25]])
dw= ([['Doors1',2.25,0.9,1.98],
['Doors2',2.25*2,1.08,1.98],

      ['Windows',2*2.75,0.75,1.08],
      ['windows21', 2*2.25, 1.08, 1.08],])


class AWC:
    def __init__(self,master):
        frame = Frame(master,bg = 'red')
        frame.pack()
        self.Label = Label(frame, text = 'Quantity')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.TCL = Button(frame,text = "Total centre line length",command = self.TCL)
        self.TCL.pack(side=TOP)
        self.distemper = Button(frame, text="Distempering", command=self.distemper)
        self.distemper.pack(side=TOP)
        self.weather_coating = Button(frame, text="Weather coating", command=self.weather_coating)
        self.weather_coating.pack(side=TOP)
        self.painting = Button(frame, text="Door and Window painting", command=self.Painting)
        self.painting.pack(side=TOP)
        self.wpcp = Button(frame, text="Water proofing cement paint", command=self.wpcp)
        self.wpcp.pack(side=TOP)
    def TCL(self):
        d = x5
        table = pd.DataFrame(d, index=range(1, len(d) + 1),
                             columns=['description', 'no', 'length'])
        table['quantity'] = table['no'] * table['length'] .round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)

        print('\n', 'Total centre line length', '\n', table, '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}m'.format(table.tquantity))
    def distemper(self):
        d = distemper
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['distemper'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.distempering()),'\u20B9{:.2f} '.format(round(fr.distempering()*table.tquantity,0)))
    def weather_coating(self):
        d = weathercoat
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['wall_paint'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.wallpainting()),'\u20B9{:.2f} '.format(round(fr.wallpainting()*table.tquantity,0)))
    def Painting(self):
        d = dw
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['paint'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.painting()),'\u20B9{:.2f} '.format(round(fr.painting()*table.tquantity,0)))

    def wpcp(self):
        d = wpcp
        table = pd.DataFrame(d, index=range(1, len(d) + 1), columns=['description', 'no', 'length', 'height'])
        table['quantity'] = table['no'] * table['length'] * table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', textwrap.fill('''Finishing walls with water proofing
cement paint of approved shade on
new work two coat to give an even
shade exculding cost of paint.''', 80), '\n', table, '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}sqm'.format(table.tquantity), '@ \u20B9{:.2f} /sqm = '.format(8.80),
              '\u20B9{:.2f} '.format(round(8.8 * table.tquantity, 0)))




if __name__ == "__main__":
    root = Tk()
    app = AWC(root)
    root.mainloop()
    print('\nCost of Distemper 17.70 kg @ \u20B9 66.00 / kg = \u20B9 1168.00')
    print('\n Cost of weather coat 10.46ltr. @ \u20B9 192.00 /ltr. = \u20B9 2008.00')
    print('\nCost of paint 2.20ltr. @ \u20B9 193.00/ltr. = \u20B9 425.00')




































































# #Mahada I
# import numpy as np
#
# x1 = ([['external long wall',2,5.5],
#        ['external short wall',2,8.23]])
# TCL = x1
# y= ([['total wall area',1,39.1-3*0.25-27.46,3.3],
#      ['verandah opening 1',-2/2.0,2.45,1.98],
#      ['verandah opening 2',-1/2.0,1.4,1.98],
#      ['Door 1',-3/2.0,1.08,1.98],
#      ['Windows',-5/2.0,0.9,1.2]])
