import ClassLibrary as cl 
import items as it













if __name__ == "__main__":
    print(it.items['efhs'])
    excavation = cl.Quantity([['cut-off walls1',2,40.84,0.3,0.2],
                             ['cut-off walls2',2,11.3,0.2,0.2],
                             ['cut-off wall3',1,3.95,0.2,0.2]])
    excavation.rate=103.2
    excavation.volume()
    print('\nCalculation of built up area\n')
    builtuparea = cl.Quantity([['area1',1,11.9,5.5,4.25],
                               ['area2',1,5.5,3.65,6.1],
                               ['area3',1,3.65,3.05,6.1],
                               ['area4',1,3.15,3.05,6.1],
                               ['area5',1,3.15,3.05,6.1],
                               ['area6',1,3.05,3.05,14],
                               ['area7',1,6.1,4.88,3.95],
                               ['area8',1,4.88,3.86,11.28]])
    builtuparea.trapeziumArea()
    print('\nArea of cut-off walls\n')
    cutoffwalls= cl.Quantity([['cut-off walls1',2,40.84,0.3],
                             ['cut-off walls2',2,11.3,0.2],
                             ['cut-off walls3',1,3.95,0.2]])
    cutoffwalls.rate =0
    cutoffwalls.hArea()
    
    print(it.items['sand_filling'])
    sandfilling = cl.Quantity([['builtup area',236.81,.25],
                               ['cut off area',-29.81,0.25]])
    sandfilling.rate= 302.62
    sandfilling.areaVolume()
    print(it.items['CC(1:3:6)'])
    subbase=cl.Quantity([['subbase',236.81,0.09]])
    subbase.rate= 3647.57
    subbase.areaVolume()
    cutoffwall = cl.Quantity([['cut-off walls1',1,40.84,0.3,0.6],
                              ['cut-off walls2]',1,40.84,0.3,0.3],
                             ['cut-off walls3',2,11.3,0.2,0.3],
                             ['cut-off walls4',1,3.95,0.2,0.3]])
    
    cutoffwall.rate =3647.57
    cutoffwall.volume()
    crust=cl.Quantity([['area of crust',236.81,0.09]
                       ])
    crust.rate=4749.14
    crust.areaVolume()
    print(it.items['rscs_walls'])
    centerinwalls=cl.Quantity([['walls',2,40.8,0.3],
                               ])
    centerinwalls.rate =387.06
    centerinwalls.vArea()
    print(it.items['rscs_plinth'])
    centeringcutoff = cl.Quantity([['cut-off walls2',2,40.84,0.1],
                             ['cut-off walls3',2,11.3,0.3],
                             ['cut-off walls4',1,3.95,0.1]])
    centeringcutoff.rate = 128.82
    centeringcutoff.vArea()
    print(it.items['Earth_work_mechanical'])
    earthwork=cl.Quantity([['in berms',1,40.88,1.2,0.6]])
    earthwork.rate = 118.9
    earthwork.volume()
    print('Hire and running charges of plate vibrator =21.31 hr @ Rs.106.00/ hour = Rs.3286.00 ')
    
    
    
    
    
    
    
    