import pandas as pd
def a(x):
    return round(x*.3048,2)
vitrified = ([['hall',1,a(41),a(28.75)],
              ['rest room',1,a(28.4166),a(11.833)],
              ])
walltile=([['long walls',2,a(41),0.9],
           ['short walls',2,a(28.75),0.9],
           ['deduct doors',-4,a(3.75),0.9],
           ['add column and wall projections',20,0.15,0.9],
           ['rest room long walls',2,a(28.4166),0.9],
           ['rest room short walls',2,a(11.833),0.9],
           ['rest room openings1',-2,a(3.5),0.9],
           ['rest room openings2',-2,a(2.33),0.9],
           ['door projections',8,0.1,0.9],
           ['toilets long walls',2,a(6.66),0.9],
           ['toilets short walls',2,a(4.166),0.93],
           ['deduct door openings',-2,a(2.33),0.95],
           ['add door projections',4,0.1,0.9]])
floortile=([['toilet floor',2,2.03,1.27]])
def vitrifiedd(d):
    y=pd.DataFrame(d,columns=['description','no','length','width'],index = range(1,len(d)+1))
    y['quantity']=round(y['no']*y['length']*y['width'],2)
    tq= y['quantity'].sum()
    print(y,'\n\t\t\t\t',tq)
if __name__ == "__main__":
    vitrifiedd(floortile)

