import ClassLibrary as cl
import items as it
import math
import FunctionLibraryR as fr
print(it.items['bmsscb'])
brickm=[['front side opening wall',1,1.57,0.25,0.9],
       ['front opening pillar',1,0.45,0.25,2.1],
       ['right side opening grills',1,1.65,0.25,0.9]]
brick=cl.Quantity(brickm)
brick.rate=2500
brick.volume()
print(it.items['12cp(1:6)'])
plaster12=[['front side opening wall',1,1.57,0.9],
       ['front opening pillar',1,0.45,2.1],
       ['right side opening grills',1,1.65,0.9]]
plaster12=cl.Quantity(plaster12)
plaster12.rate=100
plaster12.vArea()
plaster16=[['front side opening wall',1,1.57,0.9],
       ['front opening pillar',1,0.45,2.1],
       ['right side opening grills',1,1.65,0.9]]
plaster16=cl.Quantity(plaster16)
plaster16.rate=100
plaster16.vArea()
print(it.items['paint'])
paint=[['grill1',0.5,1.1,1.2],
       ['grill 2',0.5,1.2,2.1],
       ['grill3',0.5,1.5,1.2]]
paint=cl.Quantity(paint)
paint.rate=100
paint.vArea()
print('Cost and conveyance of M.S. grill windows and doors=1.15q @ \u20B96500.00\u20B97475.00')
print(it.items['efhs'],'\n')
foundation = cl.Quantity([['soak pit trench',math.pi/4,1.2,1.2,1.5]])
foundation.rate = 103.2
foundation.volume()
print('\n',it.items['CC(1:4:8)'])
concrete = cl.Quantity([['soak pit trench',math.pi/4,1.2,1.2,0.1]])
concrete.rate = fr.concrete(1)
concrete.volume()
print('\n','Supplying and fixing of R.C.C.rings and coverplate\n')
print('Cost of R.C.C. rings = 4nos @ \u20B9300.00 = \u20B9 1200.00')
print('Cost of R.C.C. coverplate = 1 no @ \u20B9 350.00 = \u20B9 350.00')
print(it.items['water closet I'])
print('\t\t\t\t\t\t\t1 no @ \u20B9 1134.08'
          ' = \u20B9 1134.08')
print('''Fixing ladies urinal pan pan duly embeddedin c.c.
(1:4:8) using hard granite metal 4cm nominal size all complete as per
specification 500mm x 440mm size white glazed vitreous china orissa pattern
squatting pan''')
print('\t\t\t\t\t\t\t1 no @ \u20B9 1003.03'
          ' = \u20B9 1003.03')
print(it.items['p or s trap'])
print('\t\t\t\t\t\t\t1 no @ \u20B9 304.49 = \u20B9 304.49')
print(it.items['pvc pipe'])
print('\t\t\t\t\t\t\t6.10m no @ \u20B9 194.59 = \u20B9 1187.00')
print(it.items['pvc soil pipe'])
print('\t\t\t\t\t\t\t3.05 no @ \u20B9 144.59'
          ' = \u20B9 441.00')
print(it.items['pvc moulded fitting'])
print('\t\t\t\t\t\t\tsingle Tee 1 no @ \u20B9 80 = \u20B9 80')
print('\t\t\t\t\t\t\tbend 2 no @ \u20B9 60.00 = \u20B9 120.00')
print('\t\t\t\t\t\t\t100mm dia pvc cowl @ \u20B9 25.00 = \u20B9 25.00')





