import ClassLibrary as cl
import FunctionLibraryR as fr
import items as it



foundation=[['column foundations',9,1.5,1.5,1.5],
            ['wall foundations long',6,4.39-1.5,0.7,0.45],
            ['wall foundation short 1',3,3.91-1.5,0.7,0.45],
            ['wall foundation short 2',4,2.19-1.5,0.7,0.45],
            ['wall foundation short 3',2,1.83-0.7,0.7,0.45]
             ]
foundation=cl.Quantity(foundation)
foundation.rate=176*2/2.83
foundation.volume()
print(it.items['CC(1:3:6)'])
concrete=[['column foundations',9,1.5,1.5,.1],
            ['wall foundations long',6,4.39-0.45,0.7,0.1],
            ['wall foundation short 1',3,3.91-0.45,0.7,0.1],
            ['wall foundation short 2',4,2.19-0.45,0.7,0.1],
            ['wall foundation short 3',2,1.83-0.45,0.7,0.1]
             ]
concrete=cl.Quantity(concrete)
concrete.rate=3636.57
concrete.volume()
rcc=[['column footings',9,1.2,1.2,0.35],
     ['column pedestals',9,0.45,0.45,0.5],
     ['plinth beam long',3,9.00,0.25,0.3],
     ['plinth beam short 1',3,3.65,0.25,0.3],
     ['plinth beam short 2',4,2.19-.25,0.25,0.3],
     ['plinth beam short 3',2,1.83,0.25,0.3],
     ['plinth above columns',9,0.25,0.25,0],
     ]
rcc=cl.Quantity(rcc)
rcc.rate=4435.46
rcc.volume()
hysd=[['footing bars',9 ,1.7,0.62],
      ['footing bars 2',9,1.14,0.62],
      ['column main bars',4*9,6.0,1.58],
      ['pedestal bars',9*8,1.2,0.62],
      ['column stirrups',9*6,0.87,0.395],
      ['pedestal stirrups',9*6,0.37*4+.07,0.395],
      ['plinth bend main bar',5*3,8.96,0.89],
      ['plinth bend main bar 2',5*3,6.27,0.89],
      ['plinth bend short main bars',3*4,1.85+.5-.1,0.89],
      ['plinth bend extra top 1',3,3,0.89],
      ['plinth bend extra top 2',6,1.63,0.89],
      ['plinth bend extra top 3',3,1.47,0.89],
      ['plinth bend extra top 4',3,2.07,0.89],
      ['plinth bend extra top 5',3,0.85,0.89],
      ['stirrups',310,0.97,0.395],
      ['column stirrups',9*9,0.87,0.395]
      ]
hysd=cl.Quantity(hysd)
hysd.rate=4303.66
hysd.reinforcement()
brickfp=[['long walls',2,3.95,0.4,0.65],
         ['long walls',2,3.95,0.4,0.55],
         ['long walls',2,3.95,0.25,0.55],
         ['short walls',2,3.45,0.4,0.55],
         ['short walls',1,3.45,0.25,0.55],
         ['short walls 1',2,1.6,0.4,0.55],
         ['short walls 2',1,1.6,0.25,0.55],
         ['short walls 3',2,1.88,0.25,0.55],
         ['long walls', 6, 3.95, 0.25, 0.25],
         ['short walls', 3, 3.65, 0.25, 0.25],
         ['short walls 1', 4, 1.93, 0.25, 0.25],
         ['short walls 3', 2, 1.88, 0.25, 0.25],
         ['plinth beam long', -2,9.39, 0.25, 0.3],
         ['plinth beam short', -2, 6.36, 0.25, 0.3]]

brickfp=cl.Quantity(brickfp)
brickfp.rate=3226.2
brickfp.volume()
sandfill=[['foundation trench',9,1.5,1.5,0.15],
          ['foundation trench above footings',9,1.5,1.5,0.75],
          ['deduct rcc pedestals',-9,0.45,0.45,.5],
          ['wall foundations long', 6, 4.39 - 1.5, 0.7, 0.1],
          ['wall foundation short 1', 6, 3.91 - 1.5, 0.7, 0.1],
          ['wall foundation short 2', 3, 1.88 - 1.5, 0.7, 0.1],
          ['wall foundation short 3', 2, 1.83 - 0.7, 0.7, 0.1]
          ]
sandfill=cl.Quantity(sandfill)
sandfill.rate=277.34
sandfill.volume()
#2nd phase of work
rccm20=[['columns above plinth',9,0.25,0.25,1.2],

        ]
rccm20=cl.Quantity(rccm20)
rccm20.rate=4435.46
rccm20.volume()
hysd1=[['stirrups in columns',16*9,0.71,0.395],
       ]
hysd1=cl.Quantity(hysd1)
hysd1.rate=4303.66
hysd1.reinforcement()
bmfp1=[['long walls',6,4.14,0.25,0.25],
       ['short walls 1',3,3.65,0.25,0.25],
       ['short walls 2',4,1.63,0.25,0.25],
       ['short walls 3',1,1.6,0.25,0.25]]
bmfp1=cl.Quantity(bmfp1)
bmfp1.rate=3226.2
bmfp1.volume()
bmss1=[['long walls',6,4.14,0.25,0.9],
       ['short walls 1',3,3.65,0.25,0.9],
       ['short walls 2',4,1.63,0.25,0.9],
       ['short walls 3',1,1.6,0.25,0.9],
        ['deduct half thick wall',-1,1.6,0.12,0.9],
       ['deduct door 1',-1,1.2,0.25,0.9],
       ['deduct door 2',-3,0.9,0.25,0.9],
       ['deduct door 3',-2,0.75,0.25,0.9],
       ]
bmss1=cl.Quantity(bmss1)
bmss1.rate=3226.2
bmss1.volume()
sandfill1=[['volume',1,9.04,6.05,0.15],
           ['deduct brick volume',-1,1.51,1,1],
           ['rcc',-9,0.25,0.25,0.15]]
sandfill1=cl.Quantity(sandfill1)
sandfill1.rate=277.34
sandfill1.volume()
rscscolumn=[['columns',4*9,0.25,1.2]]
rscscolumn=cl.Quantity(rscscolumn)
rscscolumn.rate=462.1
rscscolumn.vArea()



