import FunctionLibrary as fl
import textwrap
EC = 'Rs.{:.2f}'.format(200000)
ECT = '(tWO lakh only)'
NW ='''Construction of C.C. Road from Kaudiamunda to Tamultikira
'''
HA = 'out of g.g.y. (2016-17) head of account'
text = '''\n\tThis Estimate consists of C.C. road with sand filling in subgrade, C.C.(1:3:6)
in sub-base and C.C.(1:2:4) in surface of the road
  '''
middle = '''\n\tThis estimate has been prepared based on Analysis of Rates 2006. Schedule of
Rates - 2014 has been taken into Account.Prevailing Labour rateshave been taken
into account at framing of the estimate.'''
conclusion = '''\n\tAll works will be executed as per guidance of engineer-in-charge.'''











if __name__ == "__main__":
    

    print('\n\t','This estimate amounting to',EC+ECT,'has been framed to meet the probable expenditure towards',NW+HA+text)


    print(middle)
    print(conclusion)
    print(fl.signature(0,'',0,''))
    


