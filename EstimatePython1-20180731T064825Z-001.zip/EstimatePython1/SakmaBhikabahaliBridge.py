l=13.50
h = 2.5
foundation = ([['protection wall',1,7.5,1.5,1.2],
               ['guard wall adjacent to the field',1,l,1.5,1.2]])
crhg = ([['C.R.H.G. Guard wall',1,8.1,0.6,1.8,3.5]])
metal_concrete= ([['D/S appron area',1,15.15,4.59,0.1],
                  ['U/S appron part 1',1,13.6,2,0.1],
                  ['U/S appron part 2',1,1.85,3.5,0.1],
                  ['U/S appron part 3',1,1.95,2.3,0.1],
                  ['protection wall bottom',1,7.2,1.2,0.6],
                  ['protection wall top',1,7.2,0.45,1.2]])
metal_concrete_wall_1 = ([['C.C.Guard wall',1,l,0.3,1.2,h]])
chips_concrete = ([['D/S appron area',1,15.15,4.59,0.1],
                ['U/S appron part 1',1,13.6,2,0.1],
                  ['U/S appron part 2',1,1.85,3.5,0.1],
                  ['U/S appron part 3',1,1.95,2.3,0.1],
                   ['top of new retaining wall',1,8.1,0.45,0.08]])
rscs_footing = ([['D/S appron sides',1,15.15,0.2],
                 ['D/S appron sides',2,4.59,0.2],
                  ['U/S side appron ',2,17.4,0.2]])
rscs_wall = [['protection wall bottom',1,7.2,0.6],
            ['protection wall top',1,7.2,1.2],
                ['Guard wall vertical side',1,l,h],
                ['guard wall slanting side',1,l,h+0.1]]


