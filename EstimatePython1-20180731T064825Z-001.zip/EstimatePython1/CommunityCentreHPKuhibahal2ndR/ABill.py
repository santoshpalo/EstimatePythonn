import ClassLibrary as cl
import math as mt
def a (x):
    return round(x*0.3048,2)

tcl = cl.Quantity([['long walls',2,a(25.75-.8333)],
                       ['short walls',2,a(20-.833)]])
tcl.tcl()
plaster12=cl.Quantity([['alround walls',1,26.86+1,3.3],
                       ['deduct for doors',-0.5,1.2,2.1],
                       ['deduct for windows',-6*0.5,0.9,1.2]])
plaster12.rate=88.73
plaster12.vArea()
plaster16=cl.Quantity([['alround walls',1,26.86-1,3.3],
                       ['deduct for doors',-0.5,1.2,2.1],
                       ['deduct for windows',-6*0.5,0.9,1.2]])
plaster16.rate=128.17
plaster16.vArea()
print('Cost of M.S. doors and windows=4.25q @ 7000.00/qtl=\u20B929750.00')
print('Conveyance of doors and windows=\u20B91000.00')
print('Extra labour charges for 1st floor work')
print('Extra Unskilled labour=',mt.ceil(0.12*87.44*.05+80.84*.24*.03))
print('Extra skilled labour=',mt.ceil(0.14*87.44*.05+80.84*.16*.03))
print('\n','2nos extra labour charges @ \u20B9 224.30 = \u20B9 448.6')
print('\n','2nos extra labour charges @ \u20B9 264.30 = \u20B9 528.6')
print('enhanced unskilled labour charges=',56,'@\u20B910.80','=\u20B9605.00')
