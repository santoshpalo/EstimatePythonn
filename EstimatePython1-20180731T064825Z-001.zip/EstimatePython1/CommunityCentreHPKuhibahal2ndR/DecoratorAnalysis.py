import pandas as pd
u_s=224.3
ss=264.3
# def Velocity_decorator(Velocity):
#     def wrapper(displacement,time):
#         print('The displacement =','{:.2f}m'.format(displacement))
#         print('The time =', '{:.2f}sec'.format(time))
#         print('The velocity is','{:.2f}m/sec'.format(Velocity(displacement,time)))
#         return Velocity(displacement,time)
#     return wrapper
#
# @Velocity_decorator
# def Velocity(displacement,time):
#     return displacement/time
# print(Velocity(4,5))
# Defining a function decorator for plaster 12mm thick (1:6)
data=[[0.12,'nos',u_s],[0.14,'nos',ss],[.0358,'qtl',100],[.015,'cum',100]]
# def plaster12_decorator(plaster12):
#     def wrapper(data):
#         plaster12(data)
#     return wrapper
#
#
#
#
# @plaster12_decorator
def plaster12(data):
    table=pd.DataFrame(data,index=['unskilled labour','skilled labour','cement','sand'],columns=['quantity','unit','rate'])
    table['total']=table['quantity']*table['rate']
    tamount=table['total'].sum()
    print (table)
    return tamount
print(plaster12(data))