import pandas as pd
import math as mt
import items as it
import LeadStatement1 as ls1
from tkinter import *
import FunctionLibraryR as fr
import textwrap
print(textwrap.fill('Name of the work:-Construction of Burial Ground at Kuhibahal, Mahada G.P.',80))
print('Estimated Cost:-2,50,000.00\t\t\tHead of Account:-14th C.F.C.(2016-17)')
print('-'*80)
#======
tcl= ([['long walls',2,7.37],
       ['short walls',2,3.71]])
foundation=([['column foundations',6,1.5,1.5,1.5],
             ['peripherrial walls',1,22.16-6*1.5,0.7,0.65]])
pcc = ([['column foundations',6,1.5,1.5,0.15],
             ['peripherrial walls',1,22.16-6*1.5,0.7,0.1],
        ['floor subbase',1,7.11,3.46,0.1]])
rcc=([['R.C.C, footings',6,1.2,1.2,0.3],
      ['R.C.C. pedestals',6,0.45,0.45,1.2],
      ['R.C.C. columns below plinth',6,0.25,0.25,1.35],
      ['Plinth beam',1,22.16,0.25,0.25],
      ['columns above plinth bend',6,0.25,0.25,3.15],
      ['R.C.C. slab',1,8.2,4.57,0.1],
      ['R.C.C. beams',1,22.16,0.25,0.2],
      ['Cross beam',1,3.46,0.25,0.25],
      ['deduct for vents',-2,0.6,0.6,0.1]])
brickfp=([['0.38m wide',1,22.16-6*0.45,0.38,1.2],
          ['0.25m wide',1,22.16-6*0.25,0.25,1.35]])
footing=([['footings of columns',6*4,1.2,0.3],
          ['plinth beam',2,22.16,0.25]])
column = ([['pedestals',6*4,0.45,1.2],
           ['columns below plinth',6*4,0.25,1.35],
           ['beams',1,26.16,0.65],
           ['beam1',1,3.45,0.75]])
slab=([['slab',1,8.2,4.57],
      ['deduct beam1',-1,22.16,0.25],
      ['deduct beam2',-1,3.46,0.25]])
tor10 = ([['footings bar 1',6*(mt.ceil(1.08/0.15)),1.08+2*0.23],
          ['footings bar 2',6*(mt.ceil(1.08/0.15))+4,1.08],
          ['pedestal bars',6*8,1.42+.2],
          ])
tor12 = ([['plinth beam bars',4*2,7.37+.18],
          ['plinth beam bars',4*2,3.71+.18],
          ['roof beam bars long',2*5,7.37+.18],
          ['roof beam bars short',2*5,3.71+.18],
          ['roof beam middle',5,3.71+.18],
          ['extra bars at top',2,3.71/3+.25],
          ['extra bars at top',8,3.71/6+.2]])
tor8=([['column stirrups below plinth',6*mt.ceil(2.5/0.15),0.87],
       ['pedestal stirrups',60,1.8-.08],
       ['plinth beam stirrups',mt.ceil(6.87/0.15)*2,0.87],
       ['plinth beam short stirrups',mt.ceil(3.45/0.15)*2,0.87],
       ['column stirrups above plinth ',6*mt.ceil(3.15/0.15),0.87],
       ['beam stirrups',mt.ceil(6.87/0.15)*2,0.97],
       ['beam short stirrups',mt.ceil(3.45/0.15)*2,0.97],
       ['middle beam stirrups',mt.ceil(3.45/0.15),1.07],
       ['slab main bars',17,5.24],
       ['slab main bars2',17,4.45],
       ['slab main bar at top',2*15,3.45+.5+.3+.15],
       ['peripheral distribution 1',2*3,7.54],
       ['peripheral distribution 2',2*3,4.49],
       ['distribution 1 internal',2*3*2,7.54-.3-.3],
       ['distribution internal 2',20*2,3.45],
       ['extra bar at top',47,1.05],
       ['extra bars at the vent 1',4*5,0.6],
       ['distributions',4*5,1.8],
       ['corner bars',4*3,1.5]
       ])
tor16=([['column bars',6*4,1.5+1.35+0.45+.25+3.15+.2]])
sandfill =([['under footings',6,1.5,1.5,0.15],
            ['under walls',1,22.16-6*.45,0.7,0.1],
            ['plinth fill stage 1',1,7.12,3.46,1.35+.25-.1]])
plaster20 = ([['roof slab top',1,8.23,4.57]])
cc124 = ([['floor crust',1,7.63,4.57-.6,0.1]])
plaster12 = ([['alround plaster below plinth',1,22.16-7.62,1.6],
              ['alround plaster below plinth1',1,22.16-7.62+.13*3,1.2]])
#======
class Crematory:
    def __init__(self,master):
        frame = Frame(master,bg = 'red')
        frame.pack()
        self.Label = Label(frame, text = 'Quantity')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.TCL = Button(frame,text = "Total centre line length",command = self.TCL)
        self.TCL.pack(side=TOP)
        self.foundation = Button(frame, text="foundation", command=self.foundation, bg='blanched almond', fg='blue')
        self.foundation.pack(side=TOP)

        self.concrete148 = Button(frame, text="C.C.(1:4:8)", command=self.concrete148)
        self.concrete148.pack(side=TOP)
        self.rccm20 = Button(frame, text="R.C.C. M-20 grade concrete", command=self.rccm20)
        self.rccm20.pack(side=TOP)
        self.bmfpfa = Button(frame, text="brick masonry in FP with FA", command=self.bmfpfa)
        self.bmfpfa.pack(side=TOP)

        self.footing = Button(frame, text='RSCS footiong & plinth', command=self.footing)
        self.footing.pack(side=TOP)
        self.column = Button(frame, text='RSCS column & beam', command=self.column)
        self.column.pack(side=TOP)
        self.slab = Button(frame, text='RSCS slab & chajja', command=self.slab)
        self.slab.pack(side=TOP)
        self.tor_8 = Button(frame, text='8mm tor HYSD reinforcement bars', command=self.tor_8)
        self.tor_8.pack(side=TOP)
        self.tor_10 = Button(frame, text='10mm tor HYSD reinforcement bars', command=self.tor_10)
        self.tor_10.pack(side=TOP)
        self.tor_12 = Button(frame, text='12mm tor HYSD reinforcement bars', command=self.tor_12)
        self.tor_12.pack(side=TOP)
        self.tor_16 = Button(frame, text='16mm tor HYSD reinforcement bars', command=self.tor_16)
        self.tor_16.pack(side=TOP)
        self.sandfilling = Button(frame, text="Sand filling in F & P", command=self.sandfilling)
        self.sandfilling.pack(side=TOP)
        self.plaster_3 = Button(frame, text='20mm thick plaster (1:4)', command=self.plaster_3)
        self.plaster_3.pack(side=TOP)
        self.concrete124 = Button(frame, text="C.C.(1:2:4)", command=self.concrete124)
        self.concrete124.pack(side=TOP)
        self.plaster_1 = Button(frame, text='12mm thick plaster (1:6)', command=self.plaster_1)
        self.plaster_1.pack(side=TOP)

    def TCL(self):
        d = tcl
        table = pd.DataFrame(d, index=range(1, len(d) + 1),
                             columns=['description', 'no', 'length'])
        table['quantity'] = table['no'] * table['length'] .round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)

        print('\n', 'Total centre line length', '\n', table, '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}m'.format(table.tquantity))
    def foundation(self):
        d = foundation
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['efhs'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.foundation(1)),'\u20B9{:.2f} '.format(round(fr.foundation(1)*table.tquantity,0)))
    def concrete148(self):
        d = pcc
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['CC(1:4:8)'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.concrete(1)),'\u20B9{:.2f} '.format(round(fr.concrete(1)*table.tquantity,0)))
    def rccm20(self):
        d = rcc
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['m20'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.gradedconcrete(2)),'\u20B9{:.2f} '.format(round(fr.gradedconcrete(2)*table.tquantity,0)))
    def bmfpfa(self):
        d = brickfp
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['bmfpfa'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.brickmasonry(2)[0]),'\u20B9{:.2f} '.format(round(fr.brickmasonry(2)[0]*table.tquantity,0)))
    def footing(self):
        d = footing
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['rscs_plinth'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.rscs(3)),'\u20B9{:.2f} '.format(round(fr.rscs(3)*table.tquantity,0)))
    def column(self):
        d = column
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['rscs_beam'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.rscs(2)),'\u20B9{:.2f} '.format(round(fr.rscs(2)*table.tquantity,0)))
    def slab(self):
        d = slab
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['rscs_slab'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.rscs(1)),'\u20B9{:.2f} '.format(round(fr.rscs(1)*table.tquantity,0)))

    def tor_8(self):
        d = tor8
        table = pd.DataFrame(d, index=range(1, len(d) + 1), columns=['description', 'no', 'length'])
        table['quantity'] = table['no'] * table['length'].round(2)
        tquantity = (table['quantity'].sum())
        tweight = round(tquantity * 0.395, 2)
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)
        print('\n', it.items['hysd'], '\n', table, '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}m'.format(tquantity), '@ {:.3f} kg/m = '.format(0.395), '{:.2f}kg '.format(tweight),
              '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}qtl'.format(tweight / 100), '@ {:.2f} kg/m = '.format(fr.reinforcement()),
              '\u20B9{:.2f} '.format(round(tweight * fr.reinforcement() / 100)))

    def tor_10(self):
        d = tor10
        table = pd.DataFrame(d, index=range(1, len(d) + 1), columns=['description', 'no', 'length'])
        table['quantity'] = table['no'] * table['length'].round(2)
        tquantity = (table['quantity'].sum())
        tweight = round(tquantity * 0.62, 2)
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)
        print('\n', it.items['hysd'], '\n', table, '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}m'.format(tquantity), '@ {:.3f} kg/m = '.format(0.62), '{:.2f}kg '.format(tweight),
              '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}qtl'.format(tweight / 100), '@ {:.2f} kg/m = '.format(fr.reinforcement()),
              '\u20B9{:.2f} '.format(round(tweight * fr.reinforcement() / 100)))

    def tor_12(self):
        d = tor12
        table = pd.DataFrame(d, index=range(1, len(d) + 1), columns=['description', 'no', 'length'])
        table['quantity'] = table['no'] * table['length'].round(2)
        tquantity = (table['quantity'].sum())
        tweight = round(tquantity * 0.89, 2)
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)
        print('\n', it.items['hysd'], '\n', table, '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}m'.format(tquantity), '@ {:.3f} kg/m = '.format(0.89), '{:.2f}kg '.format(tweight),
              '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}qtl'.format(tweight / 100), '@ {:.2f} kg/m = '.format(fr.reinforcement()),
              '\u20B9{:.2f} '.format(round(tweight * fr.reinforcement() / 100)))

    def tor_16(self):
        d = tor16
        table = pd.DataFrame(d, index=range(1, len(d) + 1), columns=['description', 'no', 'length'])
        table['quantity'] = table['no'] * table['length'].round(2)
        tquantity = (table['quantity'].sum())
        tweight = round(tquantity * 1.58, 2)
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)
        print('\n', it.items['hysd'], '\n', table, '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}m'.format(tquantity), '@ {:.3f} kg/m = '.format(1.58), '{:.2f}kg '.format(tweight),
              '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}qtl'.format(tweight / 100), '@ {:.2f} kg/m = '.format(fr.reinforcement()),
              '\u20B9{:.2f} '.format(round(tweight * fr.reinforcement() / 100)))
    def sandfilling(self):
        d = sandfill
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['sand_filling'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.sandfilling()),'\u20B9{:.2f} '.format(round(fr.sandfilling()*table.tquantity,0)))
    def plaster_3(self):
        d = plaster20
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['20cp(1:4)'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.plaster(4)),'\u20B9{:.2f} '.format(round(fr.plaster(4)*table.tquantity,0)))
    def plaster_3(self):
        d = plaster20
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['20cp(1:4)'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.plaster(4)),'\u20B9{:.2f} '.format(round(fr.plaster(4)*table.tquantity,0)))
    def concrete124(self):
        d = cc124
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['CC(1:2:4)'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.concrete(3
                                                                                           )),'\u20B9{:.2f} '.format(round(fr.concrete(3)*table.tquantity,0)))
    def plaster_1(self):
        d = plaster12
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['12cp(1:6)'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.plaster(1)),'\u20B9{:.2f} '.format(round(fr.plaster(1)*table.tquantity,0)))

if __name__ == "__main__":
    root = Tk()
    app = Crematory(root)
    root.mainloop()
    print("Labour charges for cutting and binding of HYSD bars\n\t\t12.0quintal @ \u20B94549.90/q = \u20B954,599.00")

    print("Cess for welfare opf labourers = \u20B92,500.00")
    print('Work contingency = \u20B91,250.00')
    print('Display board and photograph = \u20B91,500.00')
    print('-'*80)
    print('Estimated cost limited to \u20B92,50,000.00')
    fr.signature(250000,'Two lakh fifty thousands only',3,'Mahada G.P.')
