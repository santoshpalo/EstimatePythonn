import ClassLibrary as cl
import items as it
import FunctionLibraryR as fr
import textwrap
def a (x):
    return round(x*0.3048,2)








if __name__ == "__main__":
    print('Name of the work:- Construction of Community Mandap at Harijan Basti, KuhiBahal')
    print('Estimated Cost:-\u20B94,00,000.00\tHead of Account:-BKBK(2015-16)')
    print('-'*80)
    tcl = cl.Quantity([['long walls',2,a(25.75-.8333)],
                       ['short walls',2,a(20-.833)]])
    tcl.tcl()
    print(it.items['efhs'])
    fndn = cl.Quantity([['column foundations',3,1.5,1.5,1.5],
                        ])
    fndn.rate = 103.2
    fndn.volume()
    print(it.items['CC(1:3:6)'])
    concrete = cl.Quantity([['foundation of columns',3,1.5,1.5,0.12],
                            ])
    concrete.rate=3755.55
    concrete.volume()
    print(it.items['m20'])
    rcc = cl.Quantity([['alround walls bend at slab top',1,26.86+1.65,0.25,0.15],
                       ['20 steps',20*0.5,1.4,0.3,0.15],
                       ['two landings',2,1.4,1.2,0.15],
                       ['waist slab',2,3.2,1.4,0.12],
                       ['beams',2,3.4,0.25,0.2],
                       ['beam on landing',2,0.9,0.25,0.2],
                       ['beam on middle landing',1,1.1,0.25,0.2],
                       ['column footings',3,1.2,1.2,0.35],
                       ['column 1',1,0.25,0.25,1.2],
                       ['column 2',1,0.25,0.25,3.0],
                       ['column 3',1,0.25,0.25,4.5],
                       ['lintel bend',1,26.86,0.25,0.15],
                       ['columns',8,0.25,0.25,3.0],
                       ['middle column',1,0.38,0.25,3.15],
                       ['chajjas',5,1.2,0.5,0.062],
                       ['chajjas on door',1,1.8,0.6,0.06],
                       ['roof bend ',1,26.86,0.25,0.15],
                       ['beams',1,a(25.75-0.833),0.25,0.15],
                       ['slab',1,a(25.75+1),a(21),0.1]

                       ])
    rcc.rate = 4374.13
    rcc.volume()
    print(it.items['bmssfa'])
    brick = cl.Quantity([['alround walls',1,26.86,0.25,3.0],
                         ['deduct door openings',-1,1.2,0.25,2.10],
                         ['deduct window openings',-5,0.9,0.25,1.2],
                         ])
    brick.rate = 3230.3
    brick.volume()
    print(it.items['rscs_plinth'])
    plinth = cl.Quantity([['column footings',3*4,1.2,0.35],
                          ['above slab bend',2,26.86+1.65,0.15],
                          ])
    plinth.rate = 83.43
    plinth.vArea()
    print(it.items['rscs_lintel'])
    lintel = cl.Quantity([['alround lintel bend',2,26.86,0.15],
                          ['bottom of lintels Door',1,1.08,0.25],
                          ['bottom of lintels windows',5,0.9,0.25]])
    lintel.rate= 479.78
    lintel.vArea()
    print(it.items['rscs_slab'])
    slab = cl.Quantity([['slab',1,a(25.75+1),a(21)],
                        ['chajjas D',1,1.8,0.6],
                        ['chajjas windows',5,1.2,0.5],
                        ['roof bend',1,26.86,.05],
                        ['deduct beam',-1,a(25.75-1.66),0.25],
                        ['landing',2,1.2-0.25,1.2],
                        ['long loft',1,a(25.75-1.66),0.6]
                        ])

    slab.rate=313.92
    slab.hArea()
    print(it.items['rscs_beam'])
    beam=cl.Quantity([['staircase beams',3,1.2,0.75],
                      ['roof beam',1,a(25.75-0.833),0.75]])
    beam.rate = 479.78
    beam.vArea()
    print(it.items['rscs_stair'])
    stair = cl.Quantity([['waist slab',2,3.4,1.2+0.12*2],
                         ['step sides',20,0.3,0.15],
                         ['landing sides',4,1.2,0.15]])
    stair.rate = 381.53
    stair.hArea()
    print(it.items['hysd'])
    print('\t\t\t\t14.38quintal @ \u20B94549.9/cum = \u20B972,977.00 ')
    print(it.items['20cp(1:4)'])
    grading=cl.Quantity([['roof slab top',1,a(26.75),a(21)]])
    grading.rate=146.19
    grading.hArea()
    print(it.items['12cp(1:6)'])
    plaster12 = cl.Quantity([['external sides of walls',1,26.86+1,3.3],
                             ['deduct Door',-0.5,1.2,2.1],
                             ['deduct windows',-5.0/2,0.9,1.2]
                             ])
    plaster12.rate=88.73
    plaster12.vArea()
    print(it.items['16cp(1:6)'])
    plaster16=cl.Quantity([['inside of walls',1,26.86-1,3.3],
                           ['deduct Door', -0.5, 1.2, 2.1],
                           ['deduct windows', -5.0 / 2, 0.9, 1.2]
                           ])
    plaster16.rate=128.17
    plaster16.vArea()
    print(it.items['6cp(1:4)rcc'])
    plaster6 = cl.Quantity([['inside column',2,0.25+.38,3.15],
                            ['chajjas D',1,1.8,0.65],
                            ['chajjas W',5,1.2,0.55],
                            ['beam',1,a(25.75-1.66),0.75],
                            ['waist slab sides',4,3.5,0.15],
                            ['landing sides',4,1.2,0.15],
                            ['step sides',20,0.3,0.15],
                            ['stair columns',2*4,0.25,3.3+0.45+1.8]]

                           )
    plaster6.rate=80.88
    plaster6.vArea()
    print(it.items['vitrified'])
    floor = cl.Quantity([['floor',1,a(25.75-1.66),a(20-1.66)]])
    floor.rate=fr.vitrifiedtile1()
    floor.hArea()
    print(it.items['floor tile'])
    floortile=cl.Quantity([['steps',25,1.2,0.25],
                           ['landings',2,1.2,1.2]])
    floortile.rate=fr.Tile(1)
    floortile.hArea()
    print(it.items['wall tile'])
    walltile = cl.Quantity([['inside the hall',1,26.86,0.9],
                            ['treads of steps',25,1.2,0.15]])
    walltile.rate = fr.Tile(2)
    walltile.vArea()
    print(it.items['paint'])
    painting = cl.Quantity([['Doors',2.25,1.2,2.1],
                            ['windows',5*2.75,0.9,1.2]])
    painting.rate = fr.painting()
    painting.vArea()
    print(it.items['wpcp'])
    waterproof = cl.Quantity([['plaster 12mm thick',88.11],
                              ['plaster 16mm thick',81.51],
                              ['plaster6mm thick',29.43],
                              ['ceiling area',41.03]])
    waterproof.rate=fr.waterproofpaint()
    waterproof.quantity(2)
    print (textwrap.fill('''Supplying, fitting and fixing of stainless steel of 304 grade in hand railing using 50mm dia of 2mm thick circular pipe with Balustrade of size 32mm x 32mm x 2mm in 3 rows in stair case as per approved design and specification, buffing, polishing, etc. with cost, conveyance taxes of all materials, labours T & P etc. required for the complete in all respect.'''))
    print('\n\t\t\t20m @ \u20B9 279.38 /m = \u20B9 5588.00')
    material = cl.Quantity([['cost of chequered tile',14.88,'sqm',217],
                            ['Cost of ceramic glazed tile',24.17,'sqm',387],
                            ['Cost of enamel paint',2.68,'ltr.',193],
                            ['Cost of primer',1.17,'ltr.',129],
                            ['Cost of water proofing cement paint',60.02,'kg',35],
                            ['Cost of M.S. Doors and windows',3.5,'qtl.',6300]])
    material.cost_material()
    extracost = cl.Quantity([['brick masonry in first floor',18.22,'cum',993.86,15],
                             ['Centering of slab',59.38,'sqm',313.92,20],
                             ['centering of slab bend',12.18,'sqm',83.43,20],
                             ['centering of columns',5.69,'sqm',479.78,20],
                             ['centering of lintel',9.45,'sqm',199.44,20],
                             ['R.C. works',10.66,'cum',323.41,15],
                            ['Reinforcement works',10,'qtl',10,5],
                             ['external plaster 12mm',88.11,'sqm',61.11,5],
                             ['external plaster 20mm',52.16,'sqm',91.8,5],
                             ['interna plaster',81.51,'sqm',95,3],
                             ['Flooring works',41.03,'sqm',105.19,5],
                             ['dado tiling',28.67,'sqm',158.28,5],
                             ['Door and window painting',19.95,'sqm',40.88,4],
                             ['water proofing cement paint',240.8,'sqm',13.45,4]
                             ])
    extracost.firstFloorExtra()
    print("Provisional cost for electrification \u20B9 26,500.00")
    print('Provision for Labour registration cess = \u20B9 100.00')
    print('Cess for welfare of labourers = \u20B9 4,000.00')
    print('Display board and photograph = \u20B9 2000.00')
    print('Work contingency = \u20B9 2,000.00')
    print('='*80)
    fr.signature(400000,'Four lakh only',2,'')






