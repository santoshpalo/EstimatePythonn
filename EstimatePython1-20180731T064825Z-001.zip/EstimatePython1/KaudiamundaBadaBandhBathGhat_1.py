import items as it
import ClassLibrary as cl 
import FunctionLibrary as fl
import statistics as st
import numpy as np
a=np.array([0.15,.2,.1,.13,.13,.13,.13,.15,.14,.15,.16,.16,.14,.15,.16,.15,.14] ) # height of risers of steps

a1= a+.1 #height of cc(1:3:6) and C.C.(1:2:4) in steps accountable for centering height



b=np.array([.3,0.5,0.55,0.75,.9,.9,.9,0.93,1.08,1.18,1.3,1.4,1.23,1.35,0.75,.4,.63])
b1 =b+.22 # height of walls excluding step and including foundation

b2= b-.23 #height of sand filling

b3=b+0.45 #height of wall external for centering
c=np.array([18.4166,18.33,18.4166,18.25,18.25,18.25,18.0833,18,18,18,18,18,18.166,18.0833,18.166,18.0833,18.0833]) #length of steps in foot
c1 = np.round(c*.3048,2)  #length of steps in metre
c2 = c1-0.9  # sand filling length under steps
d= np.array([8,2,2.083,2,2,2,10,2,2,2,2,2,2,2,2.083,2.083,5] )#width of steps in feet
d1=np.round(d*.3048,2)  #nett width of steps in metre
d2 = d1+.15  #gross width of steps in metre






if __name__ == "__main__":
    print(it.items['ewss'])
    slush = cl.Quantity([['removing slush and preparing bed', 1, 12.0, 7.0, 1.5]])
    slush.rate = 88
    slush.volume()
    print(it.items['efhs'])
    foundationtrench=cl.Quantity([['both side cut-off walls',2,15.81-.45+.75,0.75,0.45],
                                  ['top and bottom cut-off walls',2,4.88,0.75,0.45],
                                  ['middle cut-off walls',1,4.88,0.75,0.45]])
    foundationtrench.rate=103.2
    foundationtrench.volume()
    print(it.items['CC(1:3:6)'])
    pcc=cl.Quantity([['1st step',2,d1[0],0.45,b1[0]],
                      ['2nd step',2,d1[1],0.45,b1[1]],
                      ['3rd step',2,d1[2],0.45,b1[2]],
                      ['4th step',2,d1[3],0.45,b1[3]],
                      ['5th step',2,d1[4],0.45,b1[4]],
                      ['6th step',2,d1[5],0.45,b1[5]],
                    ['7th step',2,d1[6],0.45,b1[6]],
                    ['8th step',2,d1[7],0.45,b1[7]],
                    ['9th step',2,d1[8],0.45,b1[8]],
                    ['10th step',2,d1[9],0.45,b1[9]],
                    ['11th step',2,d1[10],0.45,b1[10]],
                    ['12th step',2,d1[11],0.45,b1[12]],
                    ['13th step',2,d1[12],0.45,b1[12]],
                    ['14th step',2,d1[13],0.45,b1[13]],
                    ['15th step',2,d1[14],0.45,b1[14]],
                    ['16th step',2,d1[15],0.45,b1[15]],
                    ['17th step',2,d1[16],0.45,b1[16]],
                    ['1st step',1,c1[0],d2[0],a[0]],
                      ['2nd step',1,c1[1],d2[1],a[1]],
                      ['3rd step',1,c1[2],d2[2],a[2]],
                      ['4th step',1,c1[3],d2[3],a[3]],
                      ['5th step',1,c1[4],d2[4],a[4]],
                      ['6th step',1,c1[5],d2[5],a[5]],
                    ['7th step',1,c1[6],d2[6],a[6]],
                    ['8th step',1,c1[7],d2[7],a[7]],
                    ['9th step',1,c1[8],d2[8],a[8]],
                    ['10th step',1,c1[9],d2[9],a[9]],
                    ['11th step',1,c1[10],d2[10],a[10]],
                    ['12th step',1,c1[11],d2[11],a[12]],
                    ['13th step',1,c1[12],d2[12],a[12]],
                    ['14th step',1,c1[13],d2[13],a[13]],
                    ['15th step',1,c1[14],d2[14],a[14]],
                    ['16th step',1,c1[15],d2[15],a[15]],
                    ['17th step',1,c1[16],d2[16],a[16]],
                    ['bottom cut-off',1,4.88,0.45,0.3],
                    ['top cut-off',1,4.88,0.45,0.63+.3-.22],
                    ['middle cut-off',1,4.88,0.45,1.53-.23]])
    pcc.rate=3700
    pcc.volume()
    print(it.items['CC(1:2:4)'])
    pcchips=cl.Quantity([['1st step',1,c1[0],d1[0],0.1],
                      ['2nd1 step',1,c1[1],d1[1],0.1],
                      ['3rd1 step',1,c1[2],d1[2],0.1],
                      ['4th step',1,c1[3],d1[3],0.1],
                      ['5th step',1,c1[4],d1[4],0.1],
                      ['6th step',1,c1[5],d1[5],0.1],
                    ['7th step',1,c1[6],d1[6],0.1],
                    ['8th step',1,c1[7],d1[7],0.1],
                    ['9th step',1,c1[8],d1[8],0.1],
                    ['10th step',1,c1[9],d1[9],0.1],
                    ['11th step',1,c1[10],d1[10],0.1],
                    ['12th step',1,c1[11],d1[11],0.1],
                    ['13th step',1,c1[12],d1[12],0.1],
                    ['14th step',1,c1[13],d1[13],0.1],
                    ['15th step',1,c1[14],d1[14],0.1],
                    ['16th step',1,c1[15],d1[15],0.1],
                    ['17th step',1,c1[16],d1[16],0.1]])
    pcchips.rate=4800
    pcchips.volume()
    print(it.items['sand_filling'])
    sandfill=cl.Quantity([['1st step',1,c2[0],d1[0],b2[0]],
                      ['2nd step',1,c2[1],d1[1],b2[1]],
                      ['3rd step',1,c2[2],d1[2],b2[2]],
                      ['4th step',1,c2[3],d1[3],b2[3]],
                      ['5th step',1,c2[4],d1[4],b2[4]],
                      ['6th step',1,c2[5],d1[5],b2[5]],
                    ['7th step',1,c2[6],d1[6],b2[6]],
                    ['8th step',1,c2[7],d1[7],b2[7]],
                    ['9th step',1,c2[8],d1[8],b2[8]],
                    ['10th step',1,c2[9],d1[9],b2[9]],
                    ['11th step',1,c2[10],d1[10],b2[10]],
                    ['12th step',1,c2[11],d1[11],b2[12]],
                    ['13th step',1,c2[12],d1[12],b2[12]],
                    ['14th step',1,c2[13],d1[13],b2[13]],
                    ['15th step',1,c2[14],d1[14],b2[14]],
                    ['16th step',1,c2[15],d1[15],b2[15]],
                    ['17th step',1,c2[16],d1[16],b2[16]]])
    sandfill.rate=313
    sandfill.volume()
    print(it.items['rscs_walls'])
    wall=cl.Quantity([['1st step',2,d1[0],b2[0]],
                      ['2nd step',2,d1[1],b2[1]],
                      ['3rd step',2,d1[2],b2[2]],
                      ['4th step',2,d1[3],b2[3]],
                      ['5th step',2,d1[4],b2[4]],
                      ['6th step',2,d1[5],b2[5]],
                    ['7th step',2,d1[6],b2[6]],
                    ['8th step',2,d1[7],b2[7]],
                    ['9th step',2,d1[8],b2[8]],
                    ['10th step',2,d1[9],b2[9]],
                    ['11th step',2,d1[10],b2[10]],
                    ['12th step',2,d1[11],b2[12]],
                    ['13th step',2,d1[12],b2[12]],
                    ['14th step',2,d1[13],b2[13]],
                    ['15th step',2,d1[14],b2[14]],
                    ['16th step',2,d1[15],b2[15]],
                    ['17th step',2,d1[16],b2[16]],
                      ['1st step', 2, d1[0], b2[0]],
                      ['2nd step', 2, d1[1], b3[1]],
                      ['3rd step', 2, d1[2], b3[2]],
                      ['4th step', 2, d1[3], b3[3]],
                      ['5th step', 2, d1[4], b3[4]],
                      ['6th step', 2, d1[5], b3[5]],
                      ['7th step', 2, d1[6], b3[6]],
                      ['8th step', 2, d1[7], b3[7]],
                      ['9th step', 2, d1[8], b3[8]],
                      ['10th step', 2, d1[9], b3[9]],
                      ['11th step', 2, d1[10], b3[10]],
                      ['12th step', 2, d1[11], b3[12]],
                      ['13th step', 2, d1[12], b3[12]],
                      ['14th step', 2, d1[13], b3[13]],
                      ['15th step', 2, d1[14], b3[14]],
                      ['16th step', 2, d1[15], b3[15]],
                      ['17th step', 2, d1[16], b3[16]]
                       ])
    wall.rate=387
    wall.vArea()
    print(it.items['rscs_plinth'])
    risers=cl.Quantity([['1st step',1,c1[0],a1[0]],
                      ['2nd step',1,c1[1],a1[1]],
                      ['3rd step',1,c1[2],a1[2]],
                      ['4th step',1,c1[3],a1[3]],
                      ['5th step',1,c1[4],a1[4]],
                      ['6th step',1,c1[5],a1[5]],
                    ['7th step',1,c1[6],a1[6]],
                    ['8th step',1,c1[7],a1[7]],
                    ['9th step',1,c1[8],a1[8]],
                    ['10th step',1,c1[9],a1[9]],
                    ['11th step',1,c1[10],a1[10]],
                    ['12th step',1,c1[11],a1[11]],
                    ['13th step',1,c1[12],a1[12]],
                    ['14th step',1,c1[13],a1[13]],
                    ['15th step',1,c1[14],a1[14]],
                    ['16th step',1,c1[15],a1[15]],
                    ['17th step',1,c1[16],a1[16]],
                        ['1st step', 1, c1[0], a[0]],
                        ['2nd step', 1, c1[1], a[1]],
                        ['3rd step', 1, c1[2], a[2]],
                        ['4th step', 1, c1[3], a[3]],
                        ['5th step', 1, c1[4], a[4]],
                        ['6th step', 1, c1[5], a[5]],
                        ['7th step', 1, c1[6], a[6]],
                        ['8th step', 1, c1[7], a[7]],
                        ['9th step', 1, c1[8], a[8]],
                        ['10th step', 1, c1[9], a[9]],
                        ['11th step', 1, c1[10], a[10]],
                        ['12th step', 1, c1[11], a[11]],
                        ['13th step', 1, c1[12], a[12]],
                        ['14th step', 1, c1[13], a[13]],
                        ['15th step', 1, c1[14], a[14]],
                        ['16th step', 1, c1[15], a[15]],
                        ['17th step', 1, c1[16], a[16]]
                        ])
    risers.rate = 82.08
    risers.vArea()
    print(it.items['12cp(1:6)'])
    plaster12 = cl.Quantity([['1st step', 1, c1[0], a[0]],
                             ['2nd step', 1, c1[1], a[1]],
                             ['3rd step', 1, c1[2], a[2]],
                             ['4th step', 1, c1[3], a[3]],
                             ['5th step', 1, c1[4], a[4]],
                             ['6th step', 1, c1[5], a[5]],
                             ['7th step', 1, c1[6], a[6]],
                             ['8th step', 1, c1[7], a[7]],
                             ['9th step', 1, c1[8], a[8]],
                             ['10th step', 1, c1[9], a[9]],
                             ['11th step', 1, c1[10], a[10]],
                             ['12th step', 1, c1[11], a[11]],
                             ['13th step', 1, c1[12], a[12]],
                             ['14th step', 1, c1[13], a[13]],
                             ['15th step', 1, c1[14], a[14]],
                             ['16th step', 1, c1[15], a[15]],
                             ['17th step', 1, c1[16], a[16]]])
    plaster12.rate = 107.52
    plaster12.vArea()

