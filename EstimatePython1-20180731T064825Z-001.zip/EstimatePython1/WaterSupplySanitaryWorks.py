import pandas as pd
import LeadStatement1 as ls
import WaterSupplySanitaryItems as ws
import FunctionLibrary as fl
us = 213.5
ss = 233.5
s = 253.5
hs = 273.5

def indianTypeWCPan():
    d1 = {'quantity': [0.5, 0.5,1],
           'rate': [us,s,600
                    ],
           'amount': [0]

           }
    index1 = ['unskilled labour', 'mason II','Orisaa pattern squatting pan']
    columns = ['quantity', 'rate', 'amount']
    table1 = pd.DataFrame(d1, index=index1, columns=columns)
    table1['amount'] = table1.quantity * table1.rate
    table1['quantity'] = table1['quantity'].map('{:,.2f}no.'.format)

    d2 = {'quantity': [0.206],
           'rate': [ls.z['total cost'][4]],
           'amount': [0]

           }
    index2 = ['cement']
    columns = ['quantity', 'rate', 'amount']
    table2 = pd.DataFrame(d2, index=index2, columns=columns)
    table2['amount'] = table2.quantity * table2.rate
    table2['quantity'] = table2['quantity'].map('{:,.4f}qtl'.format)

    d3 = {'quantity': [0.115, 0.058],
           'rate': [ls.z['total cost'][11], ls.z['total cost'][2]],
           'amount': [0]

           }

    index3 = ['40mm h.g. metal', 'sand']
    columns = ['quantity', 'rate', 'amount']
    table3 = pd.DataFrame(d3, index=index3, columns=columns)

    table3['amount'] = table3.quantity * table3.rate
    table3['quantity'] = table3['quantity'].map('{:,.2f}cum'.format)

    table6 = table1.append(table2).append(table3)
    Tamount6 = round(table6.amount.sum(), 2)
    table6['amount'] = table6['amount'].map('\u20B9{:,.2f}'.format)
    table6['rate'] = table6['rate'].map('\u20B9{:,.2f}'.format)
    print(ws.items['Indian W.C. Pan'],'\n',table6)
    print('Total cost =\t\t\t\t', (u"\u20B9"), Tamount6)

def P_or_S_Trap():
    d1 = {'quantity': [1],
           'rate': [263],
           'amount': [0]

           }
    index1 = ['100mm dia SCI P trap']
    columns = ['quantity', 'rate', 'amount']
    table1 = pd.DataFrame(d1, index=index1, columns=columns)
    table1['amount'] = table1.quantity * table1.rate
    table1['quantity'] = table1['quantity'].map('{:,.2f}no.'.format)

    d2 = {'quantity': [1],
           'rate': [28.34],
           'amount': [0]

           }
    index2 = ['Rate same as per item no 3.2.2']
    columns = ['quantity', 'rate', 'amount']
    table2 = pd.DataFrame(d2, index=index2, columns=columns)
    table2['amount'] = table2.quantity * table2.rate
    table2['quantity'] = table2['quantity'].map('{:,.0f}L.S.'.format)



    table6 = table1.append(table2)
    Tamount6 = round(table6.amount.sum(), 2)
    table6['amount'] = table6['amount'].map('\u20B9{:,.2f}'.format)
    table6['rate'] = table6['rate'].map('\u20B9{:,.2f}'.format)
    print(ws.items['P or S trap'],'\n',table6)
    print('Total cost =\t\t\t\t', (u"\u20B9"), Tamount6)

def pvcPipes(x):

    d1 = {'quantity': [1.67/10,1.17/10],
           'rate': [us,s],
           'amount': [0]
           }
    index1 = ['unskilled labour','mason II']
    columns = ['quantity', 'rate', 'amount']
    table1 = pd.DataFrame(d1, index=index1, columns=columns)
    table1['amount'] = table1.quantity * table1.rate
    table1['quantity'] = table1['quantity'].map('{:,.2f}no.'.format)
    if x == 1:
        d2 = {'quantity': [1],
           'rate': [50
                    ],
           'amount': [0]
           }
    else:
        d2 = {'quantity': [1],
              'rate': [100],
              'amount': [0]
              }

    index2 = ['50mm pvc schedule-80 pipes']
    columns = ['quantity', 'rate', 'amount']
    table2 = pd.DataFrame(d2, index=index2, columns=columns)
    table2['amount'] = table2.quantity * table2.rate
    # table2['quantity'] = table2['quantity'].map('{:,.0f}m'.format)
    d3 = {'quantity': [0.15,0.02],
          'rate': [169.24,169.24*1.15],
          'amount': [0]
          }
    index3 = ['Add for fittings and wastages 15%','Add for wooden plug, clamps,cement etc 2%']
    columns = ['quantity', 'rate', 'amount']
    table3 = pd.DataFrame(d3, index=index3, columns=columns)
    table3['amount'] = table3.quantity * table3.rate
    table3['quantity'] = table3['quantity'].map('{:,.2f}'.format)



    table6 = table1.append(table2).append(table3)
    Tamount6 = round(table6.amount.sum(), 2)
    # table6['amount'] = table6['amount'].map('\u20B9{:,.2f}'.format)
    # table6['rate'] = table6['rate'].map('\u20B9{:,.2f}'.format)
    print(ws.items['fixing pvc pipes'],'\n',table6)
    print('Total cost =\t\t\t\t', (u"\u20B9"), Tamount6)
def ladyUrinal():

    d1 = {'quantity': [1,1],
           'rate': [us,s],
           'amount': [0]
           }
    index1 = ['unskilled labour','mason II']
    columns = ['quantity', 'rate', 'amount']
    table1 = pd.DataFrame(d1, index=index1, columns=columns)
    table1['amount'] = table1.quantity * table1.rate
    table1['quantity'] = table1['quantity'].map('{:,.2f}no.'.format)

    d2 = {'quantity': [1],
       'rate': [500],
       'amount': [0]
       }


    index2 = ['vitreous china squatting plate urinal']
    columns = ['quantity', 'rate', 'amount']
    table2 = pd.DataFrame(d2, index=index2, columns=columns)
    table2['amount'] = table2.quantity * table2.rate
    # table2['quantity'] = table2['quantity'].map('{:,.0f}m'.format)
    d3 = {'quantity': [1,1],
          'rate': [16.08,19.95],
          'amount': [0]
          }
    index3 = ['cement , sand and grit','Carriage of materials']
    columns = ['quantity', 'rate', 'amount']
    table3 = pd.DataFrame(d3, index=index3, columns=columns)
    table3['amount'] = table3.quantity * table3.rate
    table3['quantity'] = table3['quantity'].map('{:,.2f}'.format)



    table6 = table1.append(table2).append(table3)
    Tamount6 = round(table6.amount.sum(), 2)
    # table6['amount'] = table6['amount'].map('\u20B9{:,.2f}'.format)
    # table6['rate'] = table6['rate'].map('\u20B9{:,.2f}'.format)
    print(ws.items['fixing pvc pipes'],'\n',table6)
    print('Total cost =\t\t\t\t', (u"\u20B9"), Tamount6)



indianTypeWCPan()
P_or_S_Trap()
pvcPipes(0)
pvcPipes(1)
ladyUrinal()
fl.concrete(1)
fl.Tile(1)
fl.Tile(2)
fl.signature(1,'',0,'')