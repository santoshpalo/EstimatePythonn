import items as it
import ClassLibrary as cl
import FunctionLibraryR as fr
import math
import textwrap











if __name__ == "__main__":
    print('Work done estimate for toilets and Final Bill of the Building construction\n')
    print('-'*80)
    print('Cummulative Amount paid 5th R/A Bill = \u20B94,69,800\n')

    # print(it.items['moorumcollection'])
    # moorum=cl.Quantity([['sub base spread',1,10,3.0,0.1]])
    # moorum.rate =70.67
    # moorum.volume()
    print(it.items['efhs'],'\n')
    foundation = cl.Quantity([['soak pit trench',math.pi/4,1.2,1.2,1.5]])
    foundation.rate = 103.2
    foundation.volume()
    print('\n',it.items['CC(1:4:8)'])
    concrete = cl.Quantity([['soak pit trench',math.pi/4,1.2,1.2,0.1]])
    concrete.rate = fr.concrete(1)
    concrete.volume()
    print('\n','Supplying and fixing of R.C.C.rings and coverplate\n')
    print('Cost of R.C.C. rings = 6nos @ \u20B9300.00 = \u20B9 1800.00')
    print('Cost of R.C.C. coverplate = 1 no @ \u20B9 350.00 = \u20B9 350.00')

    print('\n',it.items['floor tile'])
    floor = cl.Quantity([['toilet floors',2,2.25,(2.54-0.25-0.13)/2]])
    floor.rate = fr.Tile(1)
    floor.hArea()
    print('\n',it.items['wall tile'])
    wall = cl.Quantity([['longwalls',4,(2.54-0.25-0.13)/2,0.6],
                        ['short walls',4,2.25,0.6]])
    wall.rate =fr.Tile(2)
    wall.vArea()
    print(it.items['water closet I'])
    print('\t\t\t\t\t\t\t1 no @ \u20B9 1134.08'
          ' = \u20B9 1134.08')
    print('''Fixing ladies urinal pan pan duly embeddedin c.c.
(1:4:8) using hard granite metal 4cm nominal size all complete as per
specification 500mm x 440mm size white glazed vitreous china orissa pattern
squatting pan''')
    print('\t\t\t\t\t\t\t1 no @ \u20B9 1003.03'
          ' = \u20B9 1003.03')
    print(it.items['p or s trap'])
    print('\t\t\t\t\t\t\t1 no @ \u20B9 304.49 = \u20B9 304.49')
    print(it.items['pvc pipe'])
    print('\t\t\t\t\t\t\t6.10m no @ \u20B9 194.59 = \u20B9 1187.00')
    print(it.items['pvc soil pipe'])
    print('\t\t\t\t\t\t\t3.05 no @ \u20B9 144.59'
          ' = \u20B9 441.00')
    print(it.items['pvc moulded fitting'])
    print('\t\t\t\t\t\t\tsingle Tee 1 no @ \u20B9 80 = \u20B9 80')
    print('\t\t\t\t\t\t\tbend 2 no @ \u20B9 60.00 = \u20B9 120.00')
    print('\t\t\t\t\t\t\t100mm dia pvc cowl @ \u20B9 25.00 = \u20B9 25.00')
    print('\t\t\t\t\t\t\t100mm dia socket 2 nos @ \u20B9 50.00 = \u20B9 100.00')
    print('\t\t\t\t\t\t\t50mm dia bend 2 nos @ \u20B9 20.00 = \u20B9 40.00')
    print(it.items['ewhs'])
    print('Reference from page no 48-49/ TMB')
    print('\t\t\t 41.06cum @ \u20B9 86.00/cum = \u20B93,531.00 ')
    print(it.items['moorumcollection'])
    moorum=cl.Quantity([['sub base spread',1,20,10.0,0.1]])
    moorum.rate =70.67
    moorum.volume()
    print('Cost of moorum = 20.00cum @ \u20B9 235.69/cum = \u20B94,714.00 ')
    print('Cost of floor tiles = 4.86 sqm @ \u20B9 429.00 / sqm -\u20B92085.00 ')
    print('Cost of wall tiles = 7.54sqm @ \u20B9 387.00/sqm = \u20B92918.00 ')
    print('-'*80)
    print(textwrap.fill('Certified that the work has been constructed with an expenditure of \u20B9 4,94,571.00(Four lakh ninty four thousand five hundred seventy one only',80))
    print('\n\n\nJunior Engineer\t\tAssistant Engineer\t\tBlock Development Officer')
    print('Binka Block Office\tBinka Block Office\t\t\t\t\tBinka')





