
import pandas as pd
class electoral():
    def __init__(self,d,columnA = ['House No.','Name','Father/Husband','Age','Remarks'],columnB=['House No.','Name','Father/Husband','Remarks']):
        self.columnA = columnA
        self.columnB = columnB
        self.d = d
    def form(self):
        table = pd.DataFrame(self.d,columns = self.columnA, index = range(1,len(self.d)+1) )
        print('\n',table,'\n\n\n\n\t\t\t\tElecotral Registration Officer')
    def reject(self):
        table = pd.DataFrame(self.d,columns = self.columnB, index = range(1,len(self.d)+1) )
        print('\n',table,'\n\n\n\n\t\t\t\tElecotral Registration Officer')
    
                                 






if __name__ == "__main__":
    print('\t\t\t\tSee Rule No. 7 (4)')
    print('''\nElectoral Roll for the Ward No. 10 ofBaunsuni Grama Sasan.
Name of village:- Baunsuni,Binka  Police Station, Subarnapur District
Birmaharajpur Assembly Constituency covering the Gram________________.''')
    form1 = electoral([[22,'Sanjeeb Mallick','Pahilman Mallick','>18year','correct'],
                       [22,'Sushanta Mallick','Dwaru Mallick','>18year','correct'],
                       [19,'Tapisa Mallick','Prashant Mallick','>18year','correct'],
                       [5,'Prabhati Dehuri','Pitabasa Sa','>18year','correct'],
                       [11,'Mina Dishiri','Madhusudan Dishiri','>18year','correct'],
                       [2,'Sauda Barik','Ekadasia Barik','>18year','correct']])
    
    #form1.form()
    form2 = electoral([[77,'Bisikeshan Barik','Dhanurdhar Barik','>18years','correct'],
                       [104,'Alladini Khamari','Ugrasen Khamari','>18years','correct'],
                       ])
    #===========================================================================
    # form3 = electoral()
    #===========================================================================
    form4 = electoral([[81,'Agyan Sa','Hemaraj Sa','>18years','correct'],
                       [62,'Phulana Naek','Ajit Naek','>18years','correct'],
                       [79,'Sauda Sa','Bisi sa','>18years','correct']
                       ])
    form5 = electoral([[136,'Sasmita Jhankar','Prakash Chandra Jhankar','>18yeras','correct'],
                       [105,'Rajani Sa','Shubal Sa','>18years','correct'],
                       [119,"Tilotama Bhoi",'Tarani Bhoi','>18years','correct'],
                       [97,'Kalabati Bisi','Ram Bisi','>18years','correct'],
                       [97,'Padma Bisi','Ram Bisi','>18years','correct'],
                       [95,'Anjali Bisi','Bharat Bisi','>18years','correct'],
                       [94,'Sushil Bisi','Akrur Bisi','>18years','correct'],
                       [105,'Raebari Sa','Buduku Sa','>18years','correct'],
                       [106,'Urmila Sa','Shankar Sa','>18years','correct'],
                       [94,'Jayan Bisi','Akrur Bisi','>18years','correct'],
                       [119,'Mamata Bhoi','Parasar Bhoi','>18years','correct'],
                       [105,'Rajani Sa','Srikrishna Sa','>18years','correct'],
                       [95,'Ajit Bisi','Bharat Bisi','>18years','correct'],
                       [90,'Kasturi Mallick','Gopal Mallick','>18years','correct'],
                       [101,'Daya Sa','Kasta Sa','>18years','correct'],
                       [106,'Gurubari Sa','Gadi Gopal Sa','>18years','correct'],
                       [114,'Banita Bhue','Prahallad Bhue','>18years','correct'],
                       ])
    form6 = electoral([[148,'Sudam Bariha','Lalachi Bariha','>18years','correct'],
                        [146,'Budani Bariha','Binod Bariha','>18years','correct'],
                        [152,'Chuababu Bariha','Mahargi Bariha','>18years','correct'],
                        [151,'Ranjita Bariha','Saheb Bariha','>18years','correct'],
                        [154,'Banita Set','Jatak Set','>18years','correct'],
                        [146,'Udian Bariha','Dharam Singh','>18years','correct'],
                        [158,'Kaikei Set','Trilochan Set','>18years','correct'],
                        ])
    form7 = electoral([[207,'Gita Sa','Khiradhar Sa','>18years','correct'],
                       [221,'Prabhasini Mallick','Chapdhari Mallick','>18years','correct'],
                       [221,'Srimati Mallick','Chapdhari Mallick','>18years','correct'],
                       [221,'Sandhyarani Mallick','Chapdhari Mallick','>18years','correct'],
                       [207,'Khiradhar Sa','Saheb Sa','>18years','correct'],
                       [222,'Saraswati Sandh','Basu Sandh','>18years','correct'],
                       [222,'Raemati','Basu Sandh','>18years','correct'],
                       [180,'Sriya Adabar','Sambhu Adabar','>18years','correct'],
                       [207,'Padmini Sa','Kshirod Sa','>18years','correct'],
                       [185,'Kasturi Padhan','Areun Padhan','>18years','correct'],
                       [222,'Samari Sandh','Basu Sandh','>18years','correct'],
                       [213,'Meera Das','Chitrasen Das','>18years','correct'],
                       [209,'Biranchi Das','Baleshwar Das','>18years','correct'],
                       [209,'Subasini Das','Biranchi Das','>18years','correct']
                       ])
    form8 = electoral([[26,'Jharana Adarkulia','Sitaram Adarkulia','>18years','correct']]
                      )
    form9 =electoral([[64,'Mahaki Set','Aksha Set','>18years','correct'],
                      [64,'Sauki Set','Aksha Set','>18years','correct'],
                      [64,'Kailash Set','Aksha Set','>18years','correct'],
                      ])
    form10 = electoral([[115,'Lili Sandh','Ganesh Sandh','>18years','correct'],
                        ])
    #===========================================================================
    # 
    # form1.form()
    # form2.form()
    # form4.form()
    # form5.form()
    # form6.form()
    # form7.form()
    # form8.form()
    # form9.form()
    # form10.form()
    #===========================================================================
    reject3=electoral([[30,'Kamalesh Yadav','Raghuraj Yadav','Not available:rejected'],
                       [31,'Jitendar Singh','Mandip prasad Singh','Not available:rejected']])
    reject5 = electoral([['-','Manju Dandsena','Sanatan Dandsena','Not available:rejected'],
                         ['-','Gourishankar Sahu','Kshetrabasi Sahu','Not available:rejected'],
                         ['-','Dibyalochan Padhan','Bhagabatia Padhan','Not available:rejected'],
                         ['-','Narottam Kuanr','Bidesi Kuanr','Not available:rejected'],
                         ['-','Kamala Kuanr','Bidesi Kuanr','Not available:rejected'],
                         ['-','Jasobanti Kuanr','Nilambar Kuanr','Not available:rejected'],
                         ['-','Nilambar Kuanr','Bidesi Kuanr','Not available:rejected'],
                         ['-','Gayatri Kuanr','Muralidhar Kuanr','Not available:rejected'],
                         ['-','Purna chandra Padhan','Kapil Padhan','Not available:rejected'],
                         ['-','Surendra mohan Sahu','Ainthu Sahu','Not available:rejected'],
                         ['-','Parbati Sandh',' Sambhu Sandhu','Not available:rejected'],
                         ['-','Sambhu Sandh','Padman Sandh','Not available:rejected'],
                         ['-','Satyamohan Dalei','Ananta Dalei','Not available:rejected'],
                         ['-','Binodini Dalei','Satyamohan Dalei','Not available:rejected']
                         ])
    reject6 = electoral([['-','Soumitri Padhan','Jalandhar Padhan','Not available:rejected'],
                        ['-','Sachidananda Sethi','Paban Sethi','Not available:rejected'],
                        ['-','Gourang Charan Padhan','Kusha Padhan','Not available:rejected'],
                        ['-','Niladri Sethi','Bidesi Sethi','Not available:rejected'],
                        ['-','Basanti Kuanr','Bidesi Kuanr','Not available:rejected'],
                        ['-','Damodar Pande','Champe Pande','Not available:rejected'],
                        ['-','Harmohan Sethi','Sidheswar Sethi','Not available:rejected'],
                        ['-','Jhari Bhoi','Jogindra Bhoi','Not available:rejected'],
                        ['-','Bidesi Kuanr','Chandra Kuanr','Not available:rejected'],
                        ['-','Maheswar padhan','Birkishore Padhan','Not available:rejected'],
                         ['-','Sanatan Dandsena','Jaydev Dandsena','Not available:rejected'],
                         ['-','Jogindra Bhoi','Dutia Bhoi','Not available:rejected'],
                         ['-','Giridhari Hota','Hanuman Hota','Not available:rejected'],
                         ['-','Manorama Hota','Giridhari Hota','Not available:rejected'],
                         ['-','Pratap Sahu','Dasarath Sahu','Not available:rejected'],
                         ['-','Bisikesan Dehuri','Dinabandhu Dehuri','Not available:rejected'],
                         ['-','Gitanjali Dehuri','Bisikeshan Dehury','Not available:rejected']])
    reject10 = electoral([['-','Itishree Pandia','Sushant Pandia','Not available:rejected'],
                          ['-','Sushant Pandia','Bibhuti bhusan Pandia','Not available:rejected'],
                          ['-','Raju swain','Dhaneswar Swain','Not available:rejected'],
                          ['-','Bebina Swain','Raju Swain','Not available:rejected'],
                          ])
    reject10.reject()
    
        