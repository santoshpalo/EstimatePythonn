import ClassLibrary as cl 
import FunctionLibrary as fl
import items as it
h1= 3.6
import math as mt






if __name__ == "__main__":
    print(it.items['bmss'])
    brickwork = cl.Quantity([['green room walls',2,8.51,0.25,h1],
                             ['green room short walls',4,3.3,0.25,h1],
                             ['pendal wall',1,13.06-6.1-2*.38-2*.25,0.25,h1],
                             ['pendal short walls',2,3.65,0.25,h1],
                             ['door in green room',-2,0.9,0.25,1.98],
                             ['door in toilet',-2,0.75,0.25,1.98],
                             ['door in pendal',-2,1.08,0.25,1.98],
                             ['opening in the pendal',-1,6.1,0.25,2.9],
                             ['windows in green room',-2,1.08,0.25,1.2],
                             ['slant walls',4,8.59,0.25,h1],
                             ['deduct verandah openings',-6,2.85,0.25,2.5],
                             ['deduct main doors',-7,1.5,0.25,1.9],
                             ['elliptical wall ',1,11.84,0.25,h1],
                             ['verandah elliptical walls',1,17.73,0.25,h1],
                             ['front veranda openings',-1,17.73,0.25,2.5],
                             ['circular arc at penndal',1,7.87,0.25,0.45],
                             ['circular steps in hall',1,11.58,0.25,0.5],
                             ['circular steps in hall',1,8.15,0.25,0.15],
                             ['deduct volume of rcc lintel',-1,5.78,1,1]
                             ])
    brickwork.rate = 3153.5
    brickwork.diction = brickwork.volume()
    brickwork.x = 3
    brickwork.express()
    print(it.items['m20'])
    rccwork = cl.Quantity([['front column footing',1,1.2,1.2,0.3],
                           ['front column',mt.pi/4,0.38,0.38,2.5+.6+0.75],
                           ['green room walls',2,8.51+1,0.25,0.15],
                           ['green room short walls',4,3.3,0.25,0.15],
                           ['pendal wall',1,13.06-6.1,0.25,0.15],
                           ['pendal short walls',2,3.65,0.25,0.15],
                           
                           ['slant walls hall',2*3,3.46,0.25,0.2],
                           ['slant walls verandah',2,9.5,0.25,0.25],
                           
                           
                           ['elliptical wall ',1,11.84+1,0.25,0.2],
                           ['verandah elliptical walls',1,17.73+1.2,0.25,0.25],
                           ['green room window chajjas',2,1.38,0.45,.06],
                           ['pendal door chajja',mt.pi/4,1.62,1.62,0.06],
                           ['verandah chajjs',2,9.75,0.45,0.065],
                           ['verandah elliptical chajja',1,18.75-4.1,0.45,.06],
                           ['front quarter circular beams',2,6.64,0.25,0.25],
                           ['front slab',2/6*mt.pi,4.7,4.7,0.1],
                           ['front slab deduct',mt.sqrt(3)/4,4.7,4.7,0.1],
                           ['main slab back portion',1,9.93,7.54,0.12],
                           ['trapezoidal portion',1,14.17,9.83,0.12],
                           ['semi elliptical portion',3/4,9.83,4.95,0.12],
                           ['main beam 1',1,11.53,0.3,0.75],
                           ['main beam 2',1,11.15,0.3,0.75],
                           ['main beam 3',1,10.5,0.3,0.75],
                           ['verandah beams',6,1.5-.25,0.3,0.3],
                           ['pendal beam',1,6.76,0.25,0.45],
                           ['green room walls',2,8.51+1,0.25,0.2],
                           ['green room short walls',4,3.3,0.25,0.2],
                           ['pendal wall',1,13.06-6.1,0.25,0.2],
                           ['pendal short walls',2,3.65,0.25,0.2],
                           
                           ['slant walls hall',2*3,3.46,0.25,0.2],
                           ['slant walls verandah',2,9.5,0.25,0.2],
                           
                           
                           ['elliptical wall ',1,11.84+1,0.25,0.2],
                           ['verandah elliptical walls',1,17.73+1.2,0.25,0.2],
                           ['main columns',6,0.5,0.3,3.05],
                           ['verandah columns',6,0.3,0.3,3.8-.2-0.25],
                           ['front verandah columns',mt.pi,0.3,0.3,3.8-.25-.2],
                           ['hall eliptical wall columns',4,0.25,0.25,3.8-.2-.2],
                           ['pendal columns',2,0.38,0.25,3.8-.15-.2],
                           ['verandah columns 0.25 wide',2,0.25,0.25,3.8-.25-.2],
                           ['green room columns',8,0.25,0.25,3.8-.25-.2],
                           
                          
                           ])
    rccwork.rate = 4692.3
    rccwork.diction = rccwork.volume()
    rccwork.x = 3
    rccwork.express()
    reinforcement = cl.Quantity([['main beam1 bottom',4,11.53-.15+2*.3,2.47],
                                 ['main beam1 top',2,14.83-.15+2*0.3,1.58],
                                 ['main beam1 extra top',4,6,2.47],
                                 ['verandah ain beam1',2*2*3,1.5+.3+.25+.3,1.58],
                                 ['main beam2 bottom',4,11.53-.15+2*.3-0.53,2.47],
                                 ['main beam2 top',2,14.83-.15+2*0.3-0.53,1.58],
                                 ['main beam2 extra top',4,6-0.18,2.47],
                                 ['main beam3 bottom',4,11.53-.15+2*.3-0.53,2.47],
                                 ['main beam3 top',2,14.83-.15+2*0.3-1.37,1.58],
                                 ['main beam3 extra top',4,6-0.46,2.47],
                                 ['four legged stirrups',172,4*(0.75+.12-.1)+2*(0.3-.08)+3*.08,0.395],
                                 ['two legged stirrups',69,2*(0.75+.12-.1)+2*.22+.08,.395],
                                 ['small stirrups in verandah',6*35,1.2,0.395],
                                 ['pendal beam main bars',3,6.76-.08+2*.3,1.58],
                                 ['pendal beam top bar',2,6.76-.08,0.89],
                                 ['pendal beam stirrups',41,2*(0.45+.125-.08)+2*.17,0.395],
                                 ['R.B. green room long walls',2*4,9.45,.89],
                                 ['R.B. short walls greenrooms',2*4,3.68,0.89],
                                 ['side walls of green room and pendal',2*4,7.65,.89],
                                 ['pendal both side walls',2*4,3.4,0.89],
                                 ['verandah out side',4,38.25-.08,0.89],
                                 ['verandah inside wall',4,32.28,0.89],
                                 ['stirrups of R.B.',725,1.07,0.395],
                                 ['green room panels bottom 1',15,3.25+0.5+.15+.9,0.395],
                                 ['green room panels bottom 2',15,3.25+.2+.5+.15,0.395],
                                 ['green room panels top 1',14,3.5+.5+.15+0.43,0.395],
                                 ['green room panels top 2',14,3.5+.5+0.2,0.395],
                                 ['toilet botttom ',2*7,1.5+.5+2*3.5/4,0.395],
                                 ['toilet top',3,1.5+.5+.15+1.5/4,0.395],
                                 ['toilet top',3,1.5+.5+.15+.2,.395],
                                 ['toilet top',3,1.5+.5+3.65/4+.2,.395],
                                 ['toilet top',3,1.5+.5+.2+.38,.395],
                                 ['pendal main bottom',29,3.65+.5+0.81+.2,.395],
                                 ['pendal main bottom2',29,3.65+2.95/4+.5+.2,.395],
                                 ['pendal top',13,9.5+.3,0.395],
                                 ['green room and pendal distribution',6+8+10*2,9.5+.3,.395],
                                 ['green room and pendal distribution short',2*10,7.65,.395],
                                 ['green room extra top',15,0.9,.395],
                                 ['pendal sides extra top',13,.9+.25+.15,.395],
                                 ['hall panel 1 bottom',43,2.81+.3+.25+.2+3.65/4,.395],
                                 ['hall panel1 bottom2',43,2.81+.3+.3+.2+2.81/4,0.395],
                                 ['hall panel 2 bottom',45*2,2.81+.3+.3+.2+2.81/4,.395],
                                 ['hall panel3 bottom',48,2.81+.3+.3+.45+.2,.395],
                                 ['hall panel3 bottom2',48,2.81+.2+.3+.3+2.81/4,.395],
                                 ['hall panel1 top',12,13.35+.5+.2+1.5/4,.395],
                                 ['hall panel2 top',12,13.97+.5+.2+1.5/4,.395],
                                 ['hall panel3 top',12,14.57+.5+.2+1.5/4,.395],
                                 ['hall panel1 long distribution',16,13.35+.5,.395],
                                 ['hall panel2 long distribution',16,13.97+.5,.395],
                                 ['hall panel3 long distribution',16,14.57+.5,.395],
                                 ['hall panels sides distributions',40,9.75,.395],
                                 ['hall elliptical main bottom',48,1.4+.25+.3+.2+2.81/4,.395],
                                 ['hall elliptical  main bottom2',48,1.4+.2+.3+.25+1.5/4,.395],
                                 ['hall elliptical long',14,11.17/2+1.5/4,.395],
                                 ['hall elliptical long distribution',4,11.17,.395],
                                 ['hall elliptical long distribution2 ',4,12.8,.395],
                                 ['verandah elliptical bottom1',52,1.5+.5+.15+.45,.395],
                                 ['verandah elliptical bottom2',52,1.5+.5+.2+.15,.395],
                                 ['verandah elliptical',7,15.8+.2+2.8/4,.395],
                                 ['verandah elliptical distribution inner',4,12.85,.395],
                                 ['verandah elliptical distribution outer',4,18.75,0.395],
                                 ['verandah panels',32,1.5+.5+.15+.2,.395],
                                 ['verandah panels 2',32,1.5+.5+1.4,.395],
                                 ['verandah panels top',7*3,2.8+.5+.2+2.8/4,.395],
                                 ['verandah panels distributions',8,9.75,.395],
                                 ['verandah sides extra top',20,.6,.395]
                                 
                                 ])
    reinforcement.reinforcement()

    
    
    
    