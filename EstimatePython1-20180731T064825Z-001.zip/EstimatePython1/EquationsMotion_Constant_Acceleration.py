#! /usr/bin/python3
import math as mt
from tkinter import *
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
matplotlib.use("TkAgg")
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
fields=('Position_1','Position_2','TimeInterval','Velocity_1','Velocity_2','Acceleration' )
def final_velocity(entries):
    v=(float(entries['Velocity_1'].get())+(float(entries['TimeInterval'].get())*float(entries['Acceleration'].get())))
    print('v',v)
def average_velocity(entries):
    v_avg = (float(entries['Position_2'].get())-float(entries['Position_1'].get()))/(float(entries['TimeInterval'].get()))
    print('v_avg',v_avg)
def displacement_velocity(entries):
    x_x0= (float(entries['Velocity_1'].get())*float(entries['TimeInterval'].get()))+0.5*(float(entries['Acceleration'].get())*float(entries['TimeInterval'].get())**2)
    print('x_x0',x_x0)
def final_velocity_time(entries):
    v= mt.sqrt((float(entries['Velocity_1'].get())**2)+2*(float(entries['Acceleration'].get()))*(float(entries['Position_2'].get())-float(entries['Position_1'].get())))
    print('v',v)
def displacement_acceleration(entries):
    x_x0 = 0.5*(float(entries['Velocity_1'].get())+float(entries['Velocity_2'].get()))*float(entries['TimeInterval'].get())
    print('x_x0',x_x0)
def displacement_velocity_1(entries):
    x_x0=(float(entries['Velocity_2'].get())*float(entries['TimeInterval'].get()))-0.5*(float(entries['Acceleration'].get())*float(entries['TimeInterval'].get())**2)
    print('x_x0',x_x0)

def makeform(root,fields):
    entries={}
    for field in fields:
        row=Frame(root)
        lab = Label(row,width=22,text=field+":",anchor='w')
        ent= Entry(row)
        ent.insert(0,"0")
        row.pack(side=TOP,fill=X,padx=5,pady=5)
        lab.pack(side=LEFT)
        ent.pack(side=RIGHT,expand = YES,fill=X)
        entries[field]=ent
    return entries
def fetch(entries):
    for entry in entries:
        print('Input => "%s"' % entry.get())
# def plott(entries):
#     x=np.linspace(float(entries['Position_1'].get()),float(entries['Position_2'].get()),10)
#     y = np.linspace(float(entries['Time_1'].get()), float(entries['Time_2'].get()), 10)
#     plt.plot(x,y,color = 'blue')
#     plt.show()


if __name__ == '__main__':
    root=Tk()
    root.title("Equations of Motion in constant Acceleration")
    ents= makeform(root,fields)
    root.bind('<Return>',(lambda event,e =ents: fetch(e)))
    b1=Button(root,text='Average Velocity',command=(lambda e= ents: average_velocity(e)))
    b1.pack(side=BOTTOM,padx=5,pady=5)
    b2 = Button(root, text='Final Velocity devoid of displacement', command=(lambda e=ents: final_velocity(e)))
    b2.pack(side=BOTTOM, padx=5, pady=5)
    b3 = Button(root, text='Displacement devoid of final velocity',command=(lambda e=ents: displacement_velocity(e)))
    b3.pack(side=BOTTOM, padx=5, pady=5)
    b4 = Button(root, text='Final velocity devoid of time',command=(lambda e=ents: final_velocity_time(e)))
    b4.pack(side=BOTTOM, padx=5, pady=5)
    b5 = Button(root, text='Displacement devoid of acceleration', command=(lambda e=ents: displacement_acceleration(e)))
    b5.pack(side=BOTTOM, padx=5, pady=5)
    b6 = Button(root, text='Displacement devoid of initial velocity',command=(lambda e=ents: displacement_velocity_1(e)))
    b6.pack(side=BOTTOM, padx=5, pady=5)
    # b2 = Button(root, text='Draw Average Velocity', command=lambda e= ents : plott(e))
    # b2.pack(side=RIGHT, padx=5, pady=5)
    root.mainloop()
