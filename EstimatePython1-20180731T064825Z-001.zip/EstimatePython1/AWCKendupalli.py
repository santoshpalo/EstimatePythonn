import ClassLibrary as cl
import items as it
w=0.23
tcl = [['long walls',3,8.79],
       ['short walls 1',3,6.22],
       ['short walls 2',2,2.33],
       ['short walls 3',1,1.57]]
tcl=cl.Quantity(tcl)
tcl.tcl()
print(it.items['bmssfa'])
bmss=[['total centre line length',1,51.26-6*w,w,3.2],
      ['deduct door ',-4,1.08,w,2.1],
      ['deduct door 2',-2,0.95,w,2.1],
      ['deduct windows',-5,1.15,w,1.08],
      ['deduct wash openings',-1,2.08,w,2.1],
      ['deduct wash opening short',-1,1.32,w,2.1]]
bmss=cl.Quantity(bmss)
bmss.rate=1000
bmss.volume()
print(it.items['m20'])
rcc=[['alround lintel bend',1,51.26-6*w,w,0.15],
     ['front chajja',1,6.12,0.45,0.062],
     ['side long chajja',1,6.48,0.45,0.062],
     ['chajjas over windows',4,1.44,0.45,0.062],
     ['columns',9,w,w,3.05]]
rcc=cl.Quantity(rcc)
rcc.rate=4000
rcc.volume()
print(it.items['rscs_beam'])
rscscolumn=[['columns',9*4,w,3.05],
            ]
rscs=cl.Quantity(rscscolumn)
rscs.rate=400
rscs.vArea()
print(it.items['rscs_lintel'])
rscslintel=[['alround lintel',2,51.26-6*w,0.15]]
rscslintel=cl.Quantity(rscslintel)
rscslintel.rate=150
rscslintel.vArea()
print(it.items['rscs_slab'])
rscschajja=[['front long chajja',1,6.12,0.45],
            ['side long chajja',1,6.48,0.45],
            ['window chajjas',4,1.44,0.45],
            ['door ', 4, 1.08, w],
            ['door 2', 2, 0.95, w],
            ['windows', 5, 1.15, w],
            ['wash openings', 1, 2.08, w],
            ['wash opening short', 1, 1.32, w]]
rscschajja=cl.Quantity(rscschajja)
rscschajja.rate=380
rscschajja.hArea()
print(it.items['hysd'])
reinforcement=[['long wall lintel bars',4*3,8.71+.23,0.62],
               ['short walls 1', 3*4, 6.22-.08+.23,0.62],
               ['short walls 2', 2*4, 2.33-.08+.23,0.62],
               ['short walls 3', 1*4, 1.57-.08+.23,0.62],
               ['stirrups',350,0.56,0.395],
               ['chajja bars',38+43+4*10,0.23+.45-.08,0.395],
               ['chajja distribution 1',3,6.12-.08,0.395],
               ['chajja distribution 2',3,6.48-.08,0.395],
               ['chajja distribution 3',4*3,1.44-.08,0.395],
               ['extra bars at door openings',4,1.58,0.62],
               ['extra bars at door openings',2,0.95+.5,0.62],
               ['extraq bars at window openings',4,1.15+.5,0.395],
               ['extra bars at wash opening 1',1,2.33+.5,0.62],
               ['extra bars at wash opening 2', 1, 1.32+ .5, 0.62],
               ['stirrups in columns',180,0.87,0.395]
                ]
reinforcement=cl.Quantity(reinforcement)
reinforcement.reinforcement()
