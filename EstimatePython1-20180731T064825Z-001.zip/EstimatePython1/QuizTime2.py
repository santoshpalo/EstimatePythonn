from tkinter import *
import textwrap
master=Tk()
answers =[
    ("10.00 %",1),
    ("25.00 %",2),
    ("20.00 %",3),
    ("Sorry, I don't know.",4)]
def ShowChoice(text):
    print(text)
var = IntVar()
var.set(answers[0][1])
label=Label(master,text = textwrap.fill("""A person sold an object at \u20B91250.00. If he made a profit of \u20B9250.00, what is his percentage of profit ?""",50),font=("Courier",30)).pack(anchor = N)
for txt , val in answers:
    Radiobutton(master,text=txt,variable=var,value=val,
                command = lambda t= txt, var = answers : ShowChoice(t)).pack(anchor = N)
def response():
    selection = var.get()
    if selection == 1:
        reaction = "No. You are wrong."
    elif selection == 2:
        reaction = "You are right.Do you need one more question ?"
    elif selection == 3:
        reaction = "No. You are wrong."
    else:
        reaction = "Read the lesson again."
    print(reaction)
Button(master,text="OK",command= response,font=("Courier",30)).pack(anchor = N)
master.mainloop()

