from tkinter import *
root = Tk()
T = Text(root,height=2,width = 80)
T.pack()
T.insert(END,"Just a text Widget\nin two lines\n")
mainloop()