import ClassLibrary as cl 
import FunctionLibrary as fl
import items as it






if __name__ == "__main__":
    print('Name of the work:-Construction of community centre at Kaudiamunda Guditala')
    print('Estimated Cost:-\u20B9100000.00\tHead of Account:-M.L.A.L.A.D.-2016')
    print('Calculation of total centre line length')
    tcl=cl.Quantity([['long walls',2,8.15],
                     ['short wallls',3,3.55]])
    print(tcl.tcl()['y0'],'\n',tcl.tcl()['y1'])
    print(it.items['m20'])
    rcc=cl.Quantity([['slab',1,8.53,4.25,0.1],
                     ['beam',1,4.05,0.25,0.15],
                     ['roof bend',2,8.35,0.25,0.15],
                     ['roof bend short',3,3.55,0.25,0.15]])
    rcc.rate=4348.6
    rcc.volume()
    print(it.items['rscs_slab'])
    slab=cl.Quantity([['slab',1,8.53,4.25],
                      ['deduct beam',-1,4.05,0.25],
                      ['roof bend',-1,27.35,.05]])
    slab.rate=305.67
    slab.hArea()
    beam=cl.Quantity([['beam',1,3.55,0.55]])
    beam.rate=462.1
    beam.vArea()
    print(it.items['hysd'])
    print('Cost and conveyance of hysd bar = 4.1q @\u20B94534.46.00/q = \u20B918,5910.00')
    print(it.items['12cp(1:6)'])
    plaster12=cl.Quantity([['walls',1,26.95-2*3.8+1-.25,3.3],
                           ['window1',-.5,1.1,1.2],
                           ['door2',-.5,1.1,2.00],
                           ['door3',-1,2.05,2.00],
                           ['door4',-1,2.5,2.00],
                           ['window2',-1,0.9,1.1]])
    plaster12.rate=85.22
    plaster12.vArea()
    print(it.items['16cp(1:6)'])
    plaster16=cl.Quantity([['walls',1,26.95-1-.25,3.3],
                           ['window11',-.5,1.1,1.2],
                           ['door2',-.5,1.1,2.00],
                           ['door3',-1,2.05,2.00],
                           ['door4',-1,2.5,2.00],
                           ['window2',-1,0.9,1.1]])
    plaster16.rate=119.57
    plaster16.vArea()
    print(it.items['20cp(1:6)'])
    plaster20=cl.Quantity([['plinth plaster out side of building',1,8.15+.6,0.9]])
    plaster20.rate=129.52
    plaster20.vArea()
    print(it.items['20cp(1:4)'])
    grading=cl.Quantity([['on roof slab top',1,8.53,4.25]])
    grading.rate=140.79
    grading.hArea()
    print(it.items['6cp(1:4)'])
    plaster6=cl.Quantity([['chajja',2,8.4,0.5],
                          ['chajja2',5.15,0.5],
                          ['chajja3',5.15,0.5],
                          ['chajja4',1.3,0.45],
                          ['chajja5',2,3.3,0.5],
                          ['beam',1,3.55,0.55]])
    plaster6.rate=89.91
    plaster6.vArea()
    
    print('\nCost and conveyance of M.S.Doors and windows= 3.0q @ Rs.6300.007q = Rs.18,900.00')
    print(it.items['paint'])
    paint=cl.Quantity([['door1',2.25,1.1,2.0],
                       ['door2',2.25,2.05,2.00],
                       ['door3',2.25,2.5,2.00],
                       ['window1',2*2.75,0.9,1.2],
                       ['window2',1*2.275,1.1,1.2]])
    paint.rate=83.33
    paint.vArea()
    print(it.items['asfloor'])
    floor=cl.Quantity([['room 1 & 2',1,7.65,3.3]])
    floor.rate=203.42
    floor.hArea()
    print(it.items['wpcp'])
    print('\t\t\t\t\t174.42sqm @ \u20B912.72/sqm = \u20B92216.00\n')
    print('\t\t\tCess for welfare of labourers = \u20B91000.00')
    print('\n\t\t\tDisplay board and photograph = Rs. 300.00')
    print('-'*80)
    fl.signature(100000, 'Rupees one lakh only', 1, '')
    
    
    
    