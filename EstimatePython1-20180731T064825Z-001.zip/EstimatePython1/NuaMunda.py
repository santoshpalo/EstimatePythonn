import textwrap


import ClassLibrary as cl

print('Name of the work:-Improvement of Nuamunda at Chaukamal, Mahada G.P.\nEstimated Cost:- \u20B91,00,000.00\tHead of Account:-4th S.F.C.(2016-17)')
print('-'*80)
print(textwrap.fill('''Excavation, loading and carriage by mechanical means in D.I. rock, laterite
and soft rock not requiring blasting interspread with boulders upto 1/2 cum
size with all lifts and delifts including trimming of slopes and bed to design
section and depositing the excavated materials away from work site as per the
specification and as directed by the Engineer-in-charge within an initial lead of
5km from the place of excavation complete''',80))
excavation=cl.Quantity([['Excavated pit',1,36.58,22.86,1.2]])
excavation.rate=97.90
excavation.volume()
print('Departmental contingency = \u20B9500.00')
print('Cess for welfare of labourers = \u20B9 1,000.00\n')
print('Display Board and Photograph = \u20B91,500.00')
print('Labour registration cess = \u20B9100.00')
excavation1=cl.Quantity([['Excavated pit',1,36.58,22.86,1.2]])
excavation1.rate=97.90
excavation1.volume()