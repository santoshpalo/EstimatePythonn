#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 11 16:01:07 2018

@author: spalo
"""

import pandas as pd
import items as it
import FunctionLibraryR as fl
import math as mt
import numpy as np
import LeadStatementGST as ls
#Data for coefficients of different items
lm=np.zeros(40,dtype=np.float64).reshape(5,8)
lm[0,0]=.43*1.2
lm[1,0]=0.1236
lm[1,5]=1
lm[2,0]=3.9
lm[2,2]=0.18
lm[2,3]=2.29
lm[2,4]=.48
lm[2,7]=0.96
lm[3,0]=4.6
lm[3,2]=0.68
lm[3,3]=3.23
lm[3,4]=.45
lm[3,6]=0.9
lm[4,1]=.05
lm[4,2]=.05
#making series of values from LeadStatementGST
#royalty=pd.Series()



pd.set_option('max_colwidth', 0)
pd.set_option('display.expand_frame_repr', False)
pd.set_option('display.precision', 2)

class UniformWidth():
    def __init__(self,length,breadth,cut_off_wall,thickness):
        self.length=length
        self.breadth=breadth
        self.cut_off_wall=cut_off_wall
        self.thickness=thickness
    def foundation(self):
        '''Excavation of foundation trench in cut-off wall'''
        data=[[2,self.length,self.cut_off_wall[0],self.cut_off_wall[1]],
              [1,self.length,self.breadth[0],0.10]]
        table=pd.DataFrame(data,index=['cut-off walls','surface area'],columns=['no','length','breadth','depth'])
        table['Total']=table['no']*table['length']*table['breadth']*table['depth']
        sumTotal=table['Total'].sum()
        table['no']=table['no'].map('{:.0f}no'.format)
        table['length']=table['length'].map('{:.2f}m'.format)
        table['breadth']=table['breadth'].map('{:.2f}m'.format)
        table['depth']=table['depth'].map('{:.2f}m'.format)
        table['Total']=table['Total'].map('{:.2f}cum'.format)
        print (it.items['efhs'],'\n',table,'\n\t\t\t\t\t','{:.2f}cum'.format(sumTotal),'@\u20B9{:.2f}/cum = '.format(fl.foundation(1)),'\u20B9{:.2f}'.format(mt.ceil(sumTotal*fl.foundation(1))))
        return sumTotal*fl.foundation(1)
    def sand_fill(self):
        '''Filling sand in foundation and plinth well watered and rammed, The thickness of sand filling is the 0th element in the array of thickness'''
        data=[
              [1,self.length,self.breadth[0]-self.cut_off_wall[0],self.thickness[0]]]
        table=pd.DataFrame(data,index=['surface area'],columns=['no','length','breadth','depth'])
        table['Total']=table['no']*table['length']*table['breadth']*table['depth']
        sumTotal=table['Total'].sum()
        table['no']=table['no'].map('{:.0f}no'.format)
        table['length']=table['length'].map('{:.2f}m'.format)
        table['breadth']=table['breadth'].map('{:.2f}m'.format)
        table['depth']=table['depth'].map('{:.2f}m'.format)
        table['Total']=table['Total'].map('{:.2f}cum'.format)
        print (it.items['sand_fill'],'\n',table,'\n\t\t\t\t\t','{:.2f}cum'.format(sumTotal),'@\u20B9{:.2f}/cum = '.format(fl.sandfilling()),'\u20B9{:.2f}'.format(mt.ceil(sumTotal*fl.sandfilling())))
        return sumTotal*fl.sandfilling()

    def metal_concrete(self):
        '''Cement concrete (1:3:6) using 40 mm cbg metal, The thickness of metal concrete is the 1st element in the array of thickness'''
        data=[[2,self.length,self.cut_off_wall[0],self.cut_off_wall[1]],
              [1,self.length,self.breadth[0],self.thickness[1]]]
        table=pd.DataFrame(data,index=['cut-off walls','sub base area'],columns=['no','length','breadth','depth'])
        table['Total']=table['no']*table['length']*table['breadth']*table['depth']
        sumTotal=table['Total'].sum()
        table['no']=table['no'].map('{:.0f}no'.format)
        table['length']=table['length'].map('{:.2f}m'.format)
        table['breadth']=table['breadth'].map('{:.2f}m'.format)
        table['depth']=table['depth'].map('{:.2f}m'.format)
        table['Total']=table['Total'].map('{:.2f}cum'.format)
        print (it.items['CC(1:3:6)'],'\n',table,'\n\t\t\t\t\t','{:.2f}cum'.format(sumTotal),'@\u20B9{:.2f}/cum = '.format(fl.concrete(2)),'\u20B9{:.2f}'.format(mt.ceil(sumTotal*fl.concrete(2))))
        return sumTotal*fl.concrete(2)

    def chips_concrete(self):
        '''Cement concrete (1:2:4) using 12 mm cbg chips, The thickness of chips concrete is the 2nd element in the array of thickness'''
        data=[
              [1,self.length,self.breadth[0],self.thickness[2]]]
        table=pd.DataFrame(data,index=['crust area'],columns=['no','length','breadth','depth'])
        table['Total']=table['no']*table['length']*table['breadth']*table['depth']
        sumTotal=table['Total'].sum()
        table['no']=table['no'].map('{:.0f}no'.format)
        table['length']=table['length'].map('{:.2f}m'.format)
        table['breadth']=table['breadth'].map('{:.2f}m'.format)
        table['depth']=table['depth'].map('{:.2f}m'.format)
        table['Total']=table['Total'].map('{:.2f}cum'.format)
        print (it.items['CC(1:2:4)'],'\n',table,'\n\t\t\t\t\t','{:.2f}cum'.format(sumTotal),'@\u20B9{:.2f}/cum = '.format(fl.concrete(3)),'\u20B9{:.2f}'.format(mt.ceil(sumTotal*fl.concrete(3))))
        return [sumTotal*fl.concrete(3),sumTotal]

    def earth_mechanical(self):
        '''Earth work in hard soil by mechanical means including all lifts and lead, royalty etc. Breadth of berm is the 1st element of array Breadth and thickness of berm is 3rd element of thickness array'''
        data=[
              [2,self.length,self.breadth[1],self.thickness[3]]]
        table=pd.DataFrame(data,index=['crust area'],columns=['no','length','breadth','depth'])
        table['Total']=table['no']*table['length']*table['breadth']*table['depth']
        sumTotal=table['Total'].sum()
        table['no']=table['no'].map('{:.0f}no'.format)
        table['length']=table['length'].map('{:.2f}m'.format)
        table['breadth']=table['breadth'].map('{:.2f}m'.format)
        table['depth']=table['depth'].map('{:.2f}m'.format)
        table['Total']=table['Total'].map('{:.2f}cum'.format)
        print (it.items['Earth_work_mechanical'],'\n',table,'\n\t\t\t\t\t','{:.2f}cum'.format(sumTotal),'@\u20B9{:.2f}/cum = '.format(fl.earthwork_mechanical(1)),'\u20B9{:.2f}'.format(mt.ceil(sumTotal*fl.earthwork_mechanical(1))))
        return sumTotal*fl.earthwork_mechanical(1)

    def rscs(self):
        '''Rigid and smooth centering and shuttering of cut-off walls both insdide and out side'''
        data=[[2,self.length,self.thickness[0]],
              [1,self.length,self.thickness[0]+self.thickness[1]+self.thickness[2]]]
        table=pd.DataFrame(data,index=['inner side of cut-off walls','outer side of cut-off walls'],columns=['no','length','height'])
        table['Total']=table['no']*table['length']*table['height']
        sumTotal=table['Total'].sum()
        table['no']=table['no'].map('{:.0f}no'.format)
        table['length']=table['length'].map('{:.2f}m'.format)

        table['height']=table['height'].map('{:.2f}m'.format)
        table['Total']=table['Total'].map('{:.2f}cum'.format)
        print (it.items['rscs_plinth'],'\n',table,'\n\t\t\t\t\t','{:.2f}cum'.format(sumTotal),'@\u20B9{:.2f}/cum = '.format(fl.rscs(3)),'\u20B9{:.2f}'.format(mt.ceil(sumTotal*fl.rscs(3))))
        return sumTotal*fl.rscs(3)
    def vibrator(self):
        '''Plate vibrator is used to consolidate the crust concrete @ 0.4 hour per 1cum of concrete'''
        quantity = self.chips_concrete()[1]
        print ('Hire and running charges of plate viobrator','{:.2f}hour'.format(quantity),'@\u20B9{:.2f} = \u20B9 '.format(106),quantity*106)
        return quantity*106
    def miscellaneous(self):
        '''Provision for display board and photograph'''
        print('\nProvision for display Board and photo graph = \u20B9 3,000.00')
        return 3000


    def foundationR(self):
            '''Excavation of foundation trench in cut-off wall'''
            data=[[2,self.length,self.cut_off_wall[0],self.cut_off_wall[1]],
                  [1,self.length,self.breadth[0],0.10]]
            table=pd.DataFrame(data,index=['cut-off walls','surface area'],columns=['no','length','breadth','depth'])
            table['Total']=table['no']*table['length']*table['breadth']*table['depth']
            sumTotal=table['Total'].sum()
            return sumTotal*fl.foundation(1)
    def sand_fillR(self):
        '''Filling sand in foundation and plinth well watered and rammed, The thickness of sand filling is the 0th element in the array of thickness'''
        data=[
              [1,self.length,self.breadth[0]-self.cut_off_wall[0],self.thickness[0]]]
        table=pd.DataFrame(data,index=['surface area'],columns=['no','length','breadth','depth'])
        table['Total']=table['no']*table['length']*table['breadth']*table['depth']
        sumTotal=table['Total'].sum()
        return sumTotal*fl.sandfilling()

    def metal_concreteR(self):
        '''Cement concrete (1:3:6) using 40 mm cbg metal, The thickness of metal concrete is the 1st element in the array of thickness'''
        data=[[2,self.length,self.cut_off_wall[0],self.cut_off_wall[1]],
              [1,self.length,self.breadth[0],self.thickness[1]]]
        table=pd.DataFrame(data,index=['cut-off walls','sub base area'],columns=['no','length','breadth','depth'])
        table['Total']=table['no']*table['length']*table['breadth']*table['depth']
        sumTotal=table['Total'].sum()
        return sumTotal*fl.concrete(2)

    def chips_concreteR(self):
        '''Cement concrete (1:2:4) using 12 mm cbg chips, The thickness of chips concrete is the 2nd element in the array of thickness'''
        data=[
              [1,self.length,self.breadth[0],self.thickness[2]]]
        table=pd.DataFrame(data,index=['crust area'],columns=['no','length','breadth','depth'])
        table['Total']=table['no']*table['length']*table['breadth']*table['depth']
        sumTotal=table['Total'].sum()
        return [sumTotal*fl.concrete(3),sumTotal]

    def earth_mechanicalR(self):
        '''Earth work in hard soil by mechanical means including all lifts and lead, royalty etc. Breadth of berm is the 1st element of array Breadth and thickness of berm is 3rd element of thickness array'''
        data=[
              [2,self.length,self.breadth[1],self.thickness[3]]]
        table=pd.DataFrame(data,index=['crust area'],columns=['no','length','breadth','depth'])
        table['Total']=table['no']*table['length']*table['breadth']*table['depth']
        sumTotal=table['Total'].sum()
        return sumTotal*fl.earthwork_mechanical(1)

    def rscsR(self):
        '''Rigid and smooth centering and shuttering of cut-off walls both insdide and out side'''
        data=[[2,self.length,self.thickness[0]],
              [1,self.length,self.thickness[0]+self.thickness[1]+self.thickness[2]]]
        table=pd.DataFrame(data,index=['inner side of cut-off walls','outer side of cut-off walls'],columns=['no','length','height'])
        table['Total']=table['no']*table['length']*table['height']
        sumTotal=table['Total'].sum()
        return sumTotal*fl.rscs(3)
    def vibratorR(self):
        '''Plate vibrator is used to consolidate the crust concrete @ 0.4 hour per 1cum of concrete'''
        quantity = self.chips_concreteR()[1]
        return quantity*106
    def miscellaneousR(self):
        '''Provision for display board and photograph'''
        return 3000
    def cessR(self):
        cess=mt.ceil((self.foundation()+self.sand_fill()+self.metal_concrete()+self.chips_concrete()+self.rscs()+self.earth_mechanical()+self.vibrator()+self.miscellaneous())*.01)
        return cess
    def cess(self):
        cess=mt.ceil((self.foundationR()+self.sand_fillR()+self.metal_concreteR()+self.chips_concreteR()[0]+self.rscsR()+self.earth_mechanicalR()+self.vibratorR()+self.miscellaneousR())*.01)
        print('\n','Provision for 1% cess for welfare of labourers = ','\u20B9{:.2f}'.format(cess))
        return cess
#Calculation  of quantities for variable width road
class VariableWidth():
    def __init__(self,surface_data,cut_off_wall,thickness):
        self.surface_data=surface_data
        self.cut_off_wall=cut_off_wall
        self.thickness = thickness

    def surface_areaR(self):
        '''This function returns the total surface area of the road, total surface area of cut-off wall, area of sand filling and cut-off wall length'''
        table=pd.DataFrame(self.surface_data,columns=['description','length','width 1','width 2'],index=range(1,len(self.surface_data)+1))
        table['area']=round(table['length']*(table['width 1']+table['width 2'])/2,2)
        table['cut-off wall length']=(table['length']**2+(table['width 1']-table['width 2'])**2).map(mt.sqrt)
        sumArea=table['area'].sum()
        sumCutoffWallLength=table['cut-off wall length'].sum()*2
        return [sumArea,round(sumCutoffWallLength*self.cut_off_wall[0],2),round(sumArea-sumCutoffWallLength*self.cut_off_wall[0],2),round(sumCutoffWallLength,2)]

    def surface_area(self):
        '''This function prints the total surface area of the road in a tabular form.'''
        table=pd.DataFrame(self.surface_data,columns=['description','length','width 1','width 2'],index=range(1,len(self.surface_data)+1))
        table['area']=round(table['length']*(table['width 1']+table['width 2'])/2,2)
        sumTotal = table['area'].sum()
        table['length']=table['length'].map('{:.2f}m'.format)
        table['width 1']=table['width 1'].map('{:.2f}m'.format)
        table['width 2']=table['width 2'].map('{:.2f}m'.format)
        table['area']=table['area'].map('{:.2f}sqm'.format)
        print('Calculation of total surface area of the road\n\n',table,'\n','\nThe total surface area of the road = ','{:.2f}sqm'.format(sumTotal))

    def foundationR(self):
        '''This function calculates the excavation of foundation and area development for camber.'''
        data=[[self.surface_areaR()[0],0.1],
              [self.surface_areaR()[1],0.15]]
        table=pd.DataFrame(data,index=['area dressing for cambering','cut-off walls'],columns=['area','thickness'])
        table['volume']=round(table['area']*table['thickness'],2)
        sumVolume=table['volume'].sum()
        return [sumVolume,mt.ceil(sumVolume*fl.foundation(1))]
    def sand_fillR(self):
        '''This method calculates the cost towards filling sand in the sub grade of the road.'''
        data=[[self.surface_areaR()[0],self.thickness[0]],
               [-self.surface_areaR()[1],self.thickness[0]]]
        table=pd.DataFrame(data,index=['surface area of the road','deduct area of cut-off wall'],columns=['area','thickness'])
        table['volume']=round(table['area']*table['thickness'],2)
        sumVolume=table['volume'].sum()
        return [sumVolume,mt.ceil(sumVolume*fl.sandfilling())]
    def metal_concreteR(self):
        '''This method calculates the volume and cost of metal concrete work in sub base and cut-off walls.'''
        data=[[self.surface_areaR()[0],self.thickness[1]],
               [self.surface_areaR()[1],self.cut_off_wall[1]]]
        table=pd.DataFrame(data,index=['surface area of the road',' cut-off wall'],columns=['area','thickness'])
        table['volume']=round(table['area']*table['thickness'],2)
        sumVolume=table['volume'].sum()
        return [sumVolume,mt.ceil(sumVolume*fl.concrete(2))]
    def chips_concreteR(self):
        '''This method calculates the volume and cost of chips concrete work in crust.'''
        data=[[self.surface_areaR()[0],self.thickness[1]],
               ]
        table=pd.DataFrame(data,index=['surface area of the road'],columns=['area','thickness'])
        table['volume']=round(table['area']*table['thickness'],2)
        sumVolume=table['volume'].sum()
        return [sumVolume,mt.ceil(sumVolume*fl.concrete(3))]
    def vibratorR(self):
        '''This method calculates the hour for which the plate vibrator worked and its H/R charges'''
        return mt.ceil(self.chips_concreteR()[0]*.4*106)
    def rscsR(self):
        '''This method evaluates the area of centering and shuttering of cut-off walls on both sides of road'''
        data=[[self.surface_areaR()[3],self.thickness[0]],
               [self.surface_areaR()[3],self.thickness[0]+self.thickness[1]+self.thickness[2]]]
        table=pd.DataFrame(data,index=['inner side of walls','outer sudes of the walls'],columns=['length','height'])
        table['area']=round(table['length']*table['height'],2)
        sumArea=table['area'].sum()
        return [sumArea,mt.ceil(sumArea*fl.rscs(3))]
    def miscellaneousR(self):
        '''This method calculates the cost for display board and photograph '''
        return 2000
    def cessR(self):
        '''This module gives us cess for welfare of labourers 1 % of total cost'''
        return (self.miscellaneousR()+self.chips_concreteR()[1]+self.metal_concreteR()[1]+self.rscsR()[1]+self.sand_fillR()[1]+self.vibratorR()+self.foundationR()[1])*.01

    def foundation(self):
        '''This function calculates the excavation of foundation and area development for camber.'''
        data=[[self.surface_areaR()[0],0.1],
              [self.surface_areaR()[1],0.15]]
        table=pd.DataFrame(data,index=['area dressing for cambering','cut-off walls'],columns=['area','thickness'])
        table['volume']=round(table['area']*table['thickness'],2)
        sumVolume=table['volume'].sum()
        table['area']=table['area'].map('{:.2f}sqm'.format)
        table['thickness']=table['thickness'].map('{:.2f}m'.format)
        table['volume']=table['volume'].map('{:.2f}cum'.format)
        print ('\n',it.items['efhs'],'\n',table,'\n\t\t\t\t\t','{:.2f}cum'.format(sumVolume),'@ \u20B9{:.2f} = '.format(fl.foundation(1)),'\u20B9{:.2f}'.format(mt.ceil(sumVolume*fl.foundation(1))))
    def sand_fill(self):
        '''This method calculates the cost towards filling sand in the sub grade of the road.'''
        data=[[self.surface_areaR()[0],self.thickness[0]],
               [-self.surface_areaR()[1],self.thickness[0]]]
        table=pd.DataFrame(data,index=['surface area of the road','deduct area of cut-off wall'],columns=['area','thickness'])
        table['volume']=round(table['area']*table['thickness'],2)
        sumVolume=table['volume'].sum()
        table['area']=table['area'].map('{:.2f}sqm'.format)
        table['thickness']=table['thickness'].map('{:.2f}m'.format)
        table['volume']=table['volume'].map('{:.2f}cum'.format)
        print ('\n',it.items['sand_filling'],'\n',table,'\n\t\t\t\t\t','{:.2f}cum'.format(sumVolume),'@ \u20B9{:.2f} = '.format(fl.sandfilling()),'\u20B9{:.2f}'.format(mt.ceil(sumVolume*fl.sandfilling())))

    def metal_concrete(self):
        '''This method calculates the volume and cost of metal concrete work in sub base and cut-off walls.'''
        data=[[self.surface_areaR()[0],self.thickness[1]],
               [self.surface_areaR()[1],self.cut_off_wall[1]]]
        table=pd.DataFrame(data,index=['surface area of the road',' cut-off wall'],columns=['area','thickness'])
        table['volume']=round(table['area']*table['thickness'],2)
        sumVolume=table['volume'].sum()
        table['area']=table['area'].map('{:.2f}sqm'.format)
        table['thickness']=table['thickness'].map('{:.2f}m'.format)
        table['volume']=table['volume'].map('{:.2f}cum'.format)
        print ('\n',it.items['CC(1:3:6)'],'\n',table,'\n\t\t\t\t\t','{:.2f}cum'.format(sumVolume),'@ \u20B9{:.2f} = '.format(fl.concrete(2)),'\u20B9{:.2f}'.format(mt.ceil(sumVolume*fl.concrete(2))))

    def chips_concrete(self):
        '''This method calculates the volume and cost of chips concrete work in crust.'''
        data=[[self.surface_areaR()[0],self.thickness[1]],
               ]
        table=pd.DataFrame(data,index=['surface area of the road'],columns=['area','thickness'])
        table['volume']=round(table['area']*table['thickness'],2)
        sumVolume=table['volume'].sum()
        table['area']=table['area'].map('{:.2f}sqm'.format)
        table['thickness']=table['thickness'].map('{:.2f}m'.format)
        table['volume']=table['volume'].map('{:.2f}cum'.format)
        print ('\n',it.items['CC(1:2:4)'],'\n',table,'\n\t\t\t\t\t','{:.2f}cum'.format(sumVolume),'@ \u20B9{:.2f} = '.format(fl.concrete(3)),'\u20B9{:.2f}'.format(mt.ceil(sumVolume*fl.concrete(3))))

    def vibrator(self):
        '''This method calculates the hour for which the plate vibrator worked and its H/R charges'''
        print('\nHire and Running charges of plate vibrator\n','{:.2f}cum'.format(self.chips_concreteR()[0]),'of concrete @ 0.4hour/cum of concrete =  ','{:.2f}hour'.format(self.chips_concreteR()[0]*.4),'@ \u20B9{:.2f}='.format(106), '\u20B9{:.2f}'.format(mt.ceil(self.chips_concreteR()[0]*.4*106)))
    def rscs(self):
        '''This method evaluates the area of centering and shuttering of cut-off walls on both sides of road'''
        data=[[self.surface_areaR()[3],self.thickness[0]],
               [self.surface_areaR()[3],self.thickness[0]+self.thickness[1]+self.thickness[2]]]
        table=pd.DataFrame(data,index=['inner side of walls','outer sudes of the walls'],columns=['length','height'])
        table['area']=round(table['length']*table['height'],2)
        sumArea=table['area'].sum()
        table['length']=table['length'].map('{:.2f}m'.format)
        table['height']=table['height'].map('{:.2f}m'.format)
        table['area']=table['area'].map('{:.2f}sqm'.format)
        print ('\n',it.items['rscs_plinth'],'\n',table,'\n\t\t\t\t\t','{:.2f}cum'.format(sumArea),'@ \u20B9{:.2f} = '.format(fl.rscs(3)),'\u20B9{:.2f}'.format(mt.ceil(sumArea*fl.rscs(3))))

    def miscellaneous(self):
        '''This method calculates the cost for display board and photograph '''
        print('\n','Provisional cost towards Display Board and photograph',' =\u20B9{:.2f}'.format(self.miscellaneousR()))
        return 2000
    def cess(self):
        '''This module gives us cess for welfare of labourers 1 % of total cost'''
        print('\nCess for welfare of labourers = \t\t','\u20B9{:.2f}'.format(mt.floor((self.miscellaneousR()+self.chips_concreteR()[1]+self.metal_concreteR()+self.rscsR()+self.sand_fillR()+self.vibratorR()+self.foundationR())*.01)))
    def totalR(self):
        return mt.ceil((self.miscellaneousR()+self.chips_concreteR()[1]+self.metal_concreteR()[1]+self.rscsR()[1]+self.sand_fillR()[1]+self.vibratorR()+self.foundationR()[1])*1.01)
    def labour_material(self):
        ml=np.array([[self.foundationR()[0]],[self.sand_fillR()[0]],[self.metal_concreteR()[0]],[self.chips_concreteR()[0]],[self.rscsR()[0]]])
        data=np.matmul(lm.T,ml)
        table=pd.DataFrame(data,index=['u/s','s/s','mason II','cement','sand','sand filling','chips12','metal40'],columns=['quantity'])
        table.insert(1,'Royalty',table['quantity']*[0,0,0,0,ls.z['Royalty'][2],ls.z['Royalty'][3],ls.z['Royalty'][9],ls.z['Royalty'][11]])
        table.insert(2,'EGB',table['quantity']*[0,0,0,2*2.8455,0,0,0,0])
        table.insert(3,'basic rate',[224.3,244.3,264.3,ls.z['basic cost'][4],ls.z['basic cost'][2],ls.z['basic cost'][3],ls.z['basic cost'][9],ls.z['basic cost'][11]])
        table.insert(4,'GST',[0,0,0,ls.z['GST'][4],ls.z['GST'][2],ls.z['GST'][3],ls.z['GST'][9],ls.z['GST'][11]])
        table.insert(5,'Gross Rate',table['basic rate']+table['GST'])
        table.insert(6,'total cost',table['quantity']*table['Gross Rate'])
        table.insert(7,'conveyance',[0,0,0,ls.z['conveyance'][4],ls.z['conveyance'][2],ls.z['conveyance'][3],ls.z['conveyance'][9],ls.z['conveyance'][11]])
        table.insert(8,'total conveyance',table['quantity']*table['conveyance'])
        print (table,'\n','Royalty = \u20B9{:.0f}'.format(table['Royalty'].sum()),'\n','EGB = \u20B9{:.0f}'.format(table['EGB'].sum()),'\n','Total M.R. value = \u20B9{:.0f}'.format(table['total cost'][:3].sum()),'\n','Total material cost = \u20B9{:.0f}'.format(table['total cost'][3:].sum()),'\n','Total conveyance cost = \u20B9{:.0f}'.format(table['total conveyance'].sum()),'\n','Display Board and photo graph = \u20B9{:.0f}'.format(self.miscellaneousR()),'\n','Cess towards welfare of labourers = \u20B9{:.0f}'.format(self.cessR()),'\n','Hire and running charges of plate vibrator = \u20B9{:.0f}'.format(self.vibratorR()),'\n','Cost towards wood for centering and shuttering and T & P = \u20B9')













if __name__ == "__main__":
# =============================================================================
     road =UniformWidth(85.18,[3.65,0.9],[0.2,0.15],[.05,0.1,0.1,0.3])
     road.foundation()
     road.sand_fill()
     road.metal_concrete()
     road.vibrator()
     road.rscs()
     road.earth_mechanical()
     road.miscellaneous()
     road.cess()
     print((road.foundationR()+road.sand_fillR()+road.metal_concreteR()+road.chips_concreteR()[0]+road.rscsR()+road.earth_mechanicalR()+road.vibratorR()+road.miscellaneousR())*1.01)
# =============================================================================
#    print(lm)
