import textwrap
import FunctionLibrary as fl


import ClassLibrary as cl
x=0.5
y = 0.14

print(textwrap.fill('Name of the work:-Renovation of Nua Munda and construction of dress changing shed at Chaukamal, Mahada G.P.',80),'\nEstimated Cost:- \u20B91,00,000.00\tHead of Account:-4th S.F.C.(2016-17)')
print('-'*80)
print(textwrap.fill('''Excavation, loading and carriage by mechanical means in D.I. rock, laterite
and soft rock not requiring blasting interspread with boulders upto 1/2 cum
size with all lifts and delifts including trimming of slopes and bed to design
section and depositing the excavated materials away from work site as per the
specification and as directed by the Engineer-in-charge within an initial lead of
5km from the place of excavation complete''',80))
excavation=cl.Quantity([['Excavation of pit ',1,38,23,1.13],
                        ])
excavation.rate=97.90
excavation.volume()
print('Departmental contingency = \u20B9500.00')
print('Cess for welfare of labourers = \u20B9 1,000.00\n')
print('Display Board and Photograph = \u20B91,500.00')
print('Labour registration cess = \u20B9100.00')
excavation1=cl.Quantity([['Excavated pit 1',1,15.24,16+x,1.85+y],
                        ['Excavated pit 2',1,15.24,13.0+x,1.85+y],
                         ['Excavated pit 3', 1, 15.24, 12+x, 1.85+y],
                         ['Excavated pit 4', 1, 15.24, 11.75+x, 1.85+y],
                         ['Excavated pit 5', 1, 15.24, 13.3+x, 1.85+y],
                         ['Excavated pit 6', 1, 30.48, 11.75+x, 1.4+y]])
excavation1.rate=97.90
print('-')
fl.signature(100000,'One lakh only',3,'Mahada G.P.')
# excavation1.volume()
