import ClassLibrary as cl
import items as it








if __name__ == "__main__":
    tcl=cl.Quantity([['long walls 1',2,10.72],
                     ['long walls 2',1,8.48],
                     ['short walls 1',2,5.94],
                     ['short walls 2',1,3.76],
                     ['short walls 3',2,2.13]])
    tcl.tcl()
    print(it.items['12cp(1:6)'])
    cp12mm=cl.Quantity([['alround walls',1,49.82,3.3],
                        ['deduct ver opening',-1,2.59,2.13],
                        ['D-1 opening',-1/2,1.2,2.1],
                        ['D - 2 opening',-1/2,1.08,2.1],
                        ['D -3 opening',-3/2,0.75,2.1],
                        ['Window openings',-4/2,0.9,1.2],
                        ])
    cp12mm.rate=81.21
    cp12mm.vArea()
    print(it.items['16cp(1:6)'])
    cp16mm=cl.Quantity([['alround walls',1,49.82-8*0.25,3.3],
          ['deduct ver opening', -1, 2.59, 2.13],
          ['D-1 opening', -1 / 2, 1.2, 2.1],
          ['D - 2 opening', -1 / 2, 1.08, 2.1],
          ['D -3 opening', -3 / 2, 0.75, 2.1],
          ['Window openings', -4 / 2, 0.9, 1.2]])
    cp16mm.rate=112.27
    cp16mm.vArea()
    print(it.items['20cp(1:6)'])
    cp20mm = cl.Quantity([['long walls',2,10.72+.38,0.5],
                          ['short walls',2,5.94,0.5]])
    cp20mm.rate=121.98
    cp20mm.vArea()
    print(it.items['bmfpcb'])
    brick=cl.Quantity([['1st footing',1,4.95,0.25,0.25],
                       ['footing 2',3,0.65,0.25,0.25],
                       ['above 1st footing',1,4.52,0.25,0.4],
                       ['sloped wall',1,0.95,0.25,0.2],
                       ['steps 1,2,3',3,0.75,0.25,0.08],
                       ['steps 4',1,0.9,0.45,0.15],
                       ['steps 5',1,0.9,0.35,0.08]])
    brick.rate=2790.95
    brick.volume()
    print(it.items['asfloor'])
    floor = cl.Quantity([['deduct walls',-1,41.58-0.75,0.25],
                         ['total area',1,8.48+0.25,5.94+0.25],
                         ['steps and ramp',1,5.76,0.9]])
    floor.rate =189.68
    floor.hArea()
    print(it.items['wpcp'])
    cementpaint=cl.Quantity([['area of 12mm thick plaster',1,151.98],
                             ['area of 16mm thick plaster',1,145.38],
                             ['20 mm thick plaster',1,17.04],
                             ['ceiling area',1,49.01]])
    cementpaint.rate=12.15
    cementpaint.tcl()
    print(it.items['CC(1:4:8)'])
    concrete=cl.Quantity([['verandah',1,2.69,0.65,0.1],
                          ['ramp',1,0.75,0.9,0.1]])
    concrete.rate=2835.52
    concrete.volume()
    print('Cost of wpcp = 90.85kg @ Rs.45.00/kg = Rs.4088.00')
    print('Cess for welfare of labourers = Rs.520.00')

