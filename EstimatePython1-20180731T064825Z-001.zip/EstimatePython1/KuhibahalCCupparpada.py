import ClassLibrary as cl

vitrified=[['hall floor',1,11.1,8.16],
            ['room 1',1,3.3,3.8],
            ['room2',1,3.3,4.2],
           ['door sill 1',1,1.2,0.38],
           ['door sill 2',2,1.2,0.25]
            ]
vit = cl.Quantity(vitrified)
vit.rate = 913.71
vit.hArea()
walltile= [['hall wall 1',1,11.6,0.9],
           ['hall wall 2',1,10.6,0.9],
           ['hall wall 3',1,8.25,0.9],
           ['hall wall 4',1,8.16,0.9],
           ['smaller rooms width',4,3.3,0.9],
           ['entrance room length',2,3.82,0.9],
           ['inner room length',2,4.2,0.9],
           ['door sill 1', -1, 1.2, 0.9-2*.3],
           ['door sill 2', -2, 1.2, 0.9-2*0.25],
           ['front skirting',1,0.38+0.25,0.9],
           ['step risers',2,1.7,0.15]
           ]
waltile=cl.Quantity(walltile)
waltile.rate=629.81
waltile.vArea()
floortile=[['steps',2,1.7,0.41]]
flortile=cl.Quantity(floortile)
flortile.rate=709.29
flortile.hArea()
tcl=[['long wall 1',1,11.6+0.25*2+3.3],
     ['long wall 2',1,10.6+0.5+3.3],
     ['short walls 1',2,8.16+.25],
     ['short walls2',1,8.5]]
tcl=cl.Quantity(tcl)
tcl.tcl()
brick=[['speps 1st footing',1,1.7,0.85,0.25],
       ['steps 2nd footing',1,1.7,0.42,0.15]]
brick=cl.Quantity(brick)
brick.rate=2943.3
brick.volume()