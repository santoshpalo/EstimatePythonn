import numpy as np
import textwrap
import pandas as pd
import items as it
import LeadStatementGST as ls1
from tkinter import *
import FunctionLibraryR as fr
import FunctionLibrary as fl
h=2.1
tcl = ([['long walls',2,6.4],
        ['short walls',2,4.5]])
flyash = ([['totla wall',1,21.8,0.4,0.25]])
flyashss=([['total length',1,21.8,0.25,h],
           ['deduct door',-1,0.9,0.25,h]])
oldbrick = ([['total wall',1,21.8,0.4,0.35]])
plinthbend = ([['total length',1,21.8,0.4,0.15]])
dismantle= ([['brick masonry walls part 1',1,2.5,0.4,2.0]])
sandfill=([['rooom',1,6.02,4.11,0.6]])
CC148=([['rooom',1,6.02,4.11,0.1]])
plaster16=([['plinth walls',1,21.8+4*.4,0.9]])
plinthrscs=([['plinth bend',2,21.8,0.15]])
print('Estimated Cost:-\u20B950,000.00\tHead of account:-M.L.A.L.A.D.(2013-14)')
print('-'*80)
class Length:
    def __init__(self,master):
        frame = Frame(master,bg = 'red')
        frame.pack()
        self.Label = Label(frame, text = 'Length')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.TCL = Button(frame,text = "Total centre line length",command = self.TCL)
        self.TCL.pack(side=TOP)
    def TCL(self):
        d = tcl
        table = pd.DataFrame(d, index=range(1, len(d) + 1),
                             columns=['description', 'no', 'length'])
        table['quantity'] = table['no'] * table['length'] .round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)
        print('\n', 'Total centre line length', '\n', table, '\n\t\t\t\t\t',
              '{:.2f}m'.format(table.tquantity))


root = Tk()
app = Length(root)
root.mainloop()
class Volume:
    def __init__(self,master):
        frame = Frame(master,bg = 'green')
        frame.pack()
        self.Label = Label(frame, text = 'Volume',bg = 'AntiqueWhite1', fg = 'blue4')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.foundation = Button(frame,text = "dismantle brick masonry",command = self.dismantling, bg = 'blanched almond', fg = 'blue')
        self.foundation.pack(side=TOP)
        self.sandfill = Button(frame, text="filling sand", command=self.sandfilling)
        self.sandfill.pack(side=TOP)
        self.flyashfp = Button(frame, text="fly ash brick masonry in F & P", command=self.bmfpfa)
        self.flyashfp.pack(side=TOP)
        self.cbbmfp = Button(frame, text="clamp burnt brick masonry in F & P", command=self.bmfpcb)
        self.cbbmfp.pack(side=TOP)
        self.rcc = Button(frame, text="R.C.C. M-20 grade concrete", command=self.rccm20)
        self.rcc.pack(side=TOP)
        self.cc148 = Button(frame, text="Cement concrete (1:4:8)", command=self.pcc148)
        self.cc148.pack(side=TOP)
        self.flyashss = Button(frame, text="fly ash brick masonry in S / S", command=self.bmssfa)
        self.flyashss.pack(side=TOP)
    def dismantling(self):
        d = ([['brick masonry walls part 1',1,2.5,0.4,2.0]])
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['dismantle brick work'], '\n', table,'\n\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(687.17),'\u20B9{:.2f} '.format(round(687.17*table.tquantity,0)))
    def sandfilling(self):
        d = sandfill
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['sand_filling'], '\n', table,'\n\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.sandfilling()),'\u20B9{:.2f} '.format(round(fr.sandfilling()*table.tquantity,0)))
    def bmfpfa(self):
        d = flyash
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['bmfpfa'], '\n', table,'\n\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.brickmasonry(2)[0]),'\u20B9{:.2f} '.format(round(fr.brickmasonry(2)[0]*table.tquantity,0)))
    def bmfpcb(self):
        d = oldbrick
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['bmfpcb'], '\n', table,'\n\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.brickmasonry(1)[0]),'\u20B9{:.2f} '.format(round(fr.brickmasonry(1)[0]*table.tquantity,0)))
    def rccm20(self):
        d=plinthbend
        table = pd.DataFrame(d, index=range(1, len(d) + 1),
                             columns=['description', 'no', 'length', 'breadth', 'height'])
        table['quantity'] = table['no'] * table['length'] * table['breadth'] * table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['m20'], '\n', table, '\n\t\t\t\t\t',
              '{:.2f}cum'.format(table.tquantity), '@ \u20B9{:.2f} = '.format(fr.gradedconcrete(2)),
              '\u20B9{:.2f} '.format(round(fr.gradedconcrete(2)* table.tquantity, 0)))
    def pcc148(self):
        d = CC148
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['CC(1:4:8)'], '\n', table,'\n\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.concrete(1)),'\u20B9{:.2f} '.format(round(fr.concrete(1)*table.tquantity,0)))
    def bmssfa(self):
        d = flyash
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','breadth','height'])
        table['quantity'] = table['no'] * table['length']*table['breadth']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['breadth'] = table['breadth'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}cum'.format)

        print('\n', it.items['bmfpfa'], '\n', table,'\n\t\t\t\t\t',
               '{:.2f}cum'.format(table.tquantity) ,'@ \u20B9{:.2f} = '.format(fr.brickmasonry(2)[0]),'\u20B9{:.2f} '.format(round(fr.brickmasonry(2)[1]*table.tquantity,0)))

root = Tk()
app = Volume(root)
root.mainloop()
#======
class VerticalArea:
    def __init__(self,master):
        frame = Frame(master,bg = 'green')
        frame.pack()
        self.Label = Label(frame, text = 'Vertical Area',bg = 'AntiqueWhite1', fg = 'blue4')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.footing = Button(frame, text='RSCS footiong & plinth', command=self.footing)
        self.footing.pack(side=TOP)
        self.plaster_2 = Button(frame, text='16mm thick plaster (1:6)', command=self.plaster_2)
        self.plaster_2.pack(side=TOP)
    def plaster_2(self):
        d = plaster16
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['16cp(1:6)'], '\n', table,'\n\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.plaster(2)),'\u20B9{:.2f} '.format(round(fr.plaster(2)*table.tquantity,0)))
    def footing(self):
        d = plinthrscs
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['rscs_plinth'], '\n', table,'\n\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.rscs(3)),'\u20B9{:.2f} '.format(round(fr.rscs(3)*table.tquantity,0)))
root = Tk()
app = VerticalArea(root)
root.mainloop()

if __name__ == "__main__":
    print(it.items['hysd'])
    print('Hysd bar quantity = 1.4 quintal @ \u20B94868.07/q = u\u20B96535.00')
    print('Cess for welfare of labourers = \u20B9500.00')
    print('Departmental contingency = \u20B9500.00')
    print('Display board and photograph = \u20B9300.00')
    fr.signature(50000,'Rupees fifty thousand only',1,'')


