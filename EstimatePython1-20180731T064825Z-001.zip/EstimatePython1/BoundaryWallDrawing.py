import matplotlib.pyplot as plt
import matplotlib.pyplot as plt
import matplotlib.patches as patches

fig3 = plt.figure()
ax3 = fig3.add_subplot(111, aspect='equal')
fig3.suptitle('CONSTRUCTION OF BOUNDARY WALL OF BRAJABIHARI HIGH SCHOOL',fontsize = 14,fontweight = 'bold')
ax3.text(4.5,4.55,'Estimated Cost : Rs. 4,00,000.00',style = 'italic')
ax3.text(4.5,4.05,'Head of Account : W.O.D.C.(2016-17)',style = 'italic')
ax3.text(3.5,0.5,'Junior Engineer       Assistant Engineer     Block Development Offcer',fontsize = 8,fontweight = 'bold')
ax3.text(3.5,0.2,'Binka Block Office     Binka Block Office             Binka',fontsize = 8,fontweight = 'bold')
for p in [
        patches.Rectangle(
        (0.2*2-.125, 0.1*2), 0.9, 0.10,
        hatch='oo',
        fill = False
    ),
          patches.Rectangle(
        (0.2*2-.125, 0.1), 0.9, 0.10,
        hatch='...',
        fill = False
    ),
    patches.Rectangle(
        (0.2*2, 0.1*3), 0.65, 0.15,
        hatch='//',
        fill = False
    ),
        patches.Rectangle(
        (0.2*2+(0.15/2), 0.25+.2), 0.5, 0.15,
        hatch='//',
        fill = False
    ),
        patches.Rectangle(
        (0.2*2+(0.27/2), 0.4+.2), 0.38, 0.45,
        hatch='//',
        fill = False
    ),
    patches.Rectangle(
        (0.2*2+.65/2-.25/2, 0.1+.3+.45+.2), 0.25, 1.65,
        hatch='//',
        fill=False
    ),
    
        patches.Rectangle(
        (1.5,2.0), .25, 0.38,
        hatch='//',
        fill = False
    ),
        patches.Rectangle(
        (1.5+.25,2.125), 3.1, 0.25,
        hatch='//',
        fill = False
    ),
        patches.Rectangle(
        (1.5+.25+3.1,2.0), 0.25, 0.38,
        hatch='//',
        fill = False
    ),
        patches.Rectangle(
        (1.5+.25+3.1+.25,2.0), 3.1, 0.25,
        hatch='//',
        fill = False
    ),
        patches.Rectangle(
        (1.5+.25+3.1+0.25+3.1,2.0), 0.25, 0.38,
        hatch='//',
        fill = False
    ),
        patches.Rectangle(
        (1.5+.25+3.1+0.25+3.1+.25,2.125), 3.1, 0.25,
        hatch='//',
        fill = False
    ),
        patches.Rectangle(
        (1.5+.25+3.1+0.25+3.1*2+0.25,2.0), 0.25, 0.38,
        hatch='//',
        fill = False
    ),
]:
    ax3.add_patch(p)
fig3.savefig('rect3.png', dpi=90, bbox_inches='tight')

plt.xlim(0, 12)
plt.ylim(0, 5)
plt.gca().set_aspect('equal', adjustable='box')
plt.draw()
#===============================================================================
# plt.axes()
# 
# circle = plt.Circle((0, 0), radius=0.75, fc='y')
# plt.gca().add_patch(circle)
# rectangle = plt.Rectangle((10, 10), 100, 100, fc='r')
# plt.gca().add_patch(rectangle)
#===============================================================================
#plt.axis('scaled')
plt.show()
