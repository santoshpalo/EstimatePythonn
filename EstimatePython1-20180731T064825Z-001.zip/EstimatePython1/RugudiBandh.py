import statistics as st
import ClassLibrary as cl
import items as it



a=[105,50,34,23,71,20,124,17,100]
a1=[round(i*.3048,2) for i in a]
b=[50,50,30,15,40,10,13,15,50]
b1=[round(i*.3048,2) for i in b]
c = [st.mean([6.33,8,8.67,8.5]),5.5833,5,5,5,5,st.mean([2*2,2*2.5,2*2.61]),2.5,5]
c1=[round(i*.3048,2) for i in c]


if __name__ == "__main__":
    print(c1)
    volumeearth=cl.Quantity([['patch1',1,a1[0],b1[0],c1[0]],
                             ['patch1', 1, a1[1], b1[1], c1[1]],
                             ['patch1', 1, a1[2], b1[2], c1[2]],
                             ['patch1', 1, a1[3], b1[3], c1[3]],
                             ['patch1', 1, a1[4], b1[4], c1[4]],
                             ['patch1', 1, a1[5], b1[5], c1[5]],
                             ['patch1', 1, a1[6], b1[6], c1[6]],
                             ['patch1', 1, a1[7], b1[7], c1[7]],
                             ['patch1', 1, a1[8], b1[8], c1[8]]])
    volumeearth.rate=91.4
    volumeearth.volume()