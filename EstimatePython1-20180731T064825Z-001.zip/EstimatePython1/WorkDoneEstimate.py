import items as it
print('Name of work:-Restoration of Bhagabat Mandir at Ginger Pada')
print('Head of Account:-M.L.A.L.A.D.(2012-13)')
print('Estimated Cost:-\u20B930,000.00')
print('Serial number of this bill:-1st R / A bill')
print('Date of commencement of the work:-19/10/2016\tM.B. No. :-574')
print('Date of completion of the work:-15/11/2015\tPage No. :-(43-46)')
print('-'*80)
print('''Supplying, fitting and fixing of Stainless steel of 304 grade in hand railing
using 50mm dia of 2mm thick circular pipe with Balustrade of size
32mm x 32mm x 2mm @ 0.90mtr. C/C and stainless square pipe bracing
of siz 32mm x 32mm x 2mm in 3 rows in stair case as per approved
design and specification, buffing, polishing etc with cost,
conveyance, taxes of all materials, labour,T&P etc. required for
the complete in all respect.''')
print('\n1 no. door 1.98m X 1.08m\n2 nos. ventilators = 0.45m x 0.45m')
print('65.00 kg @ \u20B9282.10/ kg = \u20B918338.00')
print('\nSupplying and fixing of 2nos. M.S. grills of size 1.2m x 0.50m  ')
print('\n50kg @ \u20B963.00 /kg = \u20B93150.00')
print(it.items[''])

print('-'*80)
print('\n\nJunior Engineer\t\t Assistant Engineer\t\tBlock Development Officer')
print('Binka Block Ofiice\tBinka Block Office\t\t\tBinka')


