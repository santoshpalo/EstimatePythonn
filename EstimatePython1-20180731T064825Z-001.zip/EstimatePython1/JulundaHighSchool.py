#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 11 16:12:33 2018

@author: spalo
"""
import pandas as pd
import FunctionLibraryR as fl
import ClassLibrary as cl
import items as it
print('Name of the work:-')
print('Estimated Cost:-\u20B910,00,000.00\t\tHead of Account:-Grant-in-Aid')
print('-'*80)
print('\n\t\t\tSECTION - A Construction of Boundary wall')
print(it.items['efhs'])
l=183
foundation=cl.Quantity([['wall length',1,l,0.75,0.75]])
foundation.rate=fl.foundation(1)
foundation.volume()
print('\n',it.items['CC(1:3:6)'])
concrete=cl.Quantity([[' in wall foundation',1,l,0.75,0.15]])
concrete.rate=fl.concrete(1)
concrete.volume()
#Filling sand
print('\n',it.items['sand_filling'])
sandfill=cl.Quantity([['wall foundation',1,l,0.75,0.15]])
sandfill.rate=fl.sandfilling()
sandfill.volume()
#Brick masonry in foundation and plinth
print('\n',it.items['bmfpfa'])
bmfp=cl.Quantity([['wall 1st footing',1,l,0.63,0.15],
                  ['2nd footing',1,l,0.5,0.25],
                  ['3rd footing',1,l,0.38,0.30]])
bmfp.rate=fl.brickmasonry(2)[0]
bmfp.volume()
#Brick masonry in super structure
print('\n',it.items['bmssfa'])
bmss=cl.Quantity([['wall in super structure',1,l-20,0.25,1.65],
                  ['intermediate pillars',80,0.38,0.25,1.65]])
bmss.rate=fl.brickmasonry(2)[1]
bmss.volume()
#plaster 12mm thick
print('\n',it.items['12cp(1:6)'])
plaster12=cl.Quantity([['walls',1,l,1.65],
                       ['pillar faces',80,0.25*2,1.65],
                       ['plinth plaster',1,l,0.45]])
plaster12.rate=fl.plaster(1)
plaster12.vArea()
#plaster 16 mm thick
print('\n',it.items['16cp(1:6)'])
plaster16=cl.Quantity([['walls',1,l,1.65],
                       ['existing boundary wall',1,56,1.65],
                       ['plinth plaster',1,l,0.45]])
plaster16.rate=fl.plaster(2)
plaster16.vArea()
#water proofing cement paint
print('\n',it.items['wpcp'])
waterproof=cl.Quantity([['12 mm thick plaster',100],
                        ['16mm thick plaster area',100]])
waterproof.rate=fl.waterproofpaint()
waterproof.quantity(2)
#Construction of cement concrete road
print('\n\t\t SECTION-B CEMENT CONCRETE ROAD')
#foundation trench excavation
m=115.8
print('\n',it.items['efhs'])
foundation=cl.Quantity([['cut-off walls',2,m,0.20,0.15],
                        ['dressing of the road to proper camber',1,m,3.65,0.15]])
foundation.rate=fl.foundation(1)
foundation.volume()
#Sand filling
print('\n',it.items['sand_filling'])
sandfill=cl.Quantity([['in the road subgrade',1,m,3.65-.4,0.05]])
sandfill.rate=fl.sandfilling()
sandfill.volume()
#Cement concrete (1:3:6)
print('\n',it.items['CC(1:3:6)'])
concrete=cl.Quantity([['cut-off walls',2,m,0.2,0.25],
                      ['sub base of the road',1,m,3.65,0.1]])
concrete.rate=fl.concrete(1)
concrete.volume()
#Cement concrete(1:2:4)
print('\n',it.items['CC(1:2:4)'])
concrete=cl.Quantity([['crust of the road',1,m,3.65,0.1]])
concrete.rate=fl.concrete(2)
concrete.volume()
#Rigid and smooth centering &shuttering
print('\n',it.items['rscs_plinth'])
plinth=cl.Quantity([['out side of cut-off walls',2,m,.05+.1*2],
                    ['inside of cut-off walls',2,m,.05]])
plinth.rate=fl.rscs(3)
plinth.vArea()
#Hire and running charges of vibrator
print('\nHire and runniong charges of vibrator 16.9hr @ \u20B9106.00/hr = \u20B91,791.00')
#earth work in hard soil
print('\n',it.items['Earth_work_mechanical'])
earthwork=cl.Quantity([['both side berma',2,m,0.6,0.3]])
earthwork.rate=fl.earthwork_mechanical()
earthwork.volume()
#miscellaneous
print('\nProvision for cess for welfare of labourers = \u20B910,000.00')
print('\nProvision for display board and photograph = \u20B93,500.00')
print('-'*80)
fl.signature(10000,'ten lakh only',5,'')








