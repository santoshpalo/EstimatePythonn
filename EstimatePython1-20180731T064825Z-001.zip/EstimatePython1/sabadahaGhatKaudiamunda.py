import ClassLibrary as cl 
import items as it
import FunctionLibrary as fl







if __name__ == "__main__":
    print(it.items['rcc'])
    slab = cl.Quantity([['slab ',1,7.5,5,0.1],
                        ['beam',1,4.4,0.25,0.20],
                        ['roof bend',1,21.66-.5,0.25,0.2],
                        ['hole in the RCC slab',-2,.6,0.6,0.1],
                        ['Add RCC cover plates',2,1.2,1.2,.1],
                        ['RCC columns',6,0.25,0.25,2.9]])
    slab.rate = 4041.22
    slab.volume()
    print(it.items['rscs_slab'])
    centering_slab = cl.Quantity([['slab ',1,7.5,5],
                        ['beam',-1,4.4,0.25],
                        ['roof bend',-1,21.66-.5,0.25]])
    centering_slab.rate = 313.92
    centering_slab.hArea()
    print(it.items['rscs_beam'])
    centering_beam = cl.Quantity([
                        ['beam',1,21.66-.5,0.65],
                        ['roof bend',1,4.15+.25,0.65],
                        ['columns',6*4,0.25,2.9]
                        ])
    centering_beam.rate = 479.78
    centering_beam.vArea()
    print(it.items['hysd'])
    reinforcement = cl.Quantity([['main bottom1',20,4.5,0.395],
                                 ['main bottom2',20,4.04,.395],
                                 ['main top',2*13,4.85,.395],
                                 ['distribution1',18,7.5-.08,.395],
                                 ['distribution2',28,5-.08,.395],
                                 ['extra bar at top',26,0.95,0.395],
                                 ['extra bar at top2',20,0.8,0.395],
                                 ['stirrups in columns',6*19,0.87,0.395],
                                 ['beam main bar',5*3,2.65+1.5+.25-.08,0.89],
                                 ['beam extra top',2*3,1.5,0.89],
                                 ['beam long',5*2,7.5-.6-.08,0.89],
                                 ['beam long extra bars1',2,2.3,0.89],
                                 ['beam short extra bars2',4,1.3,0.89],
                                 ['roof bend stirrups',158,0.77,0.395],
                                 ['extra bars at openings',16*2,0.6,0.395],
                                 ['distributions at openings',16*2,1.8,0.395],
                                 ['cover plate main bar',2*9*2,1.2-.08,0.395],
                                 ['corner bars at openings',2*8*3,1.0,0.395]])
    reinforcement.rate=4864.9
    reinforcement.reinforcement()
    print(it.items['20cp(1:4)'])
    grading = cl.Quantity([['slab',1,7.5,5]])
    grading.rate = 139.5
    grading.hArea()
    cc148=cl.Quantity([['sub base of floor',1,6.27,5.0-.6-.25-.38,0.1]])
    cc148.rate=3198.59
    cc148.volume()
    
    
    