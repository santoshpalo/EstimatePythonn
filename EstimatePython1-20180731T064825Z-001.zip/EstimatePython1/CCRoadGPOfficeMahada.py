foundation = ([['cut-off wall 1',1,1.68,0.2,0.15],
               ['cut-off wall 2',1,6.45,0.2,0.15],
               ['cut-off wall 3',1,8.94,0.2,0.15]])
metalconcrete = ([['cut-off wall 1',1,1.68,0.2,0.2],
               ['cut-off wall 2',1,6.45,0.2,0.2],
               ['cut-off wall 3',1,8.94,0.2,0.2],
                  ['sub-base',1,2.94,1.68,0.09],
                  ['sub-base 1',1,9.14,6.45,0.09]])
chipsconcrete = ([['crust',1,2.94,1.68,0.08],
                  ['crust 1',1,9.14,6.45,0.08]])
sandfilling = ([['crust',1,2.94,1.68-.2,0.05],
                  ['crust 1',1,9.14-.2,6.45-.2,0.05]])