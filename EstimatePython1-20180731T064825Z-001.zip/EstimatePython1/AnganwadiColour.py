import pandas as pd

import items as it
import LeadStatement1 as ls1
from tkinter import *
import FunctionLibraryR as fr
import textwrap
print(textwrap.fill('Name of the work:-',80))
print('Estimated Cost:-               \t\t\tHead of Account:-')
print('-'*80)
#Total centre line length calculation
tcl_MahadaII = ([['']])
x5=  ([['long walls',2*2,7.97],
          ['short walls 1',2*3,5.23],
          ['short wall 2',2,5.64],
          ['short wall3',2,1.83]])

x = ([['long walls',2*2,7.97],
          ['short walls 1',2*3,5.23],
          ['short wall 2',2,5.64],
          ['short wall3',2,1.83],
      ['external length',-2,8.23],
      ['external width',-2,5.49],
      ['verandah length', -2, 5.64],
      ['verandah width', -2, 1.5],
      ['wall overlappings',-3*2,0.25]
      ])
x0= ([['effective length',1,34.1,3.3],
      ['Door opening', -1.5, 1.08, 1.98],
      ['Window openings', -5*0.5, 0.9, 1.2]])
x1= ([['external length',2,8.23,3.3],
      ['external width',2,5.49,3.3],
      ['external length below plinth',2,8.23+0.13,0.6],
      ['external width below plinth',2,5.49+0.13,0.6],
      ['verandah length',2,5.64,3.3],
      ['verandah width',2,1.5,3.3],
      ['verandah opening 1',-2,2.44,1.98],
      ['verandah opening 2',-1,1.14],
      ['Door opening',-1,1.08,1.98],
      ['Window openings',-3,0.9,1.2]])
x2= ([['Doors',3*2.25,1.08,1.98],
      ['Windows',5*2.75,0.9,1.2]])


class AWC:
    def __init__(self,master):
        frame = Frame(master,bg = 'red')
        frame.pack()
        self.Label = Label(frame, text = 'Quantity')
        self.Label.pack(side=TOP)
        self.button = Button(frame,text = 'QUIT',fg = "red",command = quit)
        self.button.pack(side = LEFT)
        self.TCL = Button(frame,text = "Total centre line length",command = self.TCL)
        self.TCL.pack(side=TOP)
        self.distemper = Button(frame, text="Distempering", command=self.distemper)
        self.distemper.pack(side=TOP)
        self.weather_coating = Button(frame, text="Weather coating", command=self.weather_coating)
        self.weather_coating.pack(side=TOP)
        self.painting = Button(frame, text="Door and Window painting", command=self.Painting)
        self.painting.pack(side=TOP)
    def TCL(self):
        d = x
        table = pd.DataFrame(d, index=range(1, len(d) + 1),
                             columns=['description', 'no', 'length'])
        table['quantity'] = table['no'] * table['length'] .round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}m'.format)

        print('\n', 'Total centre line length', '\n', table, '\n\t\t\t\t\t\t\t\t\t\t',
              '{:.2f}m'.format(table.tquantity))
    def distemper(self):
        d = x0
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['distemper'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.distempering()),'\u20B9{:.2f} '.format(round(fr.distempering()*table.tquantity,0)))
    def weather_coating(self):
        d = x1
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['wall_paint'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.wallpainting()),'\u20B9{:.2f} '.format(round(fr.wallpainting()*table.tquantity,0)))
    def Painting(self):
        d = x2
        table = pd.DataFrame(d, index=range(1,len(d)+1), columns=['description','no','length','height'])
        table['quantity'] = table['no'] * table['length']*table['height'].round(2)
        table.tquantity = (table['quantity'].sum())
        table['length'] = table['length'].map('{:.2f}m'.format)
        table['height'] = table['height'].map('{:.2f}m'.format)
        table['quantity'] = table['quantity'].map('{:.2f}sqm'.format)

        print('\n', it.items['paint'], '\n', table,'\n\t\t\t\t\t\t\t\t\t\t',
               '{:.2f}sqm'.format(table.tquantity) ,'@ \u20B9{:.2f} /sqm = '.format(fr.painting()),'\u20B9{:.2f} '.format(round(fr.painting()*table.tquantity,0)))




if __name__ == "__main__":
    root = Tk()
    app = AWC(root)
    root.mainloop()
    print('\nCost of Distemper 17.70 kg @ \u20B9 66.00 / kg = \u20B9 1168.00')
    print('\n Cost of weather coat 10.46ltr. @ \u20B9 192.00 /ltr. = \u20B9 2008.00')
    print('\nCost of paint 2.20ltr. @ \u20B9 193.00/ltr. = \u20B9 425.00')




































































# #Mahada I
# import numpy as np
#
# x1 = ([['external long wall',2,5.5],
#        ['external short wall',2,8.23]])
# TCL = x1
# y= ([['total wall area',1,39.1-3*0.25-27.46,3.3],
#      ['verandah opening 1',-2/2.0,2.45,1.98],
#      ['verandah opening 2',-1/2.0,1.4,1.98],
#      ['Door 1',-3/2.0,1.08,1.98],
#      ['Windows',-5/2.0,0.9,1.2]])
