import textwrap
import items as it
import ClassLibrary as cl
import FunctionLibraryR as fr
print(textwrap.fill('Name of the work:-Construction of community centre at Rahilla, Ward No 11 , Binka N.A.C.',80))
print(textwrap.fill('Estimated Cost :-\u20B920,000.00\tHead of Account:-M.L.A.L.A.D.(2013-14)'))
print('-'*80)
L=5.84
l=3.15
if __name__ == "__main__":
    print(it.items['m20'])
    m20= cl.Quantity([['long lintel beams',2,L,0.25,0.25],
                      ['short lintel beams',2,l,0.25,0.25],
                      ['long chajja',2,L+0.45,0.45,0.062],
                      ['short chajjas',1,l+0.5,0.45,0.062]])
    m20.rate=fr.gradedconcrete(2)
    m20.volume()
    print(it.items['hysd'])
    rein = cl.Quantity([['long lintel main bars',2*5,5.84-.08,0.89],
                        ['short span lintel main bars',2*5,3.65-.08,0.89],
                        ['extra top bars',2,2.54/3*2+.25,0.89],
                        ['extra top bars 1',4,2.54/3+.25,0.89],
                        ['extra top bar2',2,3.15/3+.25,0.89],
                        ['stirrups',68+42,0.87,0.395],
                        ['chajja bars',76+21,0.45+.25-.08,0.395],
                        ['distributions long',2*3,5.84-.08+.45,0.395],
                        ['distributions chajj2',3,3.15+1.4-.08,0.395]])
    rein.rate=5074.9
    rein.reinforcement()
    print(it.items['rscs_lintel'])
    lintelcentering =  cl.Quantity([['longer sides',2,5.84,0.75],
                                    ['shorter sides',2,3.65,0.75]])
    lintelcentering.rate=fr.rscs(4)
    lintelcentering.vArea()
    print(it.items['rscs_slab'])
    chajjacentering=cl.Quantity([['longer chajjas',2,5.84+0.45,0.45],
                                 ['shorter chajjas',1,3.15+.5,0.45]])
    chajjacentering.rate=fr.rscs(1)
    chajjacentering.hArea()
    print('Cess for welfare of labourers= \u20B9200.00')
    print('Work contingency = \u20B9100.00')
    print('Display board and photograph=\u20B9500.00')
    print('='*80)
    fr.signature(20000,'Twenty thousand only',1,'')

