import ClassLibrary as cl
import items as it
import textwrap
import FunctionLibraryR as fl
import LeadStatementGST as ls
print('Calculation of centre line length')
tcl=cl.Quantity([['long walls',2,19.45],
                ['short walls 1',3,9.4],
                ['short walls 2',2,3.91]])
tcl.tcl()
print('Total centre line length of kitchen and store')
tcl1=cl.Quantity([['long walls',2,6.35],
                  ['short walls',2,3.3]])
tcl1.tcl()
print('\n',it.items['efhs'])
foundation=cl.Quantity([['column trenches',14,2.3,1.8,1.5],
                       ['alround walls',1,79.24-1.2,0.6,0.6],
                        ['plinth protection wall tank side',1,28.5,1.5,0.6],
                        ['kitchen column footings',6,1.5,1.5,1.5],
                        ['kitchen & store walls',1,19.3-6*1.5,0.6,0.6]])
foundation.rate=fl.foundation(1)
foundation.volume()
print('\n',it.items['sand_filling'])
sandfill=cl.Quantity([['column trenches',14,2.3,1.8,0.15],
                       ['alround walls',1,79.24-1.2,0.6,0.15],
                      ['in the plinth',1,19.45,4.5,4],
                      ['under sub base', 1,19.45-.6,9,0.6],
                      ['plinth protection wall tank side',1,28.5,0.9,0.15],
                      ['plinth protection filling', 1, 28.5, 0.6, 3.0],
                      ['kitchen & store foundation trench',6,1.3,1.3,0.15],
                      ['kitchen & store walls',1,19.3,0.6,0.1]])
sandfill.rate=fl.sandfilling()
sandfill.volume()
print('\n',it.items['CC(1:3:6)'])
concrete=cl.Quantity([['column trenches',14,2.3,1.8,0.15],
                       ['alround walls',1,79.24-1.2,0.6,0.15],
                      ['under sub base',1,19.45-.6,9,0.1],
                      ['plinth protection wall tank side', 1, 28.5, 1.5, 0.15],
                      ['plinth protection wall tank side',1,28.5,0.9,3.0],
                        ['plinth protection tank side',1,28.5,1.5,0.1],
                        ['plinth protection front and back',2,10,1.0,0.1],
                      ['sub base of floor Hall',1,15.00,9.00,0.1],
                      ['sub base of rooms & toilets',3,3.65,2.88,0.1],
                      ['kitchen & store column footings',6,1.3,1.3,0.1],
                      ['K & T walls',1,19.3-1.3*6,0.6,0.1],
                      ['K & T sub base floor',1,6.1,3.0,0.1]
                      ])
concrete.rate=fl.concrete(2)
concrete.volume()
print('\n',it.items['CC(1:2:4)'])
concrete=cl.Quantity([
                      ['plinth protection tank side',1,28.5,1.5,0.1],
                        ['plinth protection front and back',2,10,1.0,0.1]])
concrete.rate=fl.concrete(3)
concrete.volume()

print('\n',it.items['bmfpfa'])
brickworkfp=cl.Quantity([['tank side walls',1,17.65,0.38,2.35],
                         ['field side long wall',1,17.65,0.38,0.35],
                         ['tank side return walls',2,3.0,0.38,2.35],
                         ['field side return walls',2,3,0.38,0.35],
                         ['alround walls below plinth',1,74.92-3*0.25,0.25,1.25],
                            ['K & S walls in F & P',1,19.3,0.25,1.0]
                         ])
brickworkfp.rate=fl.brickmasonry(2)[0]
brickworkfp.volume()
print('\n',it.items['m20'])
rcc=cl.Quantity([['column footings',14,2.0,1.50,0.6],
                 ['stair case column footings',2,1.2,1.2,0.3],
                 ['column pedestals tank side',7,0.7,0.5,1.5],
                ['column pedestals field side',7,0.7,0.5,0.9],
                 ['tankside columns upto plinth level',7,0.5,0.3,2.35],
                 ['field side columns',7,0.5,0.3,0.35],
                 ['staircase columns1',1,0.25,0.25,1.5],
                ['staircase columns2',1,0.25,0.25,2.6],
                 ['long wall plinth beam',2,19.45+0.25-5*0.3,0.25,0.3],
                 ['short wall plinth beam',3,9.5,0.3,0.75],
                 ['short wall tie beam',4,9.5,0.3,0.3],
                 ['short wall toilets plinth beam',2,3.65,0.25,0.3],
                 ['lintel bend',1,79.24-3*0.25,0.25,0.15],
                 ['half brick thick lintel bend',1,5,0.13,0.15],
                 ['columns above P.L.',14,0.5,0.3,4.2-.35],
                 ['chajjas 1',12,1.8,0.5,0.06],
                 ['chajjas 2',2,1.2,0.45,0.06],
                 ['R.C.C. beams',7,9,0.3,0.75],
                 ['R.C.C. roof bend long',2,19.45,0.25,0.2],
                 ['R.C.C. roof slab',1,19.8,9.95,0.15],
                 ['R.C.C. staircase waist slab',1,6.1,1.5,0.15],
                 ['staircase beam',1,6.1+1.5+1.5,0.25,0.25],
                 ['R.C.C. landings',2,1.5,1.5,0.16],
                 ['R.C.C. steps',12*2,1.5,0.25,0.16],
                 ['R.C.C. columns K & S',6,1.0,1.0,0.3],
                 ['R.C.C. columns K & S',6,0.25,0.25,4.8],
                 ['R.C.C. plinth bend K & S',1,19.3,0.25,0.25],
                 ['R.C.C. lintel bend',1,19.3,0.25,0.15],
                 ['R.C.C. roof bend K & S',1,19.3,0.25,0.15],
                 ['R.C.C. roof slab',1,6.9,3.8,0.1],
                 ['R.C.C. chajjas',4,1.5,0.45,0.06],
                 ['R.C.C. beam',1,3.0,0.25,0.15]])
rcc.rate=fl.gradedconcrete(2)
rcc.volume()
print('\n',it.items['bmssfa'])
brickworkss=cl.Quantity([['alround walls',1,79.24-3*0.25-14*.3,0.25,4.2-.15-.2],
                         ['half brick thk walls',1,5.0,0.13,4.2-.15],
                         ['deduct door1',-2,1.5,0.25,2.1],
                         ['deduct door2',-2,1.1,0.25,2.1],
                         ['toilet doors',-2,0.75,0.13,2.1],
                         ['deduct window1',-10,1.5,0.25,1.2],
                         ['deduct window2',-2,0.9,0.25,1.2],
                         ['Add for parapet walls',1,57.2,0.25,0.9],
                         ['K&S walls',1,19.3,0.25,3.0],
                         ['door openings',-2,1.2,0.25,2.1],
                         ['window openings',-2,1.2,0.25,1.2]

                         ])
brickworkss.rate=fl.brickmasonry(2)[1]
brickworkss.volume()
print('\n',it.items['hysd'],'\n')
print('\t\t\t\t\t\t\t\t107.00q @ \u20B9',fl.reinforcement(),'/q = \u20B9',round(107.00*fl.reinforcement(),2))
print('\n',it.items['rscs_plinth'])
plinth=cl.Quantity([['column footings',14,2*(2.0+1.50),0.6],
                    ['plinth beams',3*2,9.50,0.75],
                    ['plinth beams long',4,17.3,0.3],
                    ['plinth beam of K&S',2,19.3,0.25],
                    ['Column footings',6*4,1.0,0.3],
                    ])
plinth.rate=fl.rscs(3)
plinth.vArea()
print('\n',it.items['rscs_beam'])
columns=cl.Quantity([['column pedestals tank side',7,2*0.7+2*0.6,1.6],
                    ['column pedestals field side',7,2*0.7+2*0.6,1],
                     ['tankside columns upto plinth level', 7, 2*0.5+ 2*0.3, 2.5],
                     ['field side columns', 7, 2*0.5+2* 0.3, 1],
                     ['columns above P.L.', 14, 2*0.5+2*0.3, 4.2-.35],
                     ['R.C.C. beams', 7, 9, 0.3+2* 0.75],
                     ['R.C.C. columns',24,0.25,4.8],
                     ['R.C.C. beam',1,3.0,0.55]])
columns.rate=fl.rscs(2)
columns.vArea()
print('\n',it.items['rscs_lintel'])
lintel=cl.Quantity([['lintel bend',2,79.24-3*0.25,0.15],
                 ['half brick thick lintel bend',2,5,0.15],
                    ['bottom door1', 2, 1.5, 0.25],
                    ['bottom door2', 2, 1.1, 0.25],
                    ['bottom toilet doors', 2, 0.75,0.25],
                    ['bottom window1', 10, 1.5, 0.25],
                    ['bottom window2', 2, 0.9, 0.25],
                    ['lintel bend of K&S',2,19.3,0.15],
                    ['bottom of lintels',4,1.2,0.25]])
lintel.rate=fl.rscs(4)
lintel.vArea()
print('\n',it.items['rscs_slab'])
slab=cl.Quantity([['chajjas 1',12,1.8,0.5],
                 ['chajjas 2',2,1.2,0.45],
                 ['R.C.C. landings',2,1.5,1.5],
                  ['R.C.C. roof bend long', 2, 19.45, .15],
                  ['R.C.C. roof', 1, 19.8, 0.05],
                  ['R.C.C. roof slab', 1, 19.8, 9.95],
                  ['deduct for beams',-7,9,0.3],
                  ['K&S slab',1,6.9,3.8],
                  ['deduct beam',-1,3.0,0.25],
                  ['for roof bend',1,19.3,0.05],
                  ['chajjas',4,1.5,0.5]])
slab.rate=fl.rscs(1)
slab.hArea()
print('\n',it.items['rscs_stair'])
stair=cl.Quantity([['R.C.C. staircase waist slab',1,7,1.5],
                   ['R.C.C. steps', 13*2, 1.5,0.16],
                   ['R.C.C. step sides',1,10,0.16]])
stair.rate=fl.rscs(5)
stair.hArea()

print('\n',it.items['rscs_walls'])
protectionwall=cl.Quantity([['tank side protection wall',2,28.5,3.0],
                   ])
protectionwall.rate=fl.rscs(6)
protectionwall.vArea()

print('\n',it.items['20cp(1:4)'])
gradingplaster=cl.Quantity([['R.C.C. roof', 1, 19.8, 9.95],
                            ['K&S slab',1,6.9,3.8]])
gradingplaster.rate=fl.plaster(4)
gradingplaster.hArea()
print('\n',it.items['20cp(1:6)'])
plinthplaster=cl.Quantity([
                         ['field side long wall',1,17.65,1.3],
                         ['field side return walls',2,3,1.3],
                        ['wall above grade beam',1,56.9,1.25]])
plinthplaster.rate=fl.plaster(5)
plinthplaster.vArea()
print('\n',it.items['16cp(1:6)'])
plaster16=cl.Quantity([['alround walls',1,79.24-3*0.25-14*.3,4.2],
                         ['deduct door1',-2*.5,1.5,2.1],
                         ['deduct door2',-2*.5,1.1,2.1],
                         ['toilet doors',-2*.5,0.75,2.1],
                         ['deduct window1',-10*.5,1.5,1.2],
                         ['deduct window2',-2*.5,0.9,1.2],
                       ['parapet walls',1,56.9,0.9],
                       ['K&S walls',1,19.3,3.8],
                       ['deduct doors',-2*0.5,1.2,2.1],
                       ['deduct windows',-2*0.5,1.2,1.2]
                       ])
plaster16.rate=fl.plaster(2)
plaster16.vArea()
print('\n',it.items['12cp(1:6)'])
plaster12=cl.Quantity([['alround walls',1,79.24-3*0.25-14*.3,4.2],
                         ['deduct door1',-2*.5,1.5,2.1],
                         ['deduct door2',-2*.5,1.1,2.1],
                         ['toilet doors',-2*.5,0.75,2.1],
                         ['deduct window1',-10*.5,1.5,1.2],
                         ['deduct window2',-2*.5,0.9,1.2],
                       ['parapet walls',1,56.9,1.15],
                       ['K&S walls', 1, 19.3, 3.3],
                       ['deduct doors', -2 * 0.5, 1.2, 2.1],
                       ['deduct windows', -2 * 0.5, 1.2, 1.2]
                       ])
plaster12.rate=fl.plaster(1)
plaster12.vArea()
print('\n',it.items['12cp(1:4)'])
plaster14=cl.Quantity([['half brick thk walls',1,5.0,4.25],])
plaster14.rate=fl.plaster(6)
plaster14.vArea()
print('\n',it.items['6cp(1:4)rcc'])
plaster6=cl.Quantity([['columns in plinth tank side',7,0.8,3],
                      ['columns in plinth field side',7,0.8,1],
                      ['columns in s/s',14,.8,4.2],
                      ['chajjas 1', 12, 1.8, 0.5],
                      ['chajjas 2', 2, 1.2, 0.45],
                      ['beams',4,9,1.5],
                      ['beams open',8,9.0,1.8],
                      ['ceiling of roof slab',1,19.8,9.95],
                      ['deduct for bearing',1,79.24-3*0.25,0.25],
                      ['slab border',1,2*(19.8+9.95),0.15]])
plaster6.rate=fl.plaster(3)
plaster6.hArea()

print('\n',it.items['6cp(1:4)'])
plaster6plain=cl.Quantity([['protection wall tank side',1,28.5,3],
                      ])
plaster6plain.rate=fl.plaster(3)
plaster6plain.vArea()

print('\n',textwrap.fill('Supplying ,fixing and fitting of M.S. Doors and windows including cost and conveyance = 13.50q @ \u20B97,000.00/q = \u20B994,000.oo',80))
print('\n',textwrap.fill('Supplying and fixing of plastic fibre doors at toilet 2 nos @ \u20B95,000.00/no = \u20B9 10,000.00'))
print('\n',it.items['asfloor'])
floor=cl.Quantity([['K & S floor',1,6.1,3.0]])
floor.rate=fl.flooring(1)
floor.hArea()
print('\n',it.items['vitrified'])
floor=cl.Quantity([['hall',1,15,9],
                   ['rooms',2,3.65,2.83]])
floor.rate=fl.vitrifiedtile1()
floor.hArea()
print('\n',it.items['floor tile'])
toiletfloor=cl.Quantity([['toilet floors',2,2.5,1.2]])
toiletfloor.rate=fl.Tile(1)
toiletfloor.hArea()
print('\n',it.items['wall tile'])
walltile=cl.Quantity([['hall sides',1,48,0.9],
                      ['rooms',2,12.97,0.9],
                      ['toilets walls',2,7.4,1.8]])
walltile.rate=fl.Tile(2)
walltile.vArea()
print('\n',it.items['paint'])
doorwindowpaint=cl.Quantity([['Doors1',2*2.25,1.5,2.1],
                             ['doors 2',2*2.25,1.1,2.1],
                             ['windows1',10*2.75,1.5,1.2],
                             ['windows2',2*2.75,0.9,1.2],
                             ['K&S doors',2*2.75,1.2,2.1],
                             ['K&S windows',2*2.25,1.2,1.2]])
doorwindowpaint.rate=fl.painting()
doorwindowpaint.vArea()
print('\n',it.items['wall primer'])
wallprimer=cl.Quantity([['12mm thick (1:6) plaster area',360.33],
                        ['6mm thick plaster area',490.47],
                        ['12mm thick (1:4) plaster area',21.25],
                        ['16mm thick (1:6) plaster area',346.11]
                        ])
wallprimer.rate=fl.priming_one_coat()
wallprimer.quantity(2)
print('\n',it.items['wall putty'])
wallputty=cl.Quantity([['12mm thick (1:6) plaster area',360.33],
                        ['6mm thick plaster area',490.47],
                        ['12mm thick (1:4) plaster area',21.24],
                        ['16mm thick (1:6) plaster area',346.11],
                       ['deduct out side walls plaster',-215.00]])
wallputty.rate=fl.wallputty()
wallputty.quantity(2)
print('\n',it.items['wall_paint'])
wallpaint=cl.Quantity([['alround walls',1,56.9,4.2+.6+0.9*2+0.25],
                       ['deduct for doors',-0.5,1.5,2.1],
                       ['deduct for windows',-10/2,1.5,1.2],
                       ['deduct for windows2',-1,0.9,1.2]])
wallpaint.rate=fl.wallpainting()
wallpaint.vArea()
print('\n',it.items['distemper'])
distemper=cl.Quantity([['12mm thick (1:6) plaster area',294.9],
                        ['6mm thick plaster area',490.47],
                        ['12mm thick (1:4) plaster area',21.24],
                        ['16mm thick (1:6) plaster area',294.9],
                       ['deduct out side walls plaster',-215.00]])
distemper.rate=fl.distempering()
distemper.quantity(2)
print('\n',it.items['wpcp'])
wpcp=cl.Quantity([['12mm thick plaster K&S',59.73],
                 ['16mm thick plaster',69.38],
                 ['ceiling and chajjas',26.44+3]])
wpcp.rate=fl.waterproofpaint()
wpcp.quantity(2)

materials=cl.Quantity([['distemper',221.59,'kg',ls.z['total cost'][21]],
                       ['weather coat',22.48,'ltr',ls.z['total cost'][20]],
                       ['cement based wall putty',709.21,'kg',ls.z['total cost'][24]],
                       ['wall primer',92.53,'ltr',ls.z['total cost'][25]],
                       ['enamel paint',12.55,'ltr',ls.z['total cost'][18]],
                       ['red oxide primer',5.42,'ltr',ls.z['total cost'][17]],
                       ['water proofing cement paint',39.65,'kg',ls.z['total cost'][22]],
                       ['ceramic glazed wall tile',93.19,'sqm',ls.z['total cost'][16]],
                       ['ceramic glazed floor tile', 6.00, 'sqm', ls.z['total cost'][15]]])
materials.cost_material()
print('\n',it.items['hand railing'])
print('\n\t\t\t\t','40.00m @ \u20B92933.4/m = \u20B91,17,336.00')
print("\nCess for welfare of labourers =\u20B9 35,000.00 ")
print('\nCost towards display board and photograph & T&P = \u20B935,000.00')
print('\nProvisionl cost towards electrification and sanitation= \u20B9 4,76,809.00')
fl.signature(4000000,'Forty lakh only',6,'')




