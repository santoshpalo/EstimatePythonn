from tkinter import *

class Application(Frame):
    def __init__(self,master):
        Frame.__init__(self,master)
        self.grid()

        self.velocity = 0
        self.displacement=0
        self.time=0
        self.unknown=0


        self.create_widgets()
    def create_widgets(self):
        self.L1=Label(self)
        self.L2=Label(self)
        self.L3=Label(self)
        self.L4=Label(self)


        self.L1.grid(column = 1,row = 1,padx=10)
        self.L2.grid(column = 1, row =2)
        self.L3.grid(column = 1,row = 3)
        self.L4.grid(column =3,row =5)


        self.L1["text"]="Velocity"+str(self.velocity)+"m/s"
        self.L2["text"] = "Displacement" + str(self.displacement) + "m"
        self.L3["text"] = "Time" + str(self.time)+"s"
        self.L4["text"]="Unknown variable ="+str(self.unknown)


        self.entryv=Entry(self,bd=5)
        self.entryv.grid(column = 2, row=1)
        self.entrys = Entry(self, bd=5)
        self.entrys.grid(column=2, row=2)
        self.entryt = Entry(self, bd=5)
        self.entryt.grid(column=2, row=3)

        self.button1=Button(self)
        self.button1["text"]="Calculate the unknown"
        self.button1["command"]=self.calc
        self.button1.grid(column = 2,row = 4)

    def calc(self):
        self.velocity=self.entryv.get()
        self.displacement=self.entrys.get()
        self.time=self.entryt.get()
        self.L1["text"] = "Velocity" + str(self.velocity) + "m/s"
        self.L2["text"] = "Displacement" + str(self.displacement) + "m"
        self.L3["text"] = "Time" + str(self.time) + "s"
        # self.L4["text"] = "Unknown variable =" + str(self.unknown)

        if int(self.velocity) == 0:
            self.unknown = int(self.displacement)/int(self.time)
            self.L4["text"] = "Velocity =" + str(self.unknown)+"m/s"

        elif int(self.time) == 0:
            self.unknown = int(self.displacement)/int(self.velocity)
            self.L4["text"] = "Time =" + str(self.unknown)+"s"

        elif int(self.displacement) == 0:
            self.unknown=int(self.velocity)*int(self.time)
            self.L4["text"] = "Displacement =" + str(self.unknown)+"m"
        else:
            pass









root=Tk()
root.title("Velocity-Displacement-Time")
root.geometry("600x400")
app= Application(root)

root.mainloop()


