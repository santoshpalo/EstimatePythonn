def a(x):
    return round(x*.3048,2)
hysd16=([['long walls main bars',2*5,a(50.33-0.66)],
       ['short walls main bars',2*5,a(31.5-0.66)],
         ['intermediate tie beams',4,a(31.5-.66)]
       ])
hysd12=([['intermediate tie beams',2,a(31.5-.66)],
         ['extra top at columns',8,a(7)],
         ['extra to at short columns',4,a(7)],
         ['extra corner columns',4*2,a(4.5)],
         ['bars at staircase',16,a(5)]])
hysd8=([['stirrups long walls',20*5*2,0.87],
        ['stirrups short walls',19*2*3,0.87],
        ['staircase stirrups',2*8,0.87]])
tcl=([['long walls',2,a(50.33-1.25)],
      ['short walls',2,a(31.5-1.25)]])
